import { Button, Notification, PasswordInput } from '@mantine/core'
import { useNavigate } from 'react-router-dom'
import useForm from '../../hooks/useForm'
import { instance } from '../../axios'
import { getError } from '../../utils'

export default function SecureQuestion({ handleClose }) {
    const navigate = useNavigate()
    const { formValues, formErr, handleChange, handleSubmit, setErrors } = useForm({ rep: "" }, (values) => {
        instance.post(`/admins/password/recovery`, { ...values })
            .then((res) => {
                const { link } = res.data
                handleClose()
                navigate(link)
            })
            .catch(err => {
                const getErr = getError(err)
                setErrors("message", getErr)
            })
    })
    return (
        <div>
            <form onSubmit={handleSubmit}>
                {formErr.message && <Notification color="red" title="Erreur">{formErr.message}</Notification>}
                <PasswordInput
                    label="Donner votre reponse ici"
                    placeholder="Donner votre reponse ..."
                    autoComplete="off"
                    autoCorrect="off"
                    name="rep"
                    value={formValues.rep}
                    onChange={handleChange}
                    required
                />
                <Button mt={5} type="submit">Soumettre</Button>
            </form>
        </div>
    )
}