import { Button, Notification, PasswordInput, Text, Title } from '@mantine/core'
import useForm from '../../hooks/useForm'
import { useAppState } from '../../context/AppContext'
import { instance } from '../../axios'
import { getError } from '../../utils'

export default function ChangePass() {
    const { getUser, logOut } = useAppState()
    const userId = getUser.us_id

    const submitWrapper = (values) => {
        instance.put(`/users_auth/changepass/${userId}`, { ...values })
            .then(() => {
                logOut()
                cleanForm()
            })
            .catch(err => {
                const error = getError(err)
                setErrors("message", error)
            })
    }

    const initialValues = { oldPass: "", newPass: "", confirmPass: "" }
    const { formValues, formErr, handleChange, handleSubmit, setErrors, cleanForm } = useForm(initialValues, submitWrapper)

    const validate = (values, err) => {
        const { oldPass, newPass, confirmPass } = values
        if (newPass === oldPass) err.newPass = "le nouveau mot de passe doit être different de l'ancien mot de passe"
        else if (newPass !== confirmPass) err.newPass = "confirmer le nouveau mot de passe"
    }

    return (
        <>
            {parseInt(userId, 10) === 14
                ? <Text>Vous ne pouvez pas changer de mot de passe en test !</Text>
                : <div>
                    <Title order={4}>Changer de mot passe en toute securité</Title>
                    {formErr.message && <Notification m={5} onClose={() => setErrors("message", "")} color="red" title={<Title order={3}>Erreur</Title>}>{formErr.message}</Notification>}
                    <form onSubmit={(e) => handleSubmit(e, validate)}>
                        <PasswordInput
                            label="Ancien mot de passe"
                            placeholder="Ancien mot de passe"
                            name="oldPass"
                            value={formValues.oldPass}
                            onChange={handleChange}
                            required
                            error={formErr.oldPass}
                        />
                        <PasswordInput
                            label="Nouveau mot de passe"
                            placeholder="Nouveau mot de passe"
                            name="newPass"
                            value={formValues.newPass}
                            onChange={handleChange}
                            required
                            error={formErr.newPass}
                        />
                        <PasswordInput
                            label="Confirmer le nouveau mot de passe"
                            placeholder="Confirmer le nouveau mot de passe"
                            name="confirmPass"
                            value={formValues.confirmPass}
                            onChange={handleChange}
                            required
                            error={formErr.confirmPass}
                        />
                        <Button disabled={(userId === 14)} mt={5} type="submit">Changer</Button>
                    </form>
                </div>
            }
        </>
    )
}