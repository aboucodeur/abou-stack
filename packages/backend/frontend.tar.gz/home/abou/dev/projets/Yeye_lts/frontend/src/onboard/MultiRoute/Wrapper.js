import React, { useCallback } from "react"
import Joyride from "react-joyride"
import { useMount } from "react-use"
import { useMultipleOnboardContext } from "./context"
import { Text, useMantineTheme } from "@mantine/core"
import { wrapStepAfter } from ".."
import useBasic from "./useBasic"
import useOnboardRoute from "./useOnboardRoute"
import { useLocalStorage } from "@mantine/hooks"
import { Outlet } from "react-router-dom"

// modal a maintenir
export const BLOCK = {
    achat: {
        buttonAddProduct: 14,
        buttonAchatValid_16: 16,
        validConfirm_17: 17,
    },
}

// modal a fermer apres next
export const CLOSE = {
    product: {
        modal: 8,
    },
    achat: {
        modal: 14,
    },
}

// modal a ouvrir apres next
export const AUTO = {
    product: {
        modal: 2,
    },
    achat: {
        modal: 11,
        receptionTab: 19,
    },
}

export default function MultiRouteWrapper() {
    const theme = useMantineTheme()

    const {
        setState,
        state: { run, stepIndex, steps },
    } = useMultipleOnboardContext()

    const { nextStep, prevStep, stayStep } = useBasic()
    const { taPath } = useOnboardRoute()
    const [userAgree, setValue] = useLocalStorage({ key: "yy_start_tour" })

    /**
     * Force user to click button without next and prev
     */
    const forceUserClick = (userOption = { next: false, back: false }) => {
        let options = {
            next: false,
            back: false,
            ...userOption,
        }
        return {
            styles: {
                buttonNext: {
                    display: options.next ? undefined : "none",
                },
                buttonBack: {
                    display: options.back ? undefined : "none",
                },
            },
        }
    }

    // ** user steps
    useMount(() => {
        setState({
            steps: [
                {
                    target: "#yeye_welcome_0",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Salut, bienvenue sur Yeye !
                            </Text>
                            <Text>
                                je vais t'expliquer en seulement quelques secondes comment
                                l'application je fonctionne.
                            </Text>
                        </>
                    ),
                    hideCloseButton: true,
                },
                // button_add_product_1
                {
                    target: "#button_add_product_1",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Cliquer sur le bouton
                            </Text>
                        </>
                    ),
                    ...forceUserClick(),
                    hideCloseButton: true,
                },
                // input_add_product_name_2
                {
                    target: "#input_add_product_name_2",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Donner le nom du produit
                            </Text>
                            <Text>Exemple : Farine </Text>
                        </>
                    ),
                },
                // input_add_product_unity_3
                {
                    target: "#input_add_product_unity_3",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Cliquer sur suivant !
                            </Text>
                            <Text>Exemple : Unites, Sac, KG, Litres.</Text>
                        </>
                    ),
                    placement: "right",
                },
                // select_add_product_depot_4
                {
                    target: "#select_add_product_depot_4",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Cliquer sur suivant !
                            </Text>
                            <Text>
                                Par defaut : yeye cree un magasin nommer <mark>Principale</mark>.
                            </Text>
                        </>
                    ),
                    placement: "right",
                },
                // numberinput_add_product_aprice_5
                {
                    target: "#numberinput_add_product_aprice_5",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Donner le prix d'achat !
                            </Text>
                        </>
                    ),
                    placement: "right",
                },
                // numberinput_add_product_vprice_6
                {
                    target: "#numberinput_add_product_vprice_6",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Donner le prix de vente !
                            </Text>
                        </>
                    ),
                    placement: "right",
                },
                // button_add_product_submit_7
                {
                    target: "#button_add_product_submit_7",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Cliquer pour enregistrer le produit
                            </Text>
                        </>
                    ),
                    placement: "right",
                    ...forceUserClick({ back: true }),
                    hideCloseButton: true,
                },
                // finish_add_product_8 => body
                {
                    target: "body",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Bravo, le produit a ete ajouter avec succes dans votre stock. Une
                                fois le produit ajouter la quantite est a <mark>zero</mark>,
                                maintenant nous allons faire un achat pour augmenter la quantite
                            </Text>
                        </>
                    ),
                },
                // menu_achat_9
                {
                    target: "#menu_achat_9",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Ici nous allons commander nos et gerer nos produits aupres du
                                fournisseurs. Commandes, paiements, reception et retour de commande
                            </Text>
                        </>
                    ),
                },
                // button_add_achat_10
                {
                    target: "#button_add_achat_10",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Cliquer pour ajouter un achat fournisseur !
                            </Text>
                        </>
                    ),
                },
                // dateinput_add_achat_11
                {
                    target: "#dateinput_add_achat_11",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Donner la date prevus de la commande !
                            </Text>
                        </>
                    ),
                },
                // select_add_achat_12
                {
                    target: "#select_add_achat_12",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Choisir le fournisseur !
                            </Text>
                            <Text>
                                Par defaut yeye creer un fournisseur nommer{" "}
                                <mark>Achat Rapide</mark>
                            </Text>
                        </>
                    ),
                    placement: "right",
                },
                // button_add_achat_submit_13
                {
                    target: "#button_add_achat_submit_13",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Cliquer sur le boutton pour enregistrer la commande !
                            </Text>
                        </>
                    ),
                    placement: "right",
                    ...forceUserClick({ back: true }),
                    hideCloseButton: true,
                },
                // page_add_achat_detail_14
                {
                    target: "#page_add_achat_detail_14",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Selectionner le produit a ajouter, puis cliquer sur le boutton{" "}
                                <mark>+</mark> !
                            </Text>
                            <Text>
                                Donner le *nom, *quantite et *prix d'achat, puis cliquer sur + pour
                                enregistrer.
                            </Text>
                        </>
                    ),
                    placement: "right",
                    ...forceUserClick(),
                },
                // page_add_achat_product_15
                {
                    target: "#page_add_achat_product_15",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Listes des produits commandees chez le fournisseur
                            </Text>
                        </>
                    ),
                    placement: "right",
                    ...forceUserClick(),
                },
                // button_add_achat_valid_16
                {
                    target: "#button_add_achat_valid_16",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Cliquer pour valider la commande !
                            </Text>
                        </>
                    ),
                    ...forceUserClick(),
                    hideCloseButton: true,
                },
                // button_add_achat_validconfirm_17
                {
                    target: "#button_add_achat_validconfirm_17",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Pour finir cliquer valider l'achat
                            </Text>
                        </>
                    ),
                    ...forceUserClick(),
                    hideCloseButton: true,
                },
                // body
                {
                    target: "body",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Maintenant nous allons receptionner les produits !
                            </Text>
                        </>
                    ),
                    placement: "center",
                    ...forceUserClick({ next: true }), // afficher le bouton suivant
                },
                // tab_add_achat_reception_19
                {
                    target: "button[itemid=tab_add_achat_reception_19]",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Pour modifier la quantite il faut receptionner les produits
                                commandees !
                            </Text>
                        </>
                    ),
                    ...forceUserClick({ next: true }),
                },
                // button_add_achat_reception_20
                {
                    target: "#button_add_achat_reception_20",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Cliquer pour ajouter la reception !
                            </Text>
                        </>
                    ),
                    ...forceUserClick(),
                },
                // anchor_add_achat_reception_21
                {
                    target: "#anchor_add_achat_reception_21",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Cliquer pour afficher la reception !
                            </Text>
                        </>
                    ),
                    ...forceUserClick(),
                },
                // button_add_achat_receptionfull_22
                {
                    target: "#button_add_achat_receptionfull_22",
                    content: (
                        <>
                            <Text weight="bold" size={16}>
                                Bravo maintenant nous produits on ete chargees en stock !
                            </Text>
                        </>
                    ),
                    ...forceUserClick(),
                    hideCloseButton: true,
                },
                // body_23
                {
                    target: "body",
                    content: (
                        <>
                            <Text weight="bold" size={18}>
                                Felicitation, vous avez compris 80% de l'application !
                            </Text>
                            <Text>Maintenant nous allons verifier notre stock.</Text>
                        </>
                    ),
                    placement: "center",
                    ...forceUserClick({ next: true }), // afficher le bouton suivant
                    hideCloseButton: true,
                },
            ],
        })
    })

    // ** user steps comtroller
    const handleCallback = useCallback(
        (data) => {
            const { action, index, type } = data
            wrapStepAfter((act) => {
                // refactor to switch cas
                switch (index) {
                    case 0:
                        taPath("/depots")
                        nextStep(index)
                        break
                    case 1:
                        nextStep(index)
                        if (action === act.PREV) prevStep(index)
                        break
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 10:
                    case 11:
                    case 12:
                    case 13:
                    case 15:
                    case 16:
                    case 17:
                    case 18:
                    case 19:
                    case 20:
                    case 22:
                        nextStep(index)
                        if (action === act.PREV) prevStep(index)
                        break
                    case 9:
                        taPath("/commandes/fournisseurs")
                        nextStep(index)
                        if (action === act.PREV) prevStep(index)
                        break
                    // block next
                    case 14:
                    case 21:
                        stayStep(index)
                        if (action === act.PREV) prevStep(index)
                        break
                    case 23:
                        taPath("/depots")
                        nextStep(index)
                        if (action === act.PREV) prevStep(index)
                        break

                    default:
                        // end of tour just close
                        if (type === "tour:end") {
                            setState({ run: false, stepIndex: 0, tourActive: false })
                            setValue("n")
                        }
                        break
                }
            }, type)
        },
        [nextStep, prevStep, setState, setValue, stayStep, taPath],
    )

    return (
        <>
            <Outlet />
            {userAgree === "y" ? (
                <Joyride
                    callback={handleCallback}
                    continuous
                    run={run}
                    stepIndex={stepIndex}
                    steps={steps}
                    scrollToFirstStep
                    disableOverlayClose
                    spotlightClicks
                    locale={{
                        next: "Suivant",
                        back: "Retour",
                        last: "Terminer",
                    }}
                    styles={{
                        buttonNext: {
                            backgroundColor: theme.colors.green[6],
                            color: theme.white,
                            borderRadius: "12px",
                            // padding: '5px',
                        },

                        buttonBack: {
                            backgroundColor: theme.colors.red[6],
                            color: theme.white,
                            borderRadius: "12px",
                            // padding: '5px',
                        },

                        options: {
                            primaryColor: theme.colors.orange[6],
                            zIndex: 999999,
                            beaconSize: 36,
                            width: undefined,
                        },
                    }}
                />
            ) : null}
        </>
    )
}
