import { useMemo, useState } from "react";
import { Button, Group, Text } from "@mantine/core";
import { generateColor } from "../../utils";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { IconArrowLeft, IconArrowRight } from "@tabler/icons-react";

export default function HomeStats({ graph = {} }) {
    const [step, setStep] = useState(0);
    const titles = useMemo(() => ["Nombres de produits par entrepots", "Nombres d'achats par fournisseurs"], [])

    const prev = () => setStep((step) => (step === 0 ? 1 : step - 1));
    const next = () => setStep((step) => (step === 1 ? 0 : step + 1));

    const chartData = step === 0 ? graph.stock.map((d) => ({ name: d.de_nom, total: parseInt(d.total, 10) }))
        : graph.frs.map((d) => ({ name: d.fo_nom, total: parseInt(d.total, 10) })) 


    return (
        <div>
            <Text weight="bold" align="center">{titles[step]}</Text>
            <ResponsiveContainer width="80%" height={500}>
                <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line
                        type="monotone"
                        dataKey="total"
                        stroke={generateColor(chartData.length)[0]}
                        strokeWidth={2}
                    />
                </LineChart>
            </ResponsiveContainer>
            <Group>
                <Button onClick={prev}>
                    <IconArrowLeft />
                </Button>
                <Button onClick={next}>
                    <IconArrowRight />
                </Button>
            </Group>
        </div>
    );
}
