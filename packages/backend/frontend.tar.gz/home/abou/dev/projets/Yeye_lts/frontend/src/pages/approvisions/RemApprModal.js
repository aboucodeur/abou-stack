import { Button } from '@mantine/core'
import { removeApprovision } from '../../services/api'
import { useMutation, useQueryClient } from "react-query"

export default function RemAchatModal({ apId, handleClose }) {
    const query = useQueryClient()
    const { mutate } = useMutation(["appr"], removeApprovision)
    const handleRemove = (apId) => {
        mutate(apId, {
            onSuccess() {
                query.invalidateQueries("appr")
                handleClose()
            }
        })
    }
    return <Button color="red" fullWidth onClick={() => handleRemove(apId)}>Oui</Button>
}