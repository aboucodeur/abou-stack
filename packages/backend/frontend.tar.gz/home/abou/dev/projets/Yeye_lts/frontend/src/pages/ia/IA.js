import { Divider, Group, Loader, Text, Title } from '@mantine/core'
import { useQuery } from "react-query"
import { instance } from "../../axios"
import { useAppState } from '../../context/AppContext'
import { AppTable } from '../../components'
import { formatNumber } from '../../helper'

export default function IA() {
    const { getShop } = useAppState()
    const shopId = getShop.bo_id
    const { data: iaData = [], isLoading } = useQuery(["ia", shopId],
        ({ queryKey }) => instance.get(`/ia/info_ia/${queryKey[1]}`).then(res => res.data)
    )

    const isArrProduct = Array.isArray(iaData.product)
    const isArrClient = Array.isArray(iaData.client)
    const isArrDay = Array.isArray(iaData.day)

    const productRows = isArrProduct && iaData.product.map((d, _idx) => (
        <tr key={d.pr_nom}>
            <td><Text color={_idx === 0 ? "orange" : undefined}>{d.pr_nom}</Text></td>
            <td><Text weight="bold" color="orange">{formatNumber(d.total_ventes)}</Text></td>
        </tr>
    ))
    const clientRows = isArrClient && iaData.client.map((d, _idx) => (
        <tr key={d.cl_nom}>
            <td><Text color={_idx === 0 ? "orange" : undefined}>{d.cl_nom}</Text></td>
            <td><Text weight="bold" color="orange">{formatNumber(d.nb_ventes)}</Text></td>
        </tr>
    ))
    const max = isArrDay && iaData.day[0] ? iaData.day[0].nb_ventes : 0
    const dayRows = isArrDay && iaData.day.map((d, _idx) => (
        <tr key={d.j_m}>
            <td>
                <Text color={((_idx + 1) === 1 || d.nb_ventes === max)
                    ? "green"
                    : (_idx + 1) === 7
                        ? "red"
                        : undefined}
                >
                    {(_idx + 1)} - {d.j_m}
                </Text>
            </td>
        </tr>
    ))

    if (isLoading) return (
        <div>
            <Text>Patienter je reflechis ...</Text>
            <Loader />
        </div>
    )
    return (
        <div>
            <Title order={4}>Informations generales</Title>
            <Divider mt={5} />
            <Group spacing={5} align="flex-start">
                <Group align="normal">
                    <AppTable
                        tableHead={["Top Jour"]}
                        tableRows={dayRows}
                    />
                    <AppTable
                        tableHead={["Produits Top 10", "Totals ventes"]}
                        tableRows={productRows}
                    />
                    <AppTable
                        tableHead={["Clients Top 10", "Nombres ventes"]}
                        tableRows={clientRows}
                    />
                </Group>
            </Group>
        </div>
    )
}
