import { lazy, Suspense } from 'react'
import { modals } from '@mantine/modals'
import { Alert, Badge, Button, Card, Divider, Group, Menu, Text, Title } from '@mantine/core'
import {
    getOneShopUser,
    editUserAccountState,
    deleteUserAccount,
    getBoutique,
    getAllShopUser,
    resetUserAccountPass,
} from '../../services/api'
import { useMutation, useQuery, useQueryClient } from 'react-query'
import { useNavigate, useParams } from 'react-router-dom'
import { AppTable } from '../../components'

const EditUserPage = lazy(() => import('./EditUserPage'))
const EditUserShopPage = lazy(() => import('./EditUserShopPage'))
const LicencePage = lazy(() => import('./licence/LicencePage'))

export default function SingleUser() {
    const { id, boId } = useParams()
    const userId = parseInt(id, 10)
    const shopId = parseInt(boId, 10)
    const navigate = useNavigate()

    const { data: userInfos = {}, isLoading: l1 } = useQuery(['user', userId], ({ queryKey }) =>
        getOneShopUser(queryKey[1]),
    )
    const { data: shopInfos = {}, isLoading: l2 } = useQuery(['shop', shopId], ({ queryKey }) =>
        getBoutique(queryKey[1]),
    )
    const { data: allShopUser = [], isLoading: l3 } = useQuery(
        ['shop_user', shopId],
        ({ queryKey }) => getAllShopUser(queryKey[1]),
    )

    const query = useQueryClient()
    const { mutate } = useMutation(['user'], editUserAccountState)
    const { mutate: remAccount } = useMutation(['user'], deleteUserAccount)
    const { mutate: resetPass } = useMutation(['user'], resetUserAccountPass)

    const editUserState = (id, type) => {
        mutate(
            { boId: id, type },
            {
                onSuccess() {
                    query.invalidateQueries('user')
                    query.invalidateQueries('shop_user')
                },
            },
        )
    }
    
    const handleRemove = (id) => {
        remAccount(id, {
            onSuccess() {
                query.invalidateQueries('user')
                navigate('/admin/dashboard')
            },
        })
    }

    const remoUserModal = (data) => {
        modals.open({
            title: 'Suppresion',
            children: (
                <div>
                    <Alert m={5} color="red" title="Avertissemnt">
                        <Text>
                            Suppression total de l'utilisateur cet action est irreversible veillez
                            le desactiver temporairement
                        </Text>
                    </Alert>
                    <Button
                        color="red"
                        onClick={() => {
                            handleRemove(data)
                            modals.closeAll()
                        }}
                    >
                        Oui, Supprimer
                    </Button>
                </div>
            ),
        })
    }

    const resetUserPassModal = (data) => {
        modals.open({
            title: `Reset du mot de passe ${data.us_prenom} ${data.us_nom}`,
            children: (
                <Button
                    color="orange"
                    onClick={() => {
                        resetPass(data.us_id, {
                            onSuccess() {
                                modals.closeAll()
                            },
                        })
                    }}
                >
                    Oui, renitialiser
                </Button>
            ),
        })
    }

    const editUserInfoModal = (data) => {
        modals.open({
            title: `Modification de : ${data.us_prenom} ${data.us_nom}`,
            children: (
                <Suspense fallback={<p>Chargement en cours</p>}>
                    <EditUserPage data={data} handleClose={() => modals.closeAll()} />
                </Suspense>
            ),
        })
    }

    const editUserShopModal = (data) => {
        modals.open({
            title: 'Info boutique',
            children: (
                <Suspense fallback={<p>Chargement en cours</p>}>
                    <EditUserShopPage data={data} handleClose={() => modals.closeAll()} />
                </Suspense>
            ),
        })
    }

    const openLicenceModal = () => {
        modals.open({
            title: 'Licence',
            children: (
                <Suspense fallback={<p>Chargement en cours</p>}>
                    <LicencePage boId={shopId} handleClose={() => modals.closeAll()} />
                </Suspense>
            ),
        })
    }

    const tableRows = allShopUser.map((u) => (
        <tr key={u.us_id}>
            <td>
                <Text>{u.us_id}</Text>
            </td>
            <td>
                <Text>{u.us_prenom}</Text>
            </td>
            <td>
                <Text>{u.us_nom}</Text>
            </td>
            <td>
                <Text>{u.us_email}</Text>
            </td>
            <td>
                <Badge>{u.disabled ? 'Desactiver' : 'Activer'}</Badge>
            </td>
            <td>
                <Button m={5} color="orange" onClick={() => resetUserPassModal({ ...u })}>
                    Rénitialiser
                </Button>
            </td>
        </tr>
    ))

    if (l1 || l2 || l3) return <div>Chargement des informations en cours ....</div>

    return (
        <div>
            <Title order={4}>Informations</Title>
            <Card
                m={5}
                shadow="lg"
                sx={(theme) => ({ backgroundColor: theme.colors.blue[6], color: 'white' })}
            >
                <Text>
                    Nom : {userInfos.us_prenom} {userInfos.us_nom}
                </Text>
                <Text>Entreprise : {shopInfos.bo_nom}</Text>
                <Text>Identifiant (utilisateur) : {userId}</Text>
                <Text>Identifiant (boutique) : {shopId}</Text>
                <Text>Email : {userInfos.us_email} </Text>
                <Text>Telephone : {userInfos.us_tel}</Text>
                <Text>Etat du compte : {userInfos.disabled ? 'Desactiver' : 'Activer'}</Text>
                <Text>à rejoins : {new Date(userInfos.createdAt).toLocaleString()} </Text>
                <Menu trigger="hover">
                    <Menu.Target>
                        <Button>Options</Button>
                    </Menu.Target>
                    <Menu.Dropdown>
                        <Menu.Item color="blue" onClick={() => editUserState(shopId, 'act')}>
                            Activer
                        </Menu.Item>
                        <Menu.Item color="orange" onClick={() => editUserState(shopId, 'des')}>
                            Desactiver
                        </Menu.Item>
                        <Menu.Label>Zone Dangereuse</Menu.Label>
                        <Menu.Item
                            color="orange"
                            onClick={() => resetUserPassModal({ ...userInfos })}
                        >
                            Mot de passe
                        </Menu.Item>
                        <Menu.Item color="red" onClick={() => remoUserModal(userId)}>
                            Supprimer
                        </Menu.Item>
                    </Menu.Dropdown>
                </Menu>
                <Divider m={5} />
                <Group m={5} spacing={4}>
                    <Button variant="white" onClick={() => editUserInfoModal({ ...userInfos })}>
                        Infos perso
                    </Button>
                    <Button color="orange" onClick={() => editUserShopModal({ ...shopInfos })}>
                        Infos entreprise
                    </Button>
                    <Button variant="white" onClick={() => openLicenceModal()}>
                        Licence
                    </Button>
                </Group>
            </Card>
            {allShopUser.length === 0 ? (
                <Text m={5} weight="bold">
                    Pas de gerant(s)
                </Text>
            ) : (
                <AppTable
                    title={`Nombres de gerants de la boutiques : ${allShopUser.length}`}
                    tableHead={['Id', 'Prenom', 'Nom', 'Email', 'Etat', 'Action']}
                    tableRows={tableRows}
                />
            )}
        </div>
    )
}
