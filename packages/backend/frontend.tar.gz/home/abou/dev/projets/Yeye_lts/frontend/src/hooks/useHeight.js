import { useCallback, useEffect, useState } from 'react'
/**
 * Get small piece of screen to dynamic height table
 * calcul whit math formula
 */
const calcHeight = (val, ajustVal) => ((val - (Math.round(val / 4))) - ajustVal)
export default function useHeight(addVal = 0) {
    const [height, setHeight] = useState(calcHeight(window.innerHeight, addVal))
    const detectWindowHeight = useCallback((h) => setHeight(calcHeight(h, addVal)), [addVal])

    useEffect(() => {
        window.addEventListener("resize", (e) => detectWindowHeight(e.target.innerHeight))
        return () => window.removeEventListener("resize", (e) => detectWindowHeight(e.target.innerHeight))
    }, [detectWindowHeight])
    return { wH: height }
}