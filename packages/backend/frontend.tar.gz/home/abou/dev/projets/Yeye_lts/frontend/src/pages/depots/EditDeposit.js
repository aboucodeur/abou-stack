import { useEffect } from 'react'
import { Button, Notification, TextInput } from '@mantine/core'
import useForm from '../../hooks/useForm'
import { editDepot } from '../../services/api'
import { useMutation, useQueryClient } from 'react-query'
import { getError } from '../../utils'

export default function EditDeposit({ data, handleClose }) {
    const { formValues, handleChange, setValues, cleanForm, formErr, setErrors, getInputProps } = useForm({ nom: "" })
    const { mutate } = useMutation(["dep"], editDepot)
    const queryClient = useQueryClient()

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ nom: formValues.nom.trim(), deId: data.de_id }, {
            onSuccess: () => {
                queryClient.invalidateQueries("dep")
                cleanForm()
                handleClose()
            },
            onError: (err) => {
                const error = getError(err)
                if (error) setErrors("message", error)
            }
        })
    }

    useEffect(() => {
        setValues("nom", data.de_nom)
    }, [data, setValues])

    return (
        <div>
            {formErr.message && <Notification m={5} color="red" onClose={() => setErrors("message", "")}>{formErr.message}</Notification>}
            <form onSubmit={handleSubmit}>
                <TextInput
                    label="Nouveau nom"
                    description="200 caracteres maximun"
                    {...getInputProps("nom")}
                    onChange={handleChange}
                    maxLength={200}
                />
                <Button type="submit" mt={5} fullWidth variant='outline' color="orange">Modifier</Button>
            </form>
        </div>
    )
}