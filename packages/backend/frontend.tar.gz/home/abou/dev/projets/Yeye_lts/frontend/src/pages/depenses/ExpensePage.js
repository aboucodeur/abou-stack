import { useMemo, useState } from 'react'
import { useAppState } from '../../context/AppContext'
import { Button, ActionIcon, Flex, Tooltip, Text, Group } from '@mantine/core'
import { useMutation, useQuery, useQueryClient } from "react-query"
import { addShopDepense, getShopDepense, editShopDepense, removeShopDepense } from '../../services/api'
import { IconEdit, IconTrash } from "@tabler/icons-react"
import { getError } from '../../utils'
import { useModals } from '@mantine/modals'
import MTRTable from '../../components/table/MTRTable'
import { formatWari } from '../../helper'

export default function FrsPage() {
    const { getShop } = useAppState()
    const modals = useModals()
    const shopId = getShop.bo_id
    const query = useQueryClient()

    // ** DATAS ET MUTATIONS
    const { data: getShopExpenses = [], isLoading: isLoadingGetShopClients, isError } = useQuery(["depenses", shopId], ({ queryKey }) => getShopDepense(queryKey[1]))
    const { mutateAsync: addDepense, isError: isErrorCreateExpense, isLoading: isCreatingExpense } = useMutation(["depenses"], addShopDepense)
    const { mutateAsync: editDepense } = useMutation(["depenses"], editShopDepense)
    const { mutate: deleteDepense } = useMutation(["depenses"], removeShopDepense)
    const [validationErrors, setValidationErrors] = useState({})

    // ** REGISTERED OPERATION
    const handleCreateFrs = async ({ values, exitCreatingMode }) => {
        const errorsValidation = validateForm(values)
        if (Object.entries(errorsValidation).length !== 0) {
            setValidationErrors(errorsValidation)
            return
        }
        setValidationErrors({})
        await addDepense({
            depId: values.dep_id,
            motif: values.dep_motif,
            mte: values.dep_mte,
            bo_id: getShop.bo_id,
        }, {

            onSuccess: () => {
                query.invalidateQueries("depenses")
                exitCreatingMode()
            },
            onError: (err) => {
                const error = getError(err)
                if (error) setValidationErrors(prev => ({ ...prev, message: error }))
                exitCreatingMode();
            }
        })
    }
    const handleEditFrs = async ({ values, exitEditingMode }) => {
        setValidationErrors({})
        await editDepense({
            depId: values.dep_id,
            motif: values.dep_motif,
            mte: values.dep_mte,
            bo_id: getShop.bo_id,
        },
            {
                onSuccess: () => {
                    query.invalidateQueries("depenses")
                    exitEditingMode()
                },
                onError: (err) => {
                    const error = getError(err)
                    if (error) setValidationErrors(prev => ({ ...prev, message: error }))
                    exitEditingMode();
                }
            })
    }
    const handleDeleteFrs = async (row) =>
        modals.openConfirmModal({
            title: 'Suppression du fournisseur',
            children: (
                <Text>
                    Etes-vous sure de supprimer ? <br />
                    Cette action irreverssible .
                </Text>
            ),
            labels: { confirm: 'Supprimer', cancel: 'Annuler' },
            confirmProps: {
                color: 'red',
                children: 'Confirmer',
            },
            cancelProps: { children: 'Annuler' },
            onConfirm: () => deleteDepense(row.original.dep_id, {
                onSuccess: () => {
                    query.invalidateQueries("depenses")
                }
            }),
        });

    const isArr = Array.isArray(getShopExpenses)
    const total = useMemo(() => isArr && getShopExpenses.reduce((acc, curr) => acc + parseFloat(curr.dep_mte), 0), [isArr, getShopExpenses])

    const columns = useMemo(() => [
        {
            accessorFn: (originalRow) => originalRow.createdAt ? new Date(originalRow.createdAt)?.toLocaleString() : '',
            accessorKey: 'createdAt',
            header: 'Date',
            size: 20,
            enableEditing: false,
            mantineEditTextInputProps: {
                style: { display: 'none' }
            }
        },
        {
            accessorKey: 'dep_motif',
            header: 'Motif',
            mantineEditTextInputProps: {
                type: 'text',
                required: true,
                autoComplete: 'off',
                autoCorrect: 'off',
                error: validationErrors?.dep_motif,
                onFocus: () => setValidationErrors({ ...validationErrors, motif: undefined }),
            },
            size: 30
        },
        {
            accessorKey: 'dep_mte',
            header: 'Montant',
            mantineEditTextInputProps: {
                type: 'number',
                required: true,
                autoComplete: 'off',
                autoCorrect: 'off',
                error: validationErrors?.dep_mte,
                onFocus: () => setValidationErrors({ ...validationErrors, mte: 0 }),
            },
            size: 30,
            Footer: () => <Text color="green">Total :  {formatWari(total)}</Text>,
        },
    ], [validationErrors, total])

    return (
        <MTRTable
            uId='dep_id'
            columns={columns}
            data={getShopExpenses}
            createDisplayMode={'row'}
            editDisplayMode={'row'}
            onCreatingRowCancel={() => setValidationErrors({})}
            onEditingRowCancel={() => setValidationErrors({})}
            handleCreate={handleCreateFrs}
            handleEdit={handleEditFrs}
            hooksEditingOptions={{
                enableEditing: true,
                positionActionsColumn: 'last'
            }}
            renderRowActions={({ row, table }) => (
                <Flex gap="md">
                    <Tooltip label="Edit">
                        <ActionIcon onClick={() => table.setEditingRow(row)}>
                            <IconEdit />
                        </ActionIcon>
                    </Tooltip>
                    <Tooltip label="Delete">
                        <ActionIcon color="red" onClick={() => handleDeleteFrs(row)}>
                            <IconTrash />
                        </ActionIcon>
                    </Tooltip>
                </Flex>
            )}
            renderTopToolbarCustomActions={({ table }) => (
                <Group spacing={3}>
                    <Button onClick={() => table.setCreatingRow(true)}>
                        Ajouter une depense
                    </Button>
                </Group>
            )}
            visual={{
                dataLoader: isLoadingGetShopClients,
                dataError: isErrorCreateExpense || isError,
                editLoader: isCreatingExpense,
            }}
        />
    )
}

const validateForm = (values) => {
    let errors = {}
    if (!values.dep_motif) errors.dep_motif = 'Donner le motif du depense'
    else if (values.dep_motif.length > 300) errors.dep_motif = 'Motif 300 caracteres maximum'
    if (!values.dep_mte || parseFloat(values.dep_mte) < 0) errors.dep_mte = 'Montant invalide'
    return errors
}