import { useLocalStorage, useTimeout } from '@mantine/hooks'
import { useMultipleOnboardContext } from './context'
import { useCallback } from 'react'

export default function useOnboardModal() {
    const {
        state: { stepIndex },
        setState,
    } = useMultipleOnboardContext()

    const [userAgree] = useLocalStorage({ key: 'yy_start_tour' })

    const { start, clear } = useTimeout((loadAsIndex = 0) => {
        setState({ run: true, stepIndex: loadAsIndex })
    }, 1500)

    const autoLoadOnboard = useCallback(
        (loadAsIndex = 0, func = () => undefined) => {
            if (userAgree !== 'n' && stepIndex >= loadAsIndex) {
                func()
                start(loadAsIndex)
            }

            return () => {
                clear()
            }
        },
        [clear, start, stepIndex, userAgree],
    )

    // TODO : close function => like hide addProduct modal
    const closeOnboard = useCallback(
        (closeAsIndex = 0, modalInstance = null) => {
            if (userAgree !== 'n' && modalInstance !== null && stepIndex === closeAsIndex) {
                modalInstance.closeAll()
            }
        },
        [stepIndex, userAgree],
    )

    // TODO : block function => like add product to basket (is important to handle rest of operation)
    const blockOnboard = useCallback(
        (blockAsIndex = 0) => {
            if (userAgree !== 'n' && stepIndex === blockAsIndex) {
                start(blockAsIndex) // Exécutez start ici si la condition est remplie
            }

            return () => {
                clear()
            }
        },
        [clear, start, stepIndex, userAgree],
    )

    return {
        autoLoadOnboard,
        closeOnboard,
        blockOnboard,
        stepIndex,
        setState,
    }
}
