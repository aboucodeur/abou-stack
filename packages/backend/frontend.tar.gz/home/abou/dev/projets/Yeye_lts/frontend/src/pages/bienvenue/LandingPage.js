import { useEffect } from "react"
import { useLocation, useNavigate } from "react-router-dom"
import Cookies from "js-cookie"
import { decodeToken } from "react-jwt"
import { useAppState } from "../../context/AppContext"
import { AUTH_LOGIN, SHOP_GET, USER_LOGIN } from "../../context/action/action"
import { instance } from "../../axios"
import { redirectUser } from "../../utils"
import Login from "../auth/Login"

export default function LandingPage() {
    const { dispatch } = useAppState()
    const location = useLocation()
    const navigate = useNavigate()

    useEffect(() => {
        const getShopToken = Cookies.get("yy_shop_token")
        const getUserToken = Cookies.get("yy_user_token")
        if (getUserToken && getShopToken) {
            const decodedToken = decodeToken(getUserToken).users
            const parseShopDatas = JSON.parse(getShopToken)
            // ** verifcation du compte + verification du licence
            instance
                .post(`/users_auth/check`, { usId: decodedToken.us_id, boId: parseShopDatas.bo_id })
                .then(() => {
                    dispatch({ type: SHOP_GET, payload: { shops: { ...parseShopDatas } } })
                    dispatch({ type: USER_LOGIN, payload: { users: { ...decodedToken } } })
                    dispatch({ type: AUTH_LOGIN })
                    const origin = redirectUser(
                        location?.state?.from?.pathname,
                        decodedToken?.us_role,
                    )
                    navigate(origin)
                })
        }
    }, [location, dispatch, navigate])

    return (
        <div>
            <div className="annonce-login">
                <p>
                    Optimisez votre gestion de stock
                    <span role="img" aria-labelledby="star">
                        {" "}
                        🌟
                    </span>{" "}
                    <a href="https://yeye.onrender.com" target="_blank" rel="noreferrer">
                        Plus d'informations !
                    </a>
                </p>
            </div>
            <Login />
        </div>
    )
}
