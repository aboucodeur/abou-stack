import { useQuery } from "react-query"
import { Link } from "react-router-dom"
import { getAchatInfoReception } from "../../services/api"
import { Anchor, Badge } from "@mantine/core"
import { useAppState } from "../../context/AppContext"
import "dayjs/locale/fr"
import { MTRTable } from "../../components"
import { formatNumber } from "../../helper"

export default function AchatRecepPage() {
    const { getShop } = useAppState()
    const shopId = getShop.bo_id
    const { data: achatInfoRecep = [], isLoading, isFetching, isError } = useQuery(["achats_info_r", shopId], ({ queryKey }) => getAchatInfoReception(queryKey[1]))

    return (
        <MTRTable
            uId='ac_id'
            columns={[
                {
                    accessorKey: 'a_date',
                    accessorFn: (originalRow) => new Date(originalRow.a_date).toLocaleDateString(),
                    header: 'Date de reception',
                    enableGrouping: true,
                },
                {
                    accessorKey: 'total',
                    header: 'Qte totals',
                    enableGrouping: false,
                    Cell: ({ cell }) => formatNumber(cell.getValue()),
                },
                {
                    accessorKey: 'qte_rec',
                    header: 'Qte recue(s)',
                    enableGrouping: false,
                    Cell: ({ cell }) => formatNumber(cell.getValue()),
                },
                {
                    accessorKey: 'ret',
                    header: 'Qte retourne(s)',
                    enableGrouping: false,
                    Cell: ({ cell }) => formatNumber(cell.getValue()),

                },
                {
                    accessorKey: 'appr',
                    header: 'Etat',
                    enableGrouping: true,
                    Cell: ({ cell }) => {
                        return (
                            <Badge
                                color={cell.getValue() === 0 ? "red" : "green"}>
                                {cell.getValue() === 0 ? "Pas receptionner" : "Receptionner"}
                            </Badge>
                        )
                    },
                    size: 80
                },
            ]}
            data={achatInfoRecep}
            enableGrouping={true}
            initialState={{
                grouping: ['appr']
            }}
            hooksEditingOptions={{
                enableEditing: true,
                positionActionsColumn: 'last'
            }}
            enableColumnFilters={true}
            renderRowActions={({ row }) => {
                return <Anchor component={Link} to={`/commandes/fournisseurs/${row.original.ac_id}`}>
                    Details
                </Anchor>
            }}
            visual={{
                dataLoader: isLoading,
                dataError: isError,
                dataFetching: isFetching,
            }}
        />
    )
}
