import useForm from "../../hooks/useForm"
import { Stepper, TextInput, PasswordInput, Button, Title, Notification } from "@mantine/core"
import { createUserAccount } from '../../services/api'
import { useMutation, useQueryClient } from "react-query"
import { getError } from '../../utils'

export default function AddUserPage() {
    const { formValues, formErr, handleChange, setValues, setErrors, cleanForm } = useForm({
        us_prenom: "",
        us_nom: "",
        us_tel: "",
        us_email: "",
        us_pass: "",
        bo_nom: "",
        bo_tel: "",
        bo_adr: "",
        bo_email: "",
        active: 0,
    })
    const query = useQueryClient()
    const { mutate } = useMutation(["user"], createUserAccount)

    const firstSubmit = (e) => {
        e.preventDefault()
        if (formValues.active === 1) return
        setValues("active", 1)
    }
    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ ...formValues }, {
            onSuccess() {
                query.invalidateQueries("user")
                cleanForm()
                setValues("active", 2)
            },
            onError(err) {
                const error = getError(err)
                setErrors("message", error)
                setValues("active", 0)
            }
        })
    }

    return (
        <div>
            <Title order={4}>Creation de compte</Title>
            {formErr.message && <Notification m={5} color="red" onClose={() => setErrors("message", "")} title="Notification">{formErr.message}</Notification>}
            <Stepper active={formValues.active} onStepClick={(index) => setValues("active", index)}>
                <Stepper.Step label="Creation de l'utilisateur">
                    <form onSubmit={firstSubmit}>
                        <TextInput
                            label="Prenom"
                            maxLength={60}
                            autoComplete="off"
                            autoCorrect="off"
                            name="us_prenom"
                            description="Lettres et chiffres avec (_ et espace)"
                            value={formValues.us_prenom}
                            onChange={handleChange}
                            placeholder="Prenom"
                            required
                            error={formErr.prenom}
                            autoFocus
                        />
                        <TextInput
                            label="Nom"
                            maxLength={30}
                            autoComplete="off"
                            autoCorrect="off"
                            name="us_nom"
                            value={formValues.us_nom}
                            onChange={handleChange}
                            placeholder="Nom"
                            required
                        />
                        <TextInput
                            label="Email"
                            type="email"
                            autoComplete="off"
                            autoCorrect="off"
                            name="us_email"
                            value={formValues.us_email}
                            onChange={handleChange}
                            placeholder="Email"
                            required
                        />
                        <PasswordInput
                            label="Mot de passe"
                            name="us_pass"
                            value={formValues.us_pass}
                            onChange={handleChange}
                            placeholder="Mot de passe"
                            required
                            error={formErr.pass}
                        />

                        <TextInput
                            type="tel"
                            label="Telephone"
                            maxLength={21}
                            name="us_tel"
                            autoComplete="off"
                            autoCorrect="off"
                            value={formValues.us_tel}
                            onChange={handleChange}
                            placeholder="Telephone"
                            required
                        />
                        <Button type="submit" mt={5}>Passer à l'etape suivante</Button>
                    </form>
                </Stepper.Step>
                <Stepper.Step label="Nom de l'entreprise">
                    <form onSubmit={handleSubmit}>
                        <TextInput
                            label="Nom de l'entreprise"
                            maxLength={190}
                            autoComplete="off"
                            autoCorrect="off"
                            name="bo_nom"
                            value={formValues.bo_nom}
                            onChange={handleChange}
                            required
                            autoFocus
                        />
                        <TextInput
                            label="Numero de telephone"
                            maxLength={21}
                            type="tel"
                            autoComplete="off"
                            autoCorrect="off"
                            name="bo_tel"
                            value={formValues.bo_tel}
                            onChange={handleChange}
                            required
                        />
                        <TextInput
                            label="Email"
                            type="email"
                            autoComplete="off"
                            autoCorrect="off"
                            name="bo_email"
                            value={formValues.bo_email}
                            onChange={handleChange}
                            required
                        />
                        <TextInput
                            label="Addresse de la boutique"
                            autoComplete="off"
                            autoCorrect="off"
                            name="bo_adr"
                            value={formValues.bo_adr}
                            onChange={handleChange}
                            required
                        />
                        <Button mt={5} type="submit">Creer le compte</Button>
                    </form>
                </Stepper.Step>
                <Stepper.Completed>
                    <Title align="center" m={5} order={3}>Bravo, compte utilisateur crée avec success</Title>
                </Stepper.Completed>
            </Stepper>
        </div>
    )
}