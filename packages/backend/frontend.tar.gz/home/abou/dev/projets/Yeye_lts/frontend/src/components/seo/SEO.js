import { memo } from "react"
import { Helmet } from "react-helmet-async"
const SEO = memo(({ title, description, type, name }) => {
    return (
        <Helmet>
            <title>{title}</title>
            <meta name='description' content={description} />
            <meta property="og:type" content={type} />
            <meta property="og:title" content={title} />
            <meta property="og:description" content={description} />
            <meta property="og:site_name" content="Yeye | Stock & Entreprise" />
            <meta property="og:image" content="https://www.ultra-glk.com/logo512.png" />
            <meta property="og:url" content="https://www.ultra-glk.com/" />
            <meta name="twitter:creator" content={name} />
            <meta name="twitter:card" content={type} />
            <meta name="twitter:title" content={title} />
            <meta name="twitter:description" content={description} />
        </Helmet>
    )
})
export default SEO