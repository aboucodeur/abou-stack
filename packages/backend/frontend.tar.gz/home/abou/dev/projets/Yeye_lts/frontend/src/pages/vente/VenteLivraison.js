import { useState } from 'react'
import { Anchor, Button, Card, Grid, Group, List, NumberInput, Text } from '@mantine/core'
import { modals } from "@mantine/modals"
import { addVendreLivraison, addVendreLivraisonContenu, addVendreLivraisonFull, editVendreLivraisonContenu, getVendreLivraison, getVendreLivraisonContenu } from '../../services/api'
import { useMutation, useQuery, useQueryClient } from 'react-query'
import { getError } from '../../utils'
import useForm from '../../hooks/useForm'
import { IconCheck, IconInfoCircle, IconPencil, IconPrinter } from '@tabler/icons-react'
import { AppTable } from '../../components'
import { API_URL } from '../../constant'

export default function VenteLivraison({ vendId, vendreInfo }) {
    const [viewTable, setViewTable] = useState({ isView: false, data: {}, isEdit: false })
    const [rowsId, setRowsId] = useState(null)
    const { formValues, setValues, cleanForm } = useForm({ qte: 0 })
    const query = useQueryClient()

    const { data: venteLivraison = [] } = useQuery(["vendres_lid", vendId], ({ queryKey }) => getVendreLivraison(queryKey[1]))
    const { data: vendreLivraisonContenu = [] } = useQuery(["vendres_lic", viewTable.data.li_id], ({ queryKey }) => getVendreLivraisonContenu(queryKey[1]))
    const { mutate: addLivraison } = useMutation(["vendres_recd"], addVendreLivraison)
    const { mutate: addLivraisonContenu } = useMutation(["vendres_lic"], addVendreLivraisonContenu)
    const { mutate: addLivraisonFull } = useMutation(["vendres_recf"], addVendreLivraisonFull)
    const { mutate } = useMutation(["vendres_lic"], editVendreLivraisonContenu)

    const handleClick = (id) => {
        addLivraison({ date: new Date().toISOString(), vendId: id }, {
            onSuccess: () => query.invalidateQueries("vendres_lid"),
            onError(err) {
                const error = getError(err)
                if (error) {
                    modals.open({
                        title: "Notification",

                        children: error,
                    })
                }
            }
        })
    }
    const handlePlaceContent = (id) => {
        if (viewTable.isView) return
        addLivraisonContenu(id, { onSuccess() { query.invalidateQueries("vendres_lic") } })
    }
    const handleEdit = (id) => {
        mutate({ ...formValues, lcId: id }, {
            onSuccess() {
                query.invalidateQueries("vendres_lic")
                query.invalidateQueries("vendres_info")
                query.invalidateQueries("vendres_cmd")
                setRowsId(null)
                cleanForm()
            },
            onError(err) {
                const error = getError(err)
                if (error) setRowsId(null)
            }
        })
    }
    const handleFullLivraison = (id) => {
        addLivraisonFull(id, {
            onSuccess: () => {
                query.invalidateQueries("vendres_lic")
                query.invalidateQueries("vendres_info")
                query.invalidateQueries("vendres_cmd")
                setRowsId(null)
                cleanForm()
            },
            onError: (err) => {
                const error = getError(err)
                if (error) modals.open({
                    title: "Notifications",

                    children: <Text>{error}</Text>
                })
            }
        })
    }

    const tableRows = vendreLivraisonContenu.map(d => (
        <tr key={d.lc_id}>
            <td><Text>{d.pr_nom}</Text></td>
            <td>{d.lc_id === rowsId ?
                <NumberInput
                    autoComplete="off"
                    autoCorrect="off"
                    max={d.reste_reel}
                    min={0}
                    value={formValues.qte}
                    onChange={value => setValues("qte", value)}
                /> : <Text>{d.lc_qte}</Text>}
            </td>
            <td>{<Text color="red">{parseInt(d.reste_reel, 10)}</Text>}</td>
            <td>
                {d.lc_id === rowsId ?
                    <Button
                        onClick={() => handleEdit(d.lc_id)} color="green"
                        children={<IconCheck size={21} />}
                    /> :
                    <Button
                        disabled={parseInt(d.reste_reel, 10) === 0}
                        onClick={() => {
                            setRowsId(d.lc_id)
                            setValues("qte", parseInt(d.lc_qte, 10))
                        }}
                        children={<IconPencil size={21} />}
                    />
                }
            </td>
        </tr>
    ))

    return (
        <Grid columns={30}>
            <Grid.Col md={6}>
                <Card direction="column" shadow="lg" sx={theme => ({ backgroundColor: theme.colors.blue[2], color: "white", width: "100%" })}>
                    {vendreInfo.vend_etat > 0 && vendreInfo.vend_etat < 3 &&
                        <Button variant="white" onClick={() => handleClick(vendId)}>+</Button>
                    }
                    <Text weight="bold" mt={5} order={4}>Dates</Text>
                    <List listStyleType="none">
                        {venteLivraison.map(d => (
                            <List.Item key={d.li_id}>
                                <Anchor onClick={() => {
                                    setViewTable(prevData => ({ ...prevData, isView: true, data: { ...d } }))
                                    handlePlaceContent(d.li_id)
                                }}>{new Date(d.li_date).toLocaleDateString()}</Anchor>
                            </List.Item>
                        ))}
                    </List>
                </Card>
            </Grid.Col>
            <Grid.Col md={24}>
                {viewTable.isView ?
                    <div>
                        <Group spacing={5}>
                            {vendreInfo.vend_etat > 0 && !vendreInfo.is_liv
                                ? <Button onClick={() => handleFullLivraison(viewTable.data.li_id)}>Tout Livrer</Button>
                                : <Group spacing={3}>
                                    <IconInfoCircle />
                                    <Text>Livraison complete de la vente effectuer</Text>
                                </Group>
                            }
                            {viewTable.data.li_id && vendreInfo.vend_etat > 0
                                ? <Button
                                    variant="white"
                                    component={Anchor}
                                    href={`${API_URL}/documents/vendre/bord/${viewTable.data.li_id}`}
                                    target="_blank"
                                    // fullWidth
                                    color="orange"
                                >
                                    <IconPrinter />
                                    {" "}
                                    Bordereau
                                </Button>
                                : null
                            }
                        </Group>
                        <AppTable
                            title={`Livraison du ${new Date(viewTable.data.li_date).toLocaleDateString()}`}
                            tableHead={["Designation", "Livrer", "Reste", "Action"]}
                            tableRows={tableRows}
                        />
                    </div>
                    : null}
            </Grid.Col>
        </Grid>
    )
}