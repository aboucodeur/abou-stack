import { Badge, Button, Group, Text, TextInput, Tooltip, UnstyledButton } from "@mantine/core"
import { IconEdit, IconSearch } from "@tabler/icons-react"
import { modals } from "@mantine/modals"
import { useQuery } from "react-query"
import { toLower } from "../../utils"
import useSearch from "../../hooks/useSearch"
import { AppTable } from "../../components"
import { useAppState } from "../../context/AppContext"
import { getShopUser } from "../../services/api"
import AddGerant from "./AddGerant"
import EditGerant from "./EditGerant"

export default function GerantList() {
    const { getShop } = useAppState()
    const shopId = getShop.bo_id

    const { searchVal, handleSearch, getSearchProps } = useSearch({ term: "" })
    const { data: getShopGerant = [] } = useQuery(["ger", shopId], ({ queryKey }) => getShopUser(queryKey[1]))

    const addModal = () => {
        modals.open({
            title: "Ajouter un gerant",
            children: <AddGerant boId={shopId} handleClose={() => modals.closeAll()} />,
        })
    }
    const editModal = (data) => {
        modals.open({
            title: "Modification",
            children: <EditGerant data={data} handleClose={() => modals.closeAll()} />,
        })
    }
    const searchFilter = (data) => {
        const { us_prenom, us_nom } = data
        const username = us_prenom.concat(us_nom)
        if (!searchVal.term) return data
        if (us_prenom && us_nom && toLower(username).includes(toLower(searchVal.term).split(" ").join("").trim())) return data
    }
    const rows = Array.isArray(getShopGerant) && getShopGerant
        .filter(searchFilter)
        .map((d, _idx) => (
            <tr key={d.us_id}>
                <td><Text>{(_idx + 1)}</Text></td>
                <td><Text>{d.us_prenom}</Text></td>
                <td><Text>{d.us_nom}</Text></td>
                <td><Text>{d.us_tel}</Text></td>
                <td><Text><Badge>{d.us_email}</Badge></Text></td>
                <td><Text color={d.disabled ? "red" : "green"}>{d.disabled ? "Desactiver" : "Activer"}</Text></td>
                <td>
                    <Tooltip label="Modifier" withArrow>
                        <UnstyledButton onClick={() => editModal({ ...d })}><IconEdit size={21} color="blue" /></UnstyledButton>
                    </Tooltip>
                </td>
            </tr>
        ))

    return (
        <div>
            <Group m={5} spacing={3}>
                <TextInput
                    placeholder="Rechercher ici"
                    icon={<IconSearch size={21} />}
                    autoComplete="off"
                    autoCorrect="off"
                    {...getSearchProps("term")}
                    onChange={handleSearch}
                />
                <Button onClick={() => addModal()}>Ajouter un gerant</Button>
            </Group>
            <AppTable
                title={`Gerants de la boutique : ${getShopGerant.length}`}
                tableHead={["N°", "Prenom", "Nom", "Telephone", "Email", "Etat", "Action"]}
                tableRows={rows}
            />
        </div>
    )
}