import React from 'react'
import { DatePickerInput } from "@mantine/dates"
import { Anchor, Button, Divider, Group, Loader, Paper, Text, Title } from '@mantine/core'
import useSearch from '../../hooks/useSearch'
import { pgDate } from '../../utils'
import { useQuery } from 'react-query'
import { caisseDetail } from '../../services/api'
import { IconPrinter } from '@tabler/icons-react'
import { API_URL } from '../../constant'
import { formatNumber } from '../../helper'

const CaisseGrid = ({ title, num = 0, tProps, gProps, nProps }) => {
    return (
        <Group position="apart" {...gProps}>
            <Text {...tProps}>{title}</Text>
            <Text {...nProps}>{formatNumber(num, false)}</Text>
        </Group >
    )
}

export default function Caisse({ boId, handleClose }) {
    const { searchVal, getSearchProps, setSearch } = useSearch({ d1: null, d2: null })
    const { d1, d2, tra_type } = searchVal
    const date1 = pgDate(d1) || ''
    const date2 = pgDate(d2) || ''
    const { data, isLoading } = useQuery(
        ["act_detail", date1, date2, tra_type],
        ({ queryKey }) => caisseDetail(boId, queryKey[1], queryKey[2], queryKey[3])
    )
    // ** constructions fiable de l'url
    const URL_PARAMS = new URLSearchParams({ d1: date1, d2: date2, action: 'p' }).toString()

    if (isLoading) return (
        <div>
            <Text>Chargement en cours ...</Text>
            <Loader />
        </div>
    )
    return (
        <div>
            <Text color="dimmed">Recherche de date ici</Text>
            <Group spacing={3}>
                <DatePickerInput
                    // label="Date debut"
                    placeholder='Date debut ici'
                    locale='fr'

                    {...getSearchProps("d1")}
                    onChange={(value) => setSearch('d1', value)}
                    style={{ flex: 1 }}
                    clearable
                />
                <DatePickerInput
                    // label="Date fin"

                    placeholder='Date fin ici'
                    locale='fr'
                    {...getSearchProps("d2")}
                    onChange={(value) => setSearch('d2', value)}
                    style={{ flex: 1 }}
                    clearable
                />
            </Group>
            <Paper shadow="lg" p="md" mt={5} withBorder>
                <Title order={4} align="center">
                    Caisses
                    {d1 ? ' du ' + d1.toLocaleDateString() : ''}
                    {d2 ? ' au ' + d2.toLocaleDateString() : ''}
                </Title>
                <CaisseGrid
                    title="Fond de demerrage (Boutiques)"
                    num={data.compte.solde}
                    nProps={{ color: "blue", weight: "bold" }}// infos: {
                />
                <Divider />
                <CaisseGrid
                    title="Paiements clients"
                    num={data.vente}
                />
                <Divider />
                <CaisseGrid
                    title="Depots actionnaire"
                    num={data.compte.depots}
                />
                <Divider />
                <CaisseGrid
                    title="Retrait actionnaire"
                    num={data.compte.retraits}
                />
                <Divider />
                <CaisseGrid
                    title="Paiements fournisseurs"
                    num={data.achat}
                />
                <Divider />
                <CaisseGrid
                    title="Depenses"
                    num={data.depense}
                />
                <Divider />
                <Group position="apart">
                    <Text weight="bold">Caisse</Text>
                    <Text weight="bold" color="blue">{formatNumber(data.caisse, false)} F</Text>
                </Group>
            </Paper>
            <Button
                children={<IconPrinter />}
                component={Anchor}
                href={`${API_URL}/banques/caisse/${boId}?${URL_PARAMS}`}

                target="_blank"
                color="green"
                fullWidth
                mt={5}
            />
            <Button
                fullWidth color="orange"
                mt={5}
                onClick={handleClose}>
                Fermer la caisse
            </Button>
        </div >
    )
}