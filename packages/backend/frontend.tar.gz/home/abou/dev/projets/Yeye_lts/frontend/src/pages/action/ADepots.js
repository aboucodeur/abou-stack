import React from 'react'
import useForm from '../../hooks/useForm'
import { useMutation, useQueryClient } from 'react-query'
import { Button, Group, Notification, NumberInput } from '@mantine/core'
import { IconCash } from '@tabler/icons-react'
import { depotBanque } from '../../services/api'
import { getError } from '../../utils'

export default function ADepots({ coId, closeModal }) {
    const { formValues, formErr, setValues, cleanForm, setErrors } = useForm({ mte: 0 })
    const { mutate } = useMutation(["act_detail"], depotBanque)
    const query = useQueryClient()

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ ...formValues, co_id: coId }, {
            onSuccess() {
                query.invalidateQueries("act_detail")
                closeModal()
                cleanForm()
            },
            onError: (err) => {
                const error = getError(err)
                if (error) setErrors("message", error)
            }
        })
    }

    return (
        <div>
            {formErr.message ? <Notification color="red" onClose={() => setErrors("message", "")}>{formErr.message}</Notification> : null}
            <form onSubmit={handleSubmit}>
                <Group spacing={3} mt={5}>
                    <NumberInput
                        min={1}
                        placeholder="Montant"
                        autoComplete="off"
                        autoCorrect="off"
                        value={formValues.mte}
                        onChange={(value) => setValues("mte", value)}
                        maxLength={20}
                        icon={<IconCash />}
                        required
                        style={{ width: "100%" }}
                        precision={2}
                    />
                </Group>
                <Button fullWidth mt={10} color="green" type="submit">Valider</Button>
            </form>
        </div>
    )
}