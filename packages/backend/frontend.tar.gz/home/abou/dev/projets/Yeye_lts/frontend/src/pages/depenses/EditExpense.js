import React from 'react'
import { Alert, Button, Textarea, TextInput, Title } from '@mantine/core'
import useForm from '../../hooks/useForm'
import { useMutation, useQueryClient } from 'react-query'
import { editShopDepense } from '../../services/api'
import { getError } from '../../utils'

export default function EditExpense({ data, handleClose }) {
    const { formValues, handleChange, formErr, setValues, setErrors, cleanForm, getInputProps } = useForm({ mte: "", motif: "" })
    const query = useQueryClient()
    const { mutate } = useMutation(["depenses"], editShopDepense)

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ ...formValues, depId: data.dep_id }, {
            onSuccess: () => {
                query.invalidateQueries("depenses")
                cleanForm()
                handleClose()
            },
            onError: (err) => {
                const error = getError(err)
                if (error) setErrors("message", error)
            }
        })
    }

    React.useEffect(() => {
        setValues("mte", data.dep_mte)
        setValues("motif", data.dep_motif)
    }, [data, setValues])

    return (
        <div>
            {formErr.message && <Alert color="red" title={<Title order={4}>Erreur</Title>}>{formErr.message}</Alert>}
            <form onSubmit={handleSubmit}>
                <TextInput
                    label="Montant"
                    placeholder="le montant du depense"
                    autoComplete="off"
                    autoCorrect="off"
                    name="mte"
                    required
                    {...getInputProps("mte")}
                    onChange={handleChange}
                />
                <Textarea
                    spellCheck={false}
                    label="Motif"
                    placeholder="la description du depense"
                    autoComplete="off"
                    autoCorrect="off"
                    name="motif"
                    required
                    {...getInputProps("motif")}
                    onChange={handleChange}
                />
                <Button mt={5} type="submit">Ajouter</Button>
            </form>
        </div>
    )
}