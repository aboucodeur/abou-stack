const months = [
    { label: "Janvier", value: 1 },
    { label: "Fervrier", value: 2 },
    { label: "Mars", value: 3 },
    { label: "Avril", value: 4 },
    { label: "Mai", value: 5 },
    { label: "Juin", value: 6 },
    { label: "Juillet", value: 7 },
    { label: "Août", value: 8 },
    { label: "Septembre", value: 9 },
    { label: "Octobre", value: 10 },
    { label: "Novembre", value: 11 },
    { label: "Decembre", value: 12 },
]

const Unity = [
    { label: "Boites", value: "boites" },
    { label: "Cartons", value: "cartons" },
    { label: "Colis", value: "colis" },
    { label: "Douzaines", value: "douzaines" },
    { label: "Grammes", value: "g" },
    { label: "Kilogrammes", value: "kg" },
    { label: "Litres", value: "litres" },
    { label: "Livres", value: "livres" },
    { label: "Metres", value: "metres" },
    { label: "Moulins", value: "moulins" },
    { label: "Pieces", value: "pieces" },
    { label: "Pieds", value: "pieds" },
    { label: "Plaquettes", value: "plaquettes" },
    { label: "Paquets", value: "paquets" },
    { label: "Plats", value: "plats" },
    { label: "Pouces", value: "pouces" },
    { label: "Rouleaux", value: "rouleaux" },
    { label: "Sachets", value: "sachets" },
    { label: "Unites", value: "unites" },
]

const Stats = [
    { label: "Journalière", value: 1 },
    { label: "Hebdomendaire", value: 2 },
    { label: "Mensuel", value: 3 },
    { label: "Trimestriel", value: 4 },
    { label: "Annuel", value: 5 }
]

const frenchDays = [
    'Dimanche',
    'Lundi',
    'Mardi',
    'Mercredi',
    'Jeudi',
    'Vendredi',
    'Samedi',
]

export { months, Unity, Stats, frenchDays }