import { useMemo, useState } from 'react'
import { useAppState } from '../../context/AppContext'
import { Button, ActionIcon, Flex, Tooltip, Text, Group, Badge, Anchor } from '@mantine/core'
import { useMutation, useQuery, useQueryClient } from "react-query"
import { addShopClient, editShopClient, getShopClient, removeShopClient } from '../../services/api'
import { IconEdit, IconTrash } from "@tabler/icons-react"
import { getError } from '../../utils'
import { useModals } from '@mantine/modals'
import { NavLink } from 'react-router-dom'
import MTRTable from '../../components/table/MTRTable'

export default function ClientPage() {
    const { getShop } = useAppState()
    const modals = useModals()
    const shopId = getShop.bo_id
    const query = useQueryClient()

    // ** DATAS ET MUTATIONS
    const { data: getShopClients = [], isLoading: isLoadingGetShopClients, isError } = useQuery(["clt", shopId], ({ queryKey }) => getShopClient(queryKey[1]))
    const { mutateAsync: createClient, isError: isErrorCreateClient, isLoading: isCreatingClient } = useMutation(["clt"], addShopClient)
    const { mutateAsync: editClient } = useMutation(["clt"], editShopClient)
    const { mutate: deleteClient } = useMutation(["clt"], removeShopClient)
    const [validationErrors, setValidationErrors] = useState({})

    // ** REGISTERED OPERATION
    const handleCreateClient = async ({ values, exitCreatingMode }) => {
        const errorsValidation = validateForm(values)
        if (Object.entries(errorsValidation).length !== 0) {
            setValidationErrors(errorsValidation)
            return
        }
        setValidationErrors({})
        await createClient({
            nom: values?.cl_nom.trim(),
            adr: values?.cl_adr,
            tel: values?.cl_tel,
            bo_id: shopId,
        }, {

            onSuccess: () => {
                query.invalidateQueries("clt")
                query.invalidateQueries("clt_adapt")
                exitCreatingMode()
            },
            onError: (err) => {
                const error = getError(err)
                if (error) setValidationErrors(prev => ({ ...prev, message: error }))
                exitCreatingMode();
            }
        })
    }
    const handleEditClient = async ({ values, exitEditingMode }) => {
        setValidationErrors({})
        await editClient({
            clId: values?.cl_id,
            nom: values?.cl_nom.trim(),
            adr: values?.cl_adr,
            tel: values?.cl_tel,
        },
            {
                onSuccess: () => {
                    query.invalidateQueries("clt")
                    query.invalidateQueries("clt_adapt")
                    exitEditingMode()
                },
                onError: (err) => {
                    const error = getError(err)
                    if (error) setValidationErrors(prev => ({ ...prev, message: error }))
                    exitEditingMode();
                }
            })
    }
    const handleDeleteClient = async (row) =>
        modals.openConfirmModal({
            title: 'Suppression du client',
            children: (
                <Text>
                    Etes-vous sure de supprimer  {row.original.cl_nom} ? . <br />
                    Cette action irreverssible .
                </Text>
            ),
            labels: { confirm: 'Supprimer', cancel: 'Annuler' },
            confirmProps: {
                color: !row.original.etat ? 'red' : 'blue',
                children: !row.original.etat ? 'Confirmer' : 'Restaurer',
            },
            cancelProps: { children: 'Annuler' },
            onConfirm: () => deleteClient({
                clId: row.original.cl_id,
                type: row.original.etat === true ? 'act' : 'des'
            }, {
                onSuccess: () => {
                    query.invalidateQueries("clt")
                    query.invalidateQueries("clt_adapt")
                }
            }),
        });

    const columns = useMemo(() => [
        {
            accessorFn: (originalRow) => (originalRow.etat ? 'true' : 'false'),
            id: 'etat',
            header: 'Etat de compte',
            filterVariant: 'checkbox',
            Cell: ({ cell }) => cell.getValue() === 'true'
                ? <Badge color="red">Supprimer</Badge>
                : <Badge>Nom supprimer</Badge>,
            size: 20,
            enableEditing: false,
            mantineEditTextInputProps: {
                style: { display: 'none' }
            }
        },
        {
            accessorKey: 'cl_nom',
            header: 'Nom complet',
            mantineEditTextInputProps: {
                type: 'text',
                required: true,
                autoComplete: 'off',
                autoCorrect: 'off',
                error: validationErrors?.cl_nom,
                onFocus: () => setValidationErrors({ ...validationErrors, cl_nom: undefined }),
            },
            size: 30
        },
        {
            accessorKey: 'cl_tel',
            header: 'Telephone',
            mantineEditTextInputProps: {
                type: 'tel',
                required: true,
                autoComplete: 'off',
                autoCorrect: 'off',
                error: validationErrors?.cl_tel,
                onFocus: () => setValidationErrors({ ...validationErrors, cl_tel: undefined }),
            },
            size: 30
        },
        {
            accessorKey: 'cl_adr',
            header: 'Adresse',
            mantineEditTextInputProps: {
                type: 'textarea',
                required: true,
                spellCheck: false,
                autoComplete: 'off',
                autoCorrect: 'off',
                error: validationErrors?.cl_adr,
                onFocus: () => setValidationErrors({ ...validationErrors, cl_adr: undefined }),
            },
            size: 30
        },
        {
            accessorKey: 'vend',
            header: 'Nb vente(s)',
            enableEditing: false,
            mantineEditTextInputProps: {
                style: { display: 'none' }
            }
        }
    ], [validationErrors])

    return (
        <MTRTable
            uId='cl_id'
            columns={columns}
            data={getShopClients}
            createDisplayMode={'row'}
            editDisplayMode={'row'}
            validationErrors={validationErrors}
            setValidationErrors={setValidationErrors}
            hooksEditingOptions={{
                enableEditing: true,
                positionActionsColumn: 'last'
            }}
            handleCreate={handleCreateClient}
            handleEdit={handleEditClient}
            onCreatingRowCancel={() => setValidationErrors({})}
            onEditingRowCancel={() => setValidationErrors({})}
            renderRowActions={({ row, table }) => (
            <Flex gap="md">
                <Tooltip label="Details">
                    <Anchor component={NavLink} to={`/clients/${row.original.cl_id}`}>Details</Anchor>
                </Tooltip>
                <Tooltip label="Edit">
                    <ActionIcon onClick={() => table.setEditingRow(row)}>
                        <IconEdit />
                    </ActionIcon>
                </Tooltip>
                <Tooltip label="Delete">
                    <ActionIcon color="red" onClick={() => handleDeleteClient(row)}>
                        <IconTrash />
                    </ActionIcon>
                </Tooltip>
            </Flex>
            )}
            renderTopToolbarCustomActions={({ table }) => (
            <Group spacing={3}>
                <Button onClick={() => table.setCreatingRow(true)}>
                        Ajouter un client
                </Button>
            </Group>
            )}
            visual={{
                dataLoader: isLoadingGetShopClients,
                dataError: isErrorCreateClient || isError,
                addLoader: isCreatingClient,
            }}
    />
    )
}

// ** validation 
const validateForm = (values) => {
    let errors = {}
    if (!values.cl_nom) errors.cl_nom = 'Nom client obligatoire'
    else if (values.cl_nom.length > 100) errors.cl_nom = 'Nom 100 caracteres maximum'

    if (!values.cl_tel) errors.cl_tel = 'Telephone obligatoire'
    else if (values.cl_tel.length > 60) errors.cl_nom = 'Telephone 100 caracteres maximum'

    if (!values.cl_adr) errors.cl_adr = 'Adresse obligatoire'
    else if (values.cl_adr.length > 300) errors.cl_nom = 'Adresse 300 caracteres maximum'

    return errors
}