import { useState } from "react"
import {
    Button,
    Divider,
    Group,
    Tabs,
    TextInput,
    Grid,
    Loader,
    Anchor,
    Badge,
    Text,
    Tooltip,
    Flex,
    ActionIcon,
} from "@mantine/core"
import { Link } from "react-router-dom"
import { modals } from "@mantine/modals"
import { IconEdit, IconReceipt, IconSearch, IconTrash } from "@tabler/icons-react"
import AddDeposit from "./AddDeposit"
import Stock from "../acceuil/Stock"
import { useAppState } from "../../context/AppContext"
import { useMutation, useQuery, useQueryClient } from "react-query"
import { getDepotProduct, getShopDepots, removeProduct } from "../../services/api"
import useSearch from "../../hooks/useSearch"
import { toLower } from "../../utils"
import DeleteDeposit from "./DeleteDeposit"
import EditDeposit from "./EditDeposit"
import AddProduct from "./AddProduct"
import EditProduct from "./EditProduct"
import { AppTable, MTRTable } from "../../components"
import { API_URL } from "../../constant"
import useHeight from "../../hooks/useHeight"
// import ApprList from '../approvisions/ApprList'

export default function Deposit() {
    const { getShop } = useAppState()

    const shopId = getShop.bo_id
    const { searchVal, handleSearch, getSearchProps } = useSearch({ nom: "", produit: "" })
    const [oneDatas, setOneDatas] = useState({ view: false, data: {} })
    const { data: shopDeposit = [], isLoading } = useQuery(["dep", shopId], ({ queryKey }) =>
        getShopDepots(queryKey[1]),
    )
    const {
        data: depositProduct = [],
        isLoading: dProductLoading,
        isFetching: dProductFecthing,
        isError,
    } = useQuery(["prod", oneDatas.data.de_id], ({ queryKey }) => getDepotProduct(queryKey[1]))
    const { mutate } = useMutation(["prod"], removeProduct)
    const query = useQueryClient()

    const { wH } = useHeight(150)

    const addDeposit = () => {
        modals.open({
            title: "Nouveau depot",
            children: <AddDeposit boId={shopId} handleClose={() => modals.closeAll()} />,
        })
    }

    const editDepotModal = (data) => {
        modals.open({
            title: "Modification",
            children: <EditDeposit data={data} handleClose={() => modals.closeAll()} />,
        })
    }

    const removeDepositModal = (data) => {
        modals.open({
            title: "Suppression",
            children: <DeleteDeposit data={data} handleClose={() => modals.closeAll()} />,
        })
    }

    const handleAddProduct = () => {
        modals.open({
            title: "Nouveau produit",
            children: (
                <AddProduct
                    deId={oneDatas.data.de_id}
                    boId={shopId}
                    isStock={false}
                    handleClose={() => modals.closeAll()}
                />
            ),
        })
    }

    const handleEditProduct = (data) => {
        modals.open({
            title: "Modification",
            children: (
                <EditProduct
                    deId={oneDatas.data.de_id}
                    boId={shopId}
                    data={data}
                    handleClose={() => modals.closeAll()}
                />
            ),
        })
    }

    const handleRemove = (data) => {
        modals.openConfirmModal({
            title: "Etes vous sure de supprimer",
            children: `La suppression du produits est dangereux et peut entrainer la suppression d'autre 
            elements comme les achats et ventes du meme produits`,
            onConfirm: () => {
                mutate(data.pr_id, {
                    onSuccess() {
                        query.invalidateQueries("prod")
                        modals.closeAll()
                    },
                })
            },
            confirmProps: {
                color: "red",
            },
            cancelProps: {
                color: "orange",
            },
            labels: {
                confirm: "Oui, supprimer",
                cancel: "Annuler",
            },
        })
    }

    // MRT TABLE
    const columns = [
        {
            accessorKey: "pr_nom",
            header: "Produit(s)",
            szie: 120,
        },
        {
            accessorKey: "pr_unite",
            header: "Unite(s)",
            size: 90,
        },
        {
            accessorKey: "pr_qte",
            header: "Quantite(s)",
            size: 90,
        },
        {
            accessorKey: "pr_pa",
            header: "P. achat",
            size: 90,
        },
        {
            accessorKey: "pr_pv",
            header: "P. vente",
            size: 90,
        },
        // {
        //     accessorKey: "pr_code",
        //     header: "Code",
        //     size: 90,
        //     enableColumnFilter: false,
        //     enableSorting: false,
        // },
    ]

    const depositsRows = shopDeposit
        .filter((d) => toLower(d.de_nom).includes(toLower(searchVal.nom.trim())))
        .map((d) => (
            <tr key={d.de_id}>
                <td>
                    <Anchor
                        onClick={() =>
                            setOneDatas((prev) => ({ ...prev, view: true, data: { ...d } }))
                        }
                    >
                        {d.de_nom}
                    </Anchor>
                </td>
                <td>
                    <Flex gap="md">
                        <ActionIcon onClick={() => editDepotModal({ ...d })} color="orange">
                            <IconEdit />
                        </ActionIcon>
                        <ActionIcon onClick={() => removeDepositModal({ ...d })} color="red">
                            <IconTrash />
                        </ActionIcon>
                    </Flex>
                </td>
            </tr>
        ))

    return (
        <Tabs defaultValue="first">
            <Tabs.List m={5}>
                <Tabs.Tab value="first">Tous mes produits</Tabs.Tab>
                <Tabs.Tab value="second">
                    Par deptos <Badge size="md">{shopDeposit.length}</Badge>
                </Tabs.Tab>
                {/* <Tabs.Tab value="third">Approvisionnement</Tabs.Tab> */}
            </Tabs.List>
            <Tabs.Panel value="first">
                <Stock boId={shopId} />
            </Tabs.Panel>
            <Tabs.Panel value="second">
                <Group spacing={3} m={5} style={{ display: "flex", alignItems: "center" }}>
                    <Button onClick={addDeposit} color="green" variant="outline">
                        Ajouter un depot
                    </Button>
                    <Button component={Link} to="/depots/trash" color="red">
                        <IconTrash />
                    </Button>
                </Group>
                <Divider />
                <Grid mt={5} columns={10}>
                    <Grid.Col md={2}>
                        <TextInput
                            placeholder="Chercher un depot"
                            autoComplete="off"
                            autoCorrect="off"
                            icon={<IconSearch />}
                            {...getSearchProps("nom")}
                            onChange={handleSearch}
                        />
                        <Text weight="bold" mt={5}>
                            Depots : {shopDeposit.length}
                        </Text>
                        {isLoading ? (
                            <Loader />
                        ) : (
                            <AppTable tableRows={depositsRows} mw={34} h={350} />
                        )}
                    </Grid.Col>
                    <Grid.Col md={8}>
                        {oneDatas.view ? (
                            <MTRTable
                                uId="pr_id"
                                data={depositProduct}
                                hooksEditingOptions={{
                                    enableEditing: true,
                                    positionActionsColumn: "last",
                                }}
                                columns={columns}
                                maxH={`${wH}px`}
                                visual={{
                                    dataLoader: dProductLoading,
                                    dataError: isError,
                                    dataFetching: dProductFecthing,
                                }}
                                renderTopToolbarCustomActions={() => (
                                    <div>
                                        <Text mb={5}>Depots : {oneDatas.data.de_nom}</Text>
                                        <Group spacing={5}>
                                            <Button
                                                color="green"
                                                onClick={() => handleAddProduct()}
                                                variant="outline"
                                            >
                                                Nouveau produit
                                            </Button>
                                            <Tooltip withArrow label="Fiche d'inventaire du depot">
                                                <ActionIcon
                                                    component={Anchor}
                                                    href={`${API_URL}/documents/inventaire/${shopId}?n=${oneDatas.data.de_id}`}
                                                    target="_blank"
                                                    color="blue"
                                                >
                                                    <IconReceipt />
                                                </ActionIcon>
                                            </Tooltip>
                                        </Group>
                                    </div>
                                )}
                                renderRowActions={({ row }) => (
                                    <div>
                                        {!["transport", "reliquat"].includes(
                                            row.original.pr_nom.toLowerCase(),
                                        ) ? (
                                            <Group spacing={20}>
                                                <ActionIcon
                                                    color="orange"
                                                    onClick={() =>
                                                        handleEditProduct({ ...row.original })
                                                    }
                                                >
                                                    <IconEdit />
                                                </ActionIcon>
                                                <ActionIcon
                                                    color="red"
                                                    onClick={() =>
                                                        handleRemove({ ...row.original })
                                                    }
                                                >
                                                    <IconTrash />
                                                </ActionIcon>
                                            </Group>
                                        ) : (
                                            <Text color="red">Reserver</Text>
                                        )}
                                    </div>
                                )}
                            />
                        ) : null}
                    </Grid.Col>
                </Grid>
            </Tabs.Panel>
        </Tabs>
    )
}
