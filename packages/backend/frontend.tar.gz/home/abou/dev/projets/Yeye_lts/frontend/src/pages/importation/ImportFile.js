import { Box, Button, Notification, Select, Text } from "@mantine/core";
import { useMutation, useQuery, useQueryClient } from "react-query";
import useForm from "../../hooks/useForm";
import { getShopDepotAdaptSelect, importFileToDB } from "../../services/api";
import { getError } from "../../utils";

const MIMES_TYPES = {
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
};

export default function ImportFile({ boId, handleClose }) {
  const { data: shopDepot = [] } = useQuery(
    ["dep_adapt", boId],
    ({ queryKey }) => getShopDepotAdaptSelect(queryKey[1])
  );
  const { formValues, formErr, setValues, setErrors, cleanForm } = useForm({
    file: null,
    de_id: "",
  });
  const { mutate: excelImport } = useMutation(["excel"], importFileToDB);
  const query = useQueryClient();

  const handleUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const getExtension = MIMES_TYPES[file.type];
    if (!getExtension) setErrors("message", "fichier au format xlsx (excel)");
    else setValues("file", file);
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("bo_id", boId);
    formData.append("de_id", formValues.de_id);
    formData.append("file", formValues.file);
    if (Object.entries(formErr).length !== 0) return;
    excelImport(formData, {
      onSuccess: () => {
        query.invalidateQueries("stock_prev");
        cleanForm();
        handleClose();
      },
      onError: (err) => {
        const error = getError(err);
        if (error) setErrors("message", err);
      },
    });
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        {formErr.message && (
          <Notification
            color="red"
            mt={5}
            onClose={() => setErrors("message", "")}
          >
            {formErr.message}
          </Notification>
        )}
        <Select
          label="Choisir le magazin"
          data={shopDepot.filter((d) => !d.disabled)}
          placeholder="Donner un magazin"
          description="Insertion de plusieurs produits à la fois"
          required
          clearable
          searchable
          nothingFound="Magazin introuvable"
          onChange={(value) => value && setValues("de_id", value)}
        />
        <Text>Nom du produit , prix d'achat , prix de vente , unites</Text>
        <Box>
          <input
            type="file"
            id="import-excel"
            onChange={handleUpload}
            required
          />
        </Box>
        <Button fullWidth color="green" mt={15} type="submit">
          Valider
        </Button>
      </form>
    </div>
  );
}
