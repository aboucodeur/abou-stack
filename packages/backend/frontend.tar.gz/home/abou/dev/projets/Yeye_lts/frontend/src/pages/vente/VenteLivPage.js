import { useQuery } from "react-query"
import { Link } from "react-router-dom"
import { getVendreInfoLivraison } from "../../services/api"
import { Anchor, Badge } from "@mantine/core"
import { useAppState } from "../../context/AppContext"
import { MTRTable } from "../../components"
import "dayjs/locale/fr"
import { formatNumber } from "../../helper"

export default function VenteLivPage() {
    const { getShop } = useAppState()
    const shopId = getShop.bo_id
    const { data: venteInfoLiv = [], isLoading, isFetching, isError } = useQuery(["vendres_info_l", shopId], ({ queryKey }) => getVendreInfoLivraison(queryKey[1]))


    return (
        <MTRTable
            uId='vend_id'
            columns={[
                {
                    accessorKey: 'v_date',
                    accessorFn: (originalRow) => new Date(originalRow.v_date).toLocaleDateString(),
                    header: 'Date',
                    enableGrouping: true,
                },
                {
                    accessorKey: 'total',
                    header: 'Qte totals',
                    enableGrouping: false,
                    Cell: ({ cell }) => formatNumber(cell.getValue()),
                },
                {
                    accessorKey: 'qte_liv',
                    header: 'Qte Livré(s)',
                    enableGrouping: false,
                    Cell: ({ cell }) => formatNumber(cell.getValue()),
                },
                {
                    accessorKey: 'ret',
                    header: 'Qte retourne(s)',
                    enableGrouping: false,
                    Cell: ({ cell }) => formatNumber(cell.getValue()),
                },
                {
                    accessorKey: 'appr',
                    header: 'Etat',
                    Cell: ({ cell }) => {
                        return (
                            <Badge
                                color={cell.getValue() === 0 ? "red" : "green"}>
                                {cell.getValue() === 0 ? "Pas livrer" : "Livrer"}
                            </Badge>
                        )
                    }
                },
            ]}
            data={venteInfoLiv}
            enableGrouping={true}
            initialState={{
                grouping: ['appr']
            }}
            hooksEditingOptions={{
                enableEditing: true,
                positionActionsColumn: 'last'
            }}
            enableColumnFilters={true}
            renderRowActions={({ row }) => {
                return <Anchor component={Link} to={`/ventes/${row.original.vend_id}`}>
                    Details
                </Anchor>
            }}
            visual={{
                dataLoader: isLoading,
                dataError: isError,
                dataFetching: isFetching,
            }}
        />
    )
}
