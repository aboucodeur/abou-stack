import { Button } from "@mantine/core"
import { useMutation, useQueryClient } from 'react-query'
import { addApprovisionFull } from '../../services/api'

export default function ApprValidation({ apId, handleClose }) {
    const query = useQueryClient()
    const { mutate } = useMutation(["appr"], addApprovisionFull)
    const handleConfirm = (id) => {
        mutate(apId, {
            onSuccess() {
                query.invalidateQueries("appr_info")
                handleClose()
            }
        })
    }

    return <Button mt={5} color='green' fullWidth variant='outline' onClick={() => handleConfirm(apId)}>Oui, valider</Button>
}