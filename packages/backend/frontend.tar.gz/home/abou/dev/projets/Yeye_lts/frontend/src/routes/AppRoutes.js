import { Fragment, lazy, Suspense } from "react"
import { Outlet, Route, Routes } from "react-router-dom"
import AppLayout from "../components/layout/AppLayout"
import LandingPage from "../pages/bienvenue/LandingPage"
import Deposit from "../pages/depots/Deposit"
import FrsPage from "../pages/fournisseurs/FrsPage"
import PrivateRoutes from "./PrivateRoutes"
import ClientPage from "../pages/client/ClientPage"
import ShopPage from "../pages/moi/ShopPage"
import AchatDetails from "../pages/achats/AchatDetails"
import AchatPage from "../pages/achats/AchatPage"
import VenteDetails from "../pages/vente/VenteDetails"
import VentePage from "../pages/vente/VentePage"
import StockPage from "../pages/acceuil/StockPage"
import ApprList from "../pages/approvisions/ApprList"
import ApprovisionDetail from "../pages/approvisions/ApprovisionDetail"
import ClientDetails from "../pages/client/ClientDetails"
import IA from "../pages/ia/IA"
import NotFound from "../pages/NotFound"
import useGAnalytics from "../seo/useGAnalytics"
import SEO from "../components/seo/SEO"
import SingUp from "../pages/auth/SignUp"
import MultiRouteWrapper from "../onboard/MultiRoute/Wrapper"
// Lazy loading features not most used by user
const GerantList = lazy(() => import("../pages/gerants/GerantList"))
const ExpensePage = lazy(() => import("../pages/depenses/ExpensePage"))
const Investisseur = lazy(() => import("../pages/action/Investisseur"))
const Details = lazy(() => import("../pages/action/Details"))
const DepositTrash = lazy(() => import("../pages/depots/DepositTrash"))
const ChangePass = lazy(() => import("../pages/moi/ChangePass"))
// Admin
const AdminLanding = lazy(() => import("../pages/bienvenue/AdminLanding"))
const AddUserPage = lazy(() => import("../pages/admin/AddUserPage"))
const UserLists = lazy(() => import("../pages/admin/UserLists"))
const SingleUser = lazy(() => import("../pages/admin/SingleUser"))
const ChangeAdminPass = lazy(() => import("../pages/auth/ChangeAdminPass"))

const MySuspense = ({ text = "Patientez Yeye en cours de chargement ... ", children }) => (
    <Suspense fallback={<p>{text}</p>}>{children}</Suspense>
)

export default function AppRoutes() {
    useGAnalytics()

    return (
        <Fragment>
            <SEO
                title="Yeye | Stock & Entreprise"
                name="Aboubacar Barry" // createur de yeye
                type="webapp"
                description="Une application web innovante et conviviale conçue pour simplifier et accélérer la gestion de vos stocks !"
            />
            <Routes>
                {/* Wrapper pour verifier l'authentification */}
                <Route path="/">

                    {/* Public routes */}
                    <Route index element={<LandingPage />} />
                    <Route path="/signup" element={<SingUp />} />


                    {/* Admin only */}
                    <Route path="admin" element={<MySuspense children={<Outlet />} />}>
                        <Route index element={<AdminLanding />} />
                        <Route path="pass/recovery/confirm/:token" element={<ChangeAdminPass />} />
                        <Route
                            path="dashboard"
                            element={<PrivateRoutes roles={["admin"]} children={<AppLayout />} />}
                        >
                            <Route index element={<UserLists />} />
                            <Route path="user/add" element={<AddUserPage />} />
                            <Route path="user/lists" element={<UserLists />} />
                            <Route path="user/:boId/:id" element={<SingleUser />} />
                        </Route>
                    </Route>

                    {/* All user */}
                    <Route
                        element={<PrivateRoutes roles={["prop", "ger"]} children={<AppLayout />} />}
                    >
                        <Route path="ventes">
                            <Route index element={<VentePage />} />
                            <Route path=":id" element={<VenteDetails />} />
                        </Route>
                        <Route
                            path="moi/password"
                            element={<MySuspense children={<ChangePass />} />}
                        />
                    </Route>

                    {/* Prop only */}
                    <Route
                        element={
                            <PrivateRoutes
                                roles={["prop"]}
                                children={<AppLayout children={<MultiRouteWrapper />} />}
                            />
                        }
                    >
                        <Route path="acceuil" element={<StockPage />} />
                        <Route path="action">
                            <Route index element={<MySuspense children={<Investisseur />} />} />
                            <Route
                                path="detail/:coId"
                                element={<MySuspense children={<Details />} />}
                            />
                        </Route>
                        <Route path="ia" element={<IA />} />
                        <Route path="depots">
                            <Route index element={<Deposit />} />
                            <Route
                                path="trash"
                                element={<MySuspense children={<DepositTrash />} />}
                            />
                        </Route>
                        <Route path="fournisseurs" element={<FrsPage />} />
                        <Route path="commandes/fournisseurs">
                            <Route index element={<AchatPage />} />
                            <Route path=":id" element={<AchatDetails />} />
                        </Route>
                        <Route path="approvisions">
                            <Route index element={<ApprList />} />
                            <Route path=":id" element={<ApprovisionDetail />} />
                        </Route>
                        <Route path="gerants" element={<MySuspense children={<GerantList />} />} />
                        <Route path="clients">
                            <Route index element={<ClientPage />} />
                            <Route path=":id" element={<ClientDetails />} />
                        </Route>
                        <Route
                            path="depenses"
                            element={<MySuspense children={<ExpensePage />} />}
                        />
                        <Route path="moi/boutique" element={<ShopPage />} />
                    </Route>

                    <Route path="*" element={<NotFound />} />
                </Route>
            </Routes>
        </Fragment>
    )
}
