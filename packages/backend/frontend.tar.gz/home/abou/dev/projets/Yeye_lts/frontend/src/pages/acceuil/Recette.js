import { useMemo, useState } from 'react'
import { Anchor, Group, Loader, Text, Title } from '@mantine/core'
import { useQuery } from 'react-query'
import { getBoutiqueGlobal } from '../../services/api'
import { MTRTable } from '../../components'
import { formatNumber, formatWari } from '../../helper'

export default function Recette({ boId }) {
    const [pick, setPick] = useState(1)
    const { data, isLoading, isError } = useQuery(['global', boId, pick], ({ queryKey }) =>
        getBoutiqueGlobal(queryKey[1], queryKey[2]),
    )

    const userChoices = useMemo(
        () => [
            {
                value: 1,
                label: 'Journaliere',
            },
            {
                value: 2,
                label: 'Hebdomendaire',
            },
            {
                value: 3,
                label: 'Mensuel',
            },
            {
                value: 4,
                label: 'Semestriel',
            },
            {
                value: 5,
                label: 'Annuel',
            },
        ],
        [],
    )

    const isArr = Array.isArray(data)
    const total = useMemo(
        () => isArr && data.reduce((acc, curr) => acc + parseFloat(curr.ca), 0),
        [isArr, data],
    )
    const columns = useMemo(
        () => [
            {
                accessorKey: 'pr_nom',
                header: 'Produit',
                size: 30,
            },
            {
                accessorKey: 'ca',
                header: "Chiffres d'affaires",
                size: 30,
                Cell: ({ cell }) => formatNumber(cell.getValue()),
                Footer: () => (
                    <Text size={15} weight={900} color="green">
                        Totals : {formatWari(total)}
                    </Text>
                ),
            },
        ],
        [total],
    )

    if (isLoading) return <Loader />
    return (
        <MTRTable
            uId="pr_id"
            data={data}
            columns={columns}
            visual={{
                dataLoader: isLoading,
                dataError: isError,
            }}
            renderTopToolbarCustomActions={() => (
                <div>
                    <Title order={3}>Recette : {userChoices[pick - 1].label}</Title>
                    <Group>
                        {userChoices.map((choice) => (
                            <Anchor
                                key={choice.value}
                                onClick={() => {
                                    if (pick !== choice.value) setPick(choice.value)
                                }}
                            >
                                {choice.label}
                            </Anchor>
                        ))}
                    </Group>
                </div>
            )}
        />
    )
}
