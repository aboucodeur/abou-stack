import React, { useEffect } from 'react'
import {
    Anchor,
    Box,
    Button,
    Card,
    Checkbox,
    Divider,
    Grid,
    Group,
    Tabs,
    Text,
    TextInput,
    ScrollArea,
    Badge,
    Loader,
    Tooltip,
} from '@mantine/core'
import { IconArrowRight, IconPrinter, IconSearch } from '@tabler/icons-react'
import { modals } from '@mantine/modals'
import { useParams } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from 'react-query'
import {
    addAchatCommand,
    getAchat,
    getAchatCommand,
    getAchatPaiement,
    getAchatRuptureProduct,
} from '../../services/api'
import { API_URL } from '../../constant'
import { carsIcon, cashIcon, pannierIcon } from '../../constants'
import useSearch from '../../hooks/useSearch'
import { toLower } from '../../utils'
import { ImageIcon } from '../../components'
import AchatValidation from './AchatValidation'
import AchatContenu from './AchatContenu'
import AchatPaiement from './AchatPaiement'
import AchatReception from './AchatReception'
import AchatRetour from './AchatRetour'
import { formatWari } from '../../helper'
import useOnboardModal from '../../onboard/MultiRoute/useOnboardModal'
import { AUTO, BLOCK } from '../../onboard'
import { useState } from 'react'

const AchatDetails = React.memo(() => {
    const { id } = useParams()
    const acId = parseInt(id, 10)

    const { data: achatInfo = [], isLoading } = useQuery(['achats_info', acId], ({ queryKey }) =>
        getAchat(queryKey[1]),
    )
    const { data: achatCommand = [] } = useQuery(['achats_cmd', acId], ({ queryKey }) =>
        getAchatCommand(queryKey[1]),
    )
    const { data: achatPaiement = [] } = useQuery(['achats_pay', acId], ({ queryKey }) =>
        getAchatPaiement(queryKey[1]),
    )
    const { data: achatRuptureProduct = [] } = useQuery(['achats_prod', acId], ({ queryKey }) =>
        getAchatRuptureProduct(queryKey[1]),
    )

    const { mutate } = useMutation(['achats_cmd'], addAchatCommand)
    const { searchVal, getSearchProps, handleSearch } = useSearch({ nom: '' })
    const [active, setActive] = useState('first')

    const query = useQueryClient()
    const { blockOnboard, setState, stepIndex } = useOnboardModal()

    // ** 2 block one validation + two validation
    const handleBlock = blockOnboard(BLOCK.achat.validConfirm_17)

    const handleValidate = (acId, etat = '') => {
        modals.open({
            title: "Valider la commande d'achat",
            children: (
                <AchatValidation
                    acId={acId}
                    handleClose={() => modals.closeAll()}
                    etat={etat}
                    handleBlock={handleBlock}
                    setState={setState}
                />
            ),
        })
        // ** force user click
        setState({ run: true, stepIndex: 17 })
    }

    const handleClick = (data) => {
        const { pr_id, pr_pv } = data
        mutate(
            { pr_id, prix: pr_pv, qte: 1, acId },
            {
                onSuccess: () => {
                    query.invalidateQueries('achats_cmd')
                    query.invalidateQueries('achats_prod')
                },
            },
        )
    }

    const searchFilter = (data) => {
        const { pr_nom } = data
        if (!searchVal.nom) return data
        if (toLower(pr_nom).includes(toLower(searchVal.nom.trim()))) return data
    }

    // ** bloquer la validation (obligatoire)
    useEffect(() => {
        blockOnboard(BLOCK.achat.buttonAchatValid_16)
    }, [blockOnboard])

    // ** bloquer l'onglet de reception (obligatoire)
    useEffect(() => {
        if (stepIndex === AUTO.achat.receptionTab) setActive('third')
    }, [stepIndex])

    if (isLoading)
        return (
            <div>
                <Text>Patienter ...</Text>
                <Loader />
            </div>
        )

    const total = parseFloat(achatInfo.montant)
    const payer = parseFloat(achatInfo.payer)
    const reste = total - payer

    return (
        <Grid columns={30}>
            <Grid.Col md={8}>
                <Card
                    shadow="lg"
                    sx={(theme) => ({ backgroundColor: theme.colors.blue[6], color: 'white' })}
                >
                    <Text>Reception : {new Date(achatInfo.ac_date).toLocaleDateString()}</Text>
                    <Text>Fournisseur : {achatInfo.fo_nom}</Text>
                    <Text>Montant Total(s) : {formatWari(achatInfo.montant)} </Text>
                    <Text>Montant Payer : {formatWari(achatInfo.payer)} </Text>
                    <Text weight="bold">
                        Reste : {formatWari(achatInfo.montant - achatInfo.payer)}{' '}
                    </Text>
                    <Group spacing={3}>
                        {achatInfo.ac_etat === 0 && achatCommand.length > 0 ? (
                            <Button
                                id="button_add_achat_valid_16"
                                mt={5}
                                variant="white"
                                onClick={() => handleValidate(acId)}
                            >
                                Valider l'achat
                            </Button>
                        ) : null}
                        {achatInfo.ac_etat > 0 ? (
                            <Tooltip label="Impirmer">
                                <Button
                                    component={Anchor}
                                    href={`${API_URL}/documents/achat/${acId}`}
                                    target="_blank"
                                    variant="white"
                                >
                                    <IconPrinter />
                                </Button>
                            </Tooltip>
                        ) : null}
                        {achatInfo.ac_etat > 0 ? (
                            <Tooltip label="Devalidation de l'achat" withArrow>
                                <Button
                                    m={5}
                                    onClick={() => handleValidate(acId, '0')}
                                    color="orange"
                                >
                                    Devalider
                                </Button>
                            </Tooltip>
                        ) : null}
                    </Group>
                    {achatInfo.ac_etat < 1 && achatCommand.length > 0 ? (
                        <div>
                            <Divider label="Post-validation" />
                            <Group spacing={3}>
                                <Tooltip>
                                    <Button
                                        mt={5}
                                        component={Anchor}
                                        href={`${API_URL}/documents/achat/${acId}?type=a`}
                                        target="_blank"
                                        variant="light"
                                        fullWidth
                                    >
                                        Demande avis frs
                                    </Button>
                                </Tooltip>
                            </Group>
                        </div>
                    ) : null}
                </Card>
                {achatInfo.ac_etat < 1 && achatRuptureProduct.length > 0 ? (
                    <Box>
                        <Divider label="Produits en rupture de de stock" />
                        <TextInput
                            icon={<IconSearch size={20} />}
                            placeholder="Chercher un produit"
                            autoComplete="off"
                            autoCorrect="off"
                            {...getSearchProps('nom')}
                            onChange={handleSearch}
                        />
                        <Box component={ScrollArea} style={{ height: 120 }} type="hover">
                            {Array.isArray(achatRuptureProduct) &&
                                achatRuptureProduct.filter(searchFilter).map((d) => {
                                    return (
                                        <Group mt={5} key={d.pr_id} spacing={4}>
                                            <Checkbox onClick={() => handleClick({ ...d })} />
                                            <Text weight="bold" color="red">
                                                {d.pr_nom}
                                            </Text>
                                        </Group>
                                    )
                                })}
                        </Box>
                    </Box>
                ) : null}
            </Grid.Col>
            <Grid.Col md={22}>
                <Tabs value={active} onTabChange={(value) => setActive(value)}>
                    <Tabs.List m={5}>
                        <Tabs.Tab
                            icon={<ImageIcon src={pannierIcon} alt="basket_icon" />}
                            value="first"
                        >
                            Contenu {achatInfo.ac_etat > 0 ? <Badge m={5}>OK</Badge> : null}
                        </Tabs.Tab>
                        <Tabs.Tab
                            icon={<ImageIcon src={cashIcon} alt="cash_icon" />}
                            value="second"
                        >
                            Paiement {achatInfo.ac_etat > 1 ? <Badge m={5}>OK</Badge> : null}
                        </Tabs.Tab>
                        <Tabs.Tab
                            itemID="tab_add_achat_reception_19"
                            icon={<ImageIcon src={carsIcon} alt="cars_icon" />}
                            value="third"
                        >
                            Reception {achatInfo.is_rec ? <Badge m={5}>OK</Badge> : null}
                        </Tabs.Tab>
                        <Tabs.Tab icon={<IconArrowRight size={21} />} value="four">
                            Retour {achatInfo.is_ret ? <Badge m={5}>OK</Badge> : null}
                        </Tabs.Tab>
                    </Tabs.List>
                    <Tabs.Panel value="first">
                        <AchatContenu
                            acId={acId}
                            achatCommand={achatCommand}
                            achatInfo={achatInfo}
                            getSum={total}
                        />
                    </Tabs.Panel>
                    <Tabs.Panel value="second">
                        <AchatPaiement
                            acId={acId}
                            achatPaiement={achatPaiement}
                            achatInfo={achatInfo}
                            getPaySum={payer}
                            rest={reste}
                        />
                    </Tabs.Panel>
                    <Tabs.Panel value="third">
                        <AchatReception acId={acId} achatInfo={achatInfo} />
                    </Tabs.Panel>
                    <Tabs.Panel value="four">
                        <AchatRetour acId={acId} />
                    </Tabs.Panel>
                </Tabs>
            </Grid.Col>
        </Grid>
    )
}, [])
export default AchatDetails
