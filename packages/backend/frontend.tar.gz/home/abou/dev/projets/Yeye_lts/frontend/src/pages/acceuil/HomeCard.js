import { Card, Spoiler, Text, Title } from "@mantine/core"
import { formatNumber } from "../../helper"

export default function HomeCard({ title, total = 0, desc, mw }) {
    return (
        <Card
            shadow="lg"
            m={5}
            sx={(theme) => ({ backgroundColor: theme.colors.gray[3] })}
            style={{ maxWidth: `${mw || 193}px` }}
        >
            <header>
                <Text>{title}</Text>
                <Title order={2}>{formatNumber(total, false)}</Title>
            </header>
            <Spoiler maxHeight={0} showLabel="Description" hideLabel="Fermer">
                <Text>{desc}</Text>
            </Spoiler>
        </Card>
    )
}
