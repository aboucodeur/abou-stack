import React from 'react'
import { Table, Text, createStyles } from '@mantine/core'
import { FixedSizeList } from 'react-window'

// ** PROBLEME SUR IPHONE (corriger)
const VirtualTableContext = React.createContext({
    top: 12,
    setTop: (value = 0) => { },
    header: undefined,
    footer: undefined,
})

const useStyles = createStyles((theme) => ({
    header: {
        backgroundColor: theme.colorScheme === 'dark' ? theme.colors.dark[7] : theme.white,
        transition: 'box-shadow 150ms ease',
        '&::after': {
            content: '""',
            position: 'absolute',
            left: 0,
            right: 0,
            bottom: 0,
            borderBottom: `1px solid ${theme.colorScheme === 'dark' ? theme.colors.dark[3] : theme.colors.gray[2]}`,
        },
    },

}))


export default function VirtualTable({ row, header, footer, ...rest }) {
    const listRef = React.useRef()
    const [top, setTop] = React.useState(0)

    return (
        <VirtualTableContext.Provider value={{ top, setTop, header, footer }}>
            <FixedSizeList
                itemSize={60}
                width="100%"
                innerElementType={Inner}
                onItemsRendered={props => {
                    const style = listRef.current && listRef.current._getItemStyle(props.overscanStartIndex)
                    setTop((style && style.top) || 0)
                    // Call the original callback
                    rest.onItemsRendered && rest.onItemsRendered(props)
                }}
                ref={el => (listRef.current = el)}
                {...rest}
            >
                {row}
            </FixedSizeList>
        </VirtualTableContext.Provider>
    )
}

// TODO : Pour faire le forwarding du composant
const Inner = React.forwardRef(
    function Inner({ children, ...rest }, ref) {
        const { header, footer } = React.useContext(VirtualTableContext)
        const { classes } = useStyles()
        return (
            <div {...rest} ref={ref}>
                <Table mt={5} style={{ top: 5, position: "sticky" }} verticalSpacing='sm'>
                    <thead>
                        <tr style={{ userSelect: "none" }} className={classes.header}>
                            {header.map(d => <th key={d}><Text size={14} weight="bold" olor="dimmed">{d}</Text></th>)}
                        </tr>
                    </thead>
                    <tbody>
                        {children}
                    </tbody>
                    {footer ? footer : null}
                </Table>
            </div >
        )
    }
)