import React from "react"
export default function useSearch(initialValues = {}) {
    const [searchVal, setSearchVal] = React.useState({ ...initialValues })
    const handleSearch = (e) => {
        const { name, value } = e.target
        setSearchVal(prev => ({ ...prev, [name]: value }))
    }
    const setSearch = React.useCallback((key, val) => setSearchVal(prev => ({ ...prev, [key]: val })), [])
    const cleanSearch = React.useCallback(() => setSearchVal(initialValues), [initialValues])
    const getSearchProps = React.useCallback((name = "") => {
        const hasNoyKey = !Object.keys(searchVal).includes(name)
        if (hasNoyKey) throw new Error("Aucun element definis")
        return { name: name, value: searchVal[name], }
    }, [searchVal])
    return {
        searchVal,
        setSearchVal,
        handleSearch,
        setSearch,
        cleanSearch,
        getSearchProps,
    }
}