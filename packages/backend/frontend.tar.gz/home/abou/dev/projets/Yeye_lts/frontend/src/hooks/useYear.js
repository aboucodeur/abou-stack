// ** code a fonctionner apres modification et pris en comptes des breakinhs changes
export default function useYear() {
    const years = [];
    const currentYear = new Date().getFullYear();
    const lastMonthsVolume = 3; // 3 months later to current years
    for (let i = currentYear - lastMonthsVolume; i <= currentYear; i++) {
        const pushedObj = { value: `${i}`, label: `${i}` };
        years.push(pushedObj);
    }
    return years;
}