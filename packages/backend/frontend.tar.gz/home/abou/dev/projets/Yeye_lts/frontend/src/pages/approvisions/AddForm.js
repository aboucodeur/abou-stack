import { Button, Group, Notification, NumberInput, Select } from '@mantine/core'
import useForm from '../../hooks/useForm'
import { useMutation, useQuery, useQueryClient } from 'react-query'
import { addApprovisionCommand, getShopProductAdaptSelect } from '../../services/api'
import { useAppState } from '../../context/AppContext'
import { getError } from '../../utils'
import { useFocusTrap } from '@mantine/hooks'

export default function AddForm({ apId }) {
    const { getShop } = useAppState()
    const shopId = getShop.bo_id
    const { formValues, formErr, setErrors, setValues } = useForm({ pr_id: '', qte: undefined })
    const { data: shopProduct = [] } = useQuery(['pro_adapt', shopId], ({ queryKey }) =>
        getShopProductAdaptSelect(queryKey[1]),
    )
    const { mutate } = useMutation(['appr_cmd'], addApprovisionCommand)
    const query = useQueryClient()
    const focusTrap = useFocusTrap()

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate(
            { ...formValues, apId },
            {
                onSuccess() {
                    query.invalidateQueries('appr_cmd')
                    query.invalidateQueries('appr_info')
                    query.invalidateQueries('appr_prod')
                    setValues('qte', undefined)
                    setValues('prix', undefined)
                },
                onError(err) {
                    const error = getError(err)
                    if (error) setErrors('message', error)
                },
            },
        )
    }
    return (
        <div>
            {formErr.message && (
                <Notification color="red" m={5} onClose={() => setErrors('message', '')}>
                    {formErr.message}
                </Notification>
            )}
            <form onSubmit={handleSubmit} ref={focusTrap}>
                <Group spacing={3}>
                    <Select
                        label="Choisir un produit"
                        data={shopProduct}
                        placeholder="Choisir un produit"
                        searchable
                        clearable
                        nothingFound="Produit introuvable"
                        defaultValue={formValues.pr_id}
                        onChange={(value) => {
                            if (!value) return
                            setValues('pr_id', value)
                            setValues('qte', 1)
                        }}
                        required
                        data-autofocus
                        limit={300} // ** user perform search
                    />
                    <NumberInput
                        label={`La quantite (${formValues.qte || 0})`}
                        placeholder="Donner une quantite"
                        min={1}
                        maxLength={20}
                        autoComplete="off"
                        autoCorrect="off"
                        value={formValues.qte}
                        onChange={(value) => setValues('qte', value)}
                        required
                    />
                    <Button type="submit" mt={25}>
                        +
                    </Button>
                </Group>
            </form>
        </div>
    )
}
