import { Badge, Button, Notification, Text, TextInput } from "@mantine/core"
import { useMutation, useQueryClient } from "react-query"
import useForm from "../../hooks/useForm"
import { addGerant } from "../../services/api"
import { getError } from "../../utils"

export default function AddGerant({ boId, handleClose }) {
    const { formValues, formErr, getInputProps, handleChange, setErrors, cleanForm } = useForm({ prenom: "", nom: "", email: "", tel: "" })
    const { mutate } = useMutation("ger", addGerant)
    const query = useQueryClient()

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({
            ...formValues,
            prenom: formValues.prenom.trim(),
            nom: formValues.nom.trim(),
            bo_id: boId,
            role: "ger"
        }, {
            onSuccess() {
                query.invalidateQueries("ger")
                cleanForm()
                handleClose()
            },
            onError(err) {
                const getErr = getError(err)
                if (getErr) setErrors("message", getErr)
            }
        })
    }

    return (
        <form onSubmit={handleSubmit}>
            {formErr.message && <Notification color="red" onClose={() => setErrors("message", "")}>{formErr.message}</Notification>}
            <TextInput
                label="Prenom"
                placeholder="Donner le prenom"
                autoComplete="off"
                autoCorrect="off"
                {...getInputProps("prenom")}
                onChange={handleChange}
                required
            />
            <TextInput
                label="Nom"
                placeholder="Donner le nom"
                autoComplete="off"
                autoCorrect="off"
                {...getInputProps("nom")}
                onChange={handleChange}
                required
            />
            <TextInput
                label="Email"
                placeholder="Donner le 'email"
                autoComplete="off"
                autoCorrect="off"
                {...getInputProps("email")}
                onChange={handleChange}
                required
            />
            <TextInput
                label="Télephone"
                placeholder="Donner votre télephone"
                type="tel"
                {...getInputProps("tel")}
                onChange={handleChange}
                required
            />
            <Text><Badge size="md">Mot de passe par defaut : 12345</Badge></Text>
            <Button mt={5} type="submit">Ajouter</Button>
        </form>
    )
}
