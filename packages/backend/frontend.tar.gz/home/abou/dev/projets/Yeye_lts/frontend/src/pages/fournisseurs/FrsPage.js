import { useMemo, useState } from 'react'
import { useAppState } from '../../context/AppContext'
import { Button, ActionIcon, Flex, Tooltip, Text, Group, Badge } from '@mantine/core'
import { useMutation, useQuery, useQueryClient } from "react-query"
import { getShopFournisseur, addFournisseur, editFournisseur, deleteFournisseur } from '../../services/api'
import { IconEdit, IconTrash } from "@tabler/icons-react"
import { getError } from '../../utils'
import { useModals } from '@mantine/modals'
import MTRTable from '../../components/table/MTRTable'

export default function FrsPage() {
    const { getShop } = useAppState()
    const modals = useModals()
    const shopId = getShop.bo_id
    const query = useQueryClient()

    // ** DATAS ET MUTATIONS
    const { data: getShopFrs = [], isLoading: isLoadingGetFrs, isError } = useQuery(["frs", shopId], ({ queryKey }) => getShopFournisseur(queryKey[1]))
    const { mutateAsync: createFrs, isError: isErrorCreateFrs, isLoading: isCreatingFrs } = useMutation(["frs"], addFournisseur)
    const { mutateAsync: editFrs } = useMutation(["frs"], editFournisseur)
    const { mutate: deleteFrs } = useMutation(["frs"], deleteFournisseur)
    const [validationErrors, setValidationErrors] = useState({})

    // ** REGISTERED OPERATION
    const handleCreateFrs = async ({ values, exitCreatingMode }) => {
        const errorsValidation = validateForm(values)
        console.log(errorsValidation)
        if (Object.entries(errorsValidation).length !== 0) {
            setValidationErrors(errorsValidation)
            return
        }
        setValidationErrors({})
        await createFrs({
            nom: values?.fo_nom.trim(),
            adr: values?.fo_adr,
            tel: values?.fo_tel,
            email: values?.fo_email,
            bo_id: shopId,
        }, {

            onSuccess: () => {
                query.invalidateQueries("frs")
                query.invalidateQueries("frs_adapt")
                exitCreatingMode()
            },
            onError: (err) => {
                const error = getError(err)
                if (error) setValidationErrors(prev => ({ ...prev, message: error }))
                exitCreatingMode();
            }
        })
    }
    const handleEditFrs = async ({ values, exitEditingMode }) => {
        setValidationErrors({})
        await editFrs({
            foId: values?.fo_id,
            nom: values?.fo_nom.trim(),
            adr: values?.fo_adr,
            tel: values?.fo_tel,
            email: values?.fo_email
        },
            {
                onSuccess: () => {
                    query.invalidateQueries("frs")
                    query.invalidateQueries("frs_adapt")
                    exitEditingMode()
                },
                onError: (err) => {
                    const error = getError(err)
                    if (error) setValidationErrors(prev => ({ ...prev, message: error }))
                    exitEditingMode();
                }
            })
    }
    const handleDeleteFrs = async (row) =>
        modals.openConfirmModal({
            title: 'Suppression du fournisseur',
            children: (
                <Text>
                    Etes-vous sure de supprimer  {row.original.fo_nom} ? . <br />
                    Cette action irreverssible .
                </Text>
            ),
            labels: { confirm: 'Supprimer', cancel: 'Annuler' },
            confirmProps: {
                color: !row.original.disabled ? 'red' : 'blue',
                children: !row.original.disabled ? 'Confirmer' : 'Restaurer',
            },
            cancelProps: { children: 'Annuler' },
            onConfirm: () => deleteFrs({
                foId: row.original.fo_id,
                type: row.original.disabled === true ? 'act' : 'des'
            }, {
                onSuccess: () => {
                    query.invalidateQueries("frs")
                    query.invalidateQueries("frs_adapt")
                }
            }),
        });

    const columns = useMemo(() => [
        {
            accessorFn: (originalRow) => (originalRow.disabled ? 'true' : 'false'),
            id: 'etat',
            header: 'Etat de compte',
            filterVariant: 'checkbox',
            Cell: ({ cell }) => cell.getValue() === 'true'
                ? <Badge color="red">Supprimer</Badge>
                : <Badge>Nom supprimer</Badge>,
            size: 20,
            enableEditing: false,
            mantineEditTextInputProps: {
                style: { display: 'none' }
            }
        },
        {
            accessorKey: 'fo_nom',
            header: 'Nom complet',
            mantineEditTextInputProps: {
                type: 'text',
                required: true,
                autoComplete: 'off',
                autoCorrect: 'off',
                error: validationErrors?.fo_nom,
                onFocus: () => setValidationErrors({ ...validationErrors, fo_nom: undefined }),
            },
            size: 30
        },
        {
            accessorKey: 'fo_tel',
            header: 'Telephone',
            mantineEditTextInputProps: {
                type: 'tel',
                required: true,
                autoComplete: 'off',
                autoCorrect: 'off',
                error: validationErrors?.fo_tel,
                onFocus: () => setValidationErrors({ ...validationErrors, fo_tel: undefined }),
            },
            size: 30
        },
        {
            accessorKey: 'fo_email',
            header: 'E-mail',
            mantineEditTextInputProps: {
                type: 'email',
                required: true,
                autoComplete: 'off',
                autoCorrect: 'off',
                error: validationErrors?.fo_email,
                onFocus: () => setValidationErrors({ ...validationErrors, fo_email: undefined }),
            },
            size: 30
        },
        {
            accessorKey: 'fo_adr',
            header: 'Adresse',
            mantineEditTextInputProps: {
                type: 'textarea',
                required: true,
                spellCheck: false,
                autoComplete: 'off',
                autoCorrect: 'off',
                error: validationErrors?.fo_adr,
                onFocus: () => setValidationErrors({ ...validationErrors, fo_adr: undefined }),
            },
            size: 30
        }
    ], [validationErrors])

    return (
        <MTRTable
            uId='fo_id'
            columns={columns}
            data={getShopFrs}
            createDisplayMode={'row'}
            editDisplayMode={'row'}
            validationErrors={validationErrors}
            setValidationErrors={setValidationErrors}
            onCreatingRowCancel={() => setValidationErrors({})}
            onEditingRowCancel={() => setValidationErrors({})}
            handleCreate={handleCreateFrs}
            handleEdit={handleEditFrs}
            hooksEditingOptions={{
                enableEditing: true,
                positionActionsColumn: 'last'
            }}
            renderRowActions={({ row, table }) => (
                <Flex gap="md">
                    <Tooltip label="Edit">
                        <ActionIcon onClick={() => table.setEditingRow(row)}>
                            <IconEdit />
                        </ActionIcon>
                    </Tooltip>
                    <Tooltip label="Delete">
                        <ActionIcon color="red" onClick={() => handleDeleteFrs(row)}>
                            <IconTrash />
                        </ActionIcon>
                    </Tooltip>
                </Flex>
            )}
            renderTopToolbarCustomActions={({ table }) => (
                <Group spacing={3}>
                    <Button onClick={() => table.setCreatingRow(true)}>
                        Ajouter un fournisseur
                    </Button>
                </Group>
            )}
            visual={{
                dataLoader: isLoadingGetFrs,
                dataError: isErrorCreateFrs || isError,
                addLoader: isCreatingFrs,
            }}
        />
    )
}

const validateEmail = (email = "") =>
    !!email.length &&
    email
        .toLowerCase()
        .match(
            /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
        );
const validateForm = (values) => {
    let errors = {}
    if (!values.fo_nom) errors.fo_nom = 'Nom obligatoire'
    else if (values.fo_nom > 100) errors.fo_nom = 'Nom 100 caracteres maximun'

    if (!values.fo_tel) errors.fo_tel = 'Numero de telephone obligatoire'
    else if (values.fo_tel > 60) errors.fo_nom = 'Telephone 60 caracteres maximun'

    if (!values.fo_email) errors.fo_email = 'Email obligatoire'
    else if (!validateEmail(values.fo_email)) errors.fo_email = 'Email incorrecte'
    else if (values.fo_email > 200) errors.fo_email = 'Email 200 caracteres maximun'

    if (!values.fo_adr) errors.fo_adr = 'Adresse obligatoire'
    else if (values.fo_adr > 300) errors.adr = 'Adresse 300 caracteres maximun'

    return errors
}