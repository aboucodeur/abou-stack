import { useQuery } from "react-query"
import { Link } from "react-router-dom"
import { getAchatInfoPaiement } from "../../services/api"
import { Anchor, Badge } from "@mantine/core"
import { useAppState } from "../../context/AppContext"
import "dayjs/locale/fr"
import { MTRTable } from "../../components"
import { formatNumber } from "../../helper"

export default function AchatPayPage() {
    const { getShop } = useAppState()
    const shopId = getShop.bo_id
    const { data: achatInfoPay = [], isLoading, isFetching, isError } = useQuery(["achats_info_p", shopId], ({ queryKey }) => getAchatInfoPaiement(queryKey[1]))

    return (
        <MTRTable
            uId='ac_id'
            columns={[
                {
                    accessorKey: 'a_date',
                    accessorFn: (originalRow) => new Date(originalRow.a_date).toLocaleDateString(),
                    header: 'Date de reception',
                    enableGrouping: true,
                },
                {
                    accessorKey: 'fo_nom',
                    header: 'Fournisseur',
                    enableGrouping: true,
                },
                {
                    accessorKey: 'montant',
                    header: 'Montant',
                    enableGrouping: false,
                    Cell: ({ cell }) => formatNumber(cell.getValue()),
                },
                {
                    accessorKey: 'payer',
                    header: 'Payer',
                    enableGrouping: false,
                    Cell: ({ cell }) => formatNumber(cell.getValue()),
                },
                {
                    accessorKey: 'appr',
                    header: 'Etat',
                    enableGrouping: true,
                    Cell: ({ cell }) => (
                        <Badge
                            color={cell.getValue() === 0 ? "red" : cell.getValue() === 1 ? "green" : "gray"}>
                            {cell.getValue() === 0 ? "Pas Payer" : cell.getValue() === 1 ? "Payer" : "Retourner"}
                        </Badge>
                    ),
                    size: 80
                },
        ]}
            data={achatInfoPay}
            enableGrouping={true}
            initialState={{
                grouping: ['appr']
            }}
            hooksEditingOptions={{
                enableEditing: true,
                positionActionsColumn: 'last'
            }}
            enableColumnFilters={true}
            renderRowActions={({ row }) => {
                return <Anchor component={Link} to={`/commandes/fournisseurs/${row.original.ac_id}`}>
                    Details
                </Anchor>
            }}
            visual={{
                dataLoader: isLoading,
                dataError: isError, // ** en cas d'erreur de chargement de data
                dataFetching: isFetching,
            }}
        />
    )
}
