import { Button } from '@mantine/core'
import { removeShopVendre } from '../../services/api'
import { useMutation, useQueryClient } from "react-query"

export default function RemVendreModal({ id, handleClose }) {
    const query = useQueryClient()
    const { mutate } = useMutation(["vendres"], removeShopVendre)
    const handleRemove = (id) => {
        mutate(id, {
            onSuccess() {
                query.invalidateQueries("vendres")
                handleClose()
            }
        })
    }
    return <Button color="red" onClick={() => handleRemove(id)}>Oui, Supprimer</Button>
}