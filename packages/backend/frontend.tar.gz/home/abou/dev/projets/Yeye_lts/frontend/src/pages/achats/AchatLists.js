import { ActionIcon, Anchor, Button, Group, Paper, Select, Text } from "@mantine/core"
import { getShopAchat, getShopFournisseurAdaptSelect } from "../../services/api"
import { DatePickerInput } from "@mantine/dates"
import { modals } from "@mantine/modals"
import { useQuery } from "react-query"
import { Link } from "react-router-dom"
import { useAppState } from "../../context/AppContext"
import { pgDate } from "../../utils"
import { IconCalendar, IconSelect, IconEdit, IconTrash } from "@tabler/icons-react"
import { SearchFound, VirtualTable } from "../../components"
import useSearch from "../../hooks/useSearch"
import useHeight from "../../hooks/useHeight"
import AddAchatModal from "./AddAchatModal"
import EditAchatModal from "./EditAchatModal"
import RemAchatModal from "./RemAchatModal"
import { formatNumber, formatWari } from "../../helper"
import { useCallback, useEffect, useMemo } from "react"
import useOnboardModal from "../../onboard/MultiRoute/useOnboardModal"
import { AUTO, CLOSE } from "../../onboard"

export default function AchatLists() {
    const { getShop } = useAppState()
    const shopId = getShop.bo_id
    const { searchVal, setSearch } = useSearch({ date: new Date(), foId: null })
    const { data: shopFrs = [] } = useQuery(["frs_adapt", shopId], ({ queryKey }) =>
        getShopFournisseurAdaptSelect(queryKey[1]),
    )
    const { data: shopAchat = [] } = useQuery(
        ["achats", shopId, pgDate(searchVal.date)],
        ({ queryKey }) => getShopAchat(queryKey[1], queryKey[2]),
    )
    const { wH } = useHeight(100)

    const { autoLoadOnboard, stepIndex, setState } = useOnboardModal()

    const addModal = useCallback(() => {
        modals.open({
            title: "Nouvelle commande",
            children: (
                <AddAchatModal
                    shopFrs={shopFrs}
                    boId={shopId}
                    handleClose={() => modals.closeAll()}
                    setState={setState}
                />
            ),
        })
    }, [setState, shopFrs, shopId])

    const editModal = (data) => {
        modals.open({
            title: "Modification",
            children: <EditAchatModal datas={data} handleClose={() => modals.closeAll()} />,
        })
    }

    const remModal = (acId) => {
        modals.open({
            title: "Etes vous sure de supprimer ?",
            children: <RemAchatModal id={acId} handleClose={() => modals.closeAll()} />,
        })
    }

    const isArr = Array.isArray(shopAchat)
    const total = useMemo(
        () => isArr && shopAchat.reduce((curr, acc) => curr + parseFloat(acc.total, 10), 0),
        [isArr, shopAchat],
    )
    const filteredShopAchat = isArr
        ? shopAchat.filter((d) => (!searchVal.foId ? d : d.fo_id === searchVal.foId))
        : []
        
    const Rows = ({ index }) => {
        const { ac_id, createdAt, ac_etat, ac_date, fo_nom, ac_desc, entree, total } =
            filteredShopAchat[index]
        return (
            <tr>
                <td style={{ height: "36px" }}>
                    <Text>{index + 1}</Text>
                </td>
                <td>
                    <Text>{new Date(createdAt).toLocaleString()}</Text>
                </td>
                <td>
                    <Text>{new Date(ac_date).toLocaleDateString()}</Text>
                </td>
                <td>
                    <Text>{fo_nom}</Text>
                </td>
                <td>
                    <Text>{ac_desc}</Text>
                </td>
                <td>
                    <Text color="green">{formatNumber(entree)}</Text>
                </td>
                <td>
                    <Text>{formatNumber(total)}</Text>
                </td>
                <td>
                    <Group spacing={15}>
                        <Anchor component={Link} to={`/commandes/fournisseurs/${ac_id}`}>
                            Details
                        </Anchor>
                        <ActionIcon
                            onClick={() => editModal({ ...filteredShopAchat[index] })}
                            color="orange"
                        >
                            <IconEdit />
                        </ActionIcon>
                        {total < 1 ? (
                            <ActionIcon
                                disabled={ac_etat !== "0" && total > 0 && true}
                                onClick={() => remModal(ac_id)}
                                color="red"
                            >
                                <IconTrash />
                            </ActionIcon>
                        ) : null}
                    </Group>
                </td>
            </tr>
        )
    }

    useEffect(() => {
        if (stepIndex < CLOSE.achat.modal) autoLoadOnboard(AUTO.achat.modal, addModal)
    }, [addModal, autoLoadOnboard, stepIndex])

    return (
        <div>
            <Group align="normal" mt={5} spacing={3}>
                <DatePickerInput
                    locale="fr"
                    placeholder="Date"
                    autoComplete="off"
                    autoCorrect="off"
                    value={searchVal.date}
                    onChange={(value) => setSearch("date", value)}
                    icon={<IconCalendar />}
                    clearable
                />
                <Select
                    data={shopFrs}
                    placeholder="Fournisseur"
                    clearable
                    searchable
                    nothingFound="Fournisseur Introuvable"
                    onChange={(value) => setSearch("foId", value)}
                    icon={<IconSelect />}
                />
                <Button id="button_add_achat_10" onClick={() => addModal()}>
                    ACHETER
                </Button>
            </Group>
            <div>
                {isArr && shopAchat.length === 0 ? (
                    <SearchFound message="Aucun achat pour cette date" />
                ) : (
                    <div>
                        <Paper p={16} shadow="lg">
                            <Text color="blue">Sommes des achats {formatWari(total)}</Text>
                        </Paper>
                        <VirtualTable
                            header={[
                                "N°",
                                "Date Heure",
                                "Reception",
                                "Fournisseur",
                                "Description",
                                "Entree (stock)",
                                "Montant",
                                "Action",
                            ]}
                            height={wH}
                            width="100%"
                            itemCount={filteredShopAchat.length}
                            row={Rows}
                        />
                    </div>
                )}
            </div>
        </div>
    )
}
