import { Anchor, Badge, Group, Loader, Select, Text, TextInput } from '@mantine/core'
import { NavLink } from 'react-router-dom'
import AppTable from '../../components/table/AppTable'
import { getAllUser } from '../../services/api'
import { useQuery } from 'react-query'
import useSearch from '../../hooks/useSearch'
import { IconSearch, IconSelect } from '@tabler/icons-react'
import { toLower } from '../../utils'

export default function UserLists() {
    const { searchVal, handleSearch, setSearch, getSearchProps } = useSearch({ nom: '', etat: 0 })
    const { data: allUser = [], isLoading } = useQuery(['user'], ({ queryKey }) =>
        getAllUser(queryKey[1]),
    )

    const searchFilter = (data) => {
        const { us_tel, us_prenom, us_nom } = data
        const nom = us_prenom?.concat(us_nom)
        if (!searchVal.nom) return data
        if (toLower(nom).includes(toLower(searchVal.nom.trim()))) return data
        if (us_tel.split(' ').join('').includes(searchVal.nom.trim())) return data
    }
    const tableRows = allUser
        .filter(searchFilter)
        // TODO : Possibiliter d'afficher tous les utilisateurs
        .filter((u) =>
            searchVal.etat !== -1 ? u.disabled === (searchVal.etat === 0 ? false : true) : u,
        )
        .map((u, _idx) => (
            <tr key={u.us_id}>
                <td>
                    <Text>{_idx + 1}</Text>
                </td>
                <td>{new Date(u.createdAt).toLocaleString()}</td>
                <td>
                    <Text>{u.us_prenom}</Text>
                </td>
                <td>
                    <Text>{u.us_nom}</Text>
                </td>
                <td>
                    <Text>{u.bo_nom}</Text>
                </td>
                <td>
                    <Text>{u.us_tel}</Text>
                </td>
                <td>
                    <Badge size="lg" color={u.disabled ? 'red' : 'green'}>
                        {u.disabled ? 'Desactiver' : 'Activer'}
                    </Badge>
                </td>
                <td>
                    <Anchor
                        m={5}
                        component={NavLink}
                        to={`/admin/dashboard/user/${u.bo_id}/${u.us_id}/`}
                    >
                        Details
                    </Anchor>
                </td>
            </tr>
        ))

    if (isLoading) return <Loader />
    return (
        <div>
            <Group spacing={3}>
                <TextInput
                    icon={<IconSearch />}
                    placeholder="Nom ou Tel"
                    autoComplete="off"
                    autoCorrect="off"
                    name="tel"
                    {...getSearchProps('nom')}
                    onChange={handleSearch}
                />
                <Select
                    icon={<IconSelect />}
                    placeholder="Veillez choisr un etat"
                    data={[
                        { label: 'Tous', value: -1 },
                        { label: 'Activer', value: 0 },
                        { label: 'Desactiver', value: 1 },
                    ]}
                    nothingFound="Etat introuvable"
                    clearable
                    searchable
                    defaultValue={searchVal.etat}
                    onChange={(value) => setSearch('etat', value)}
                />
            </Group>
            <AppTable
                title="Liste Utilisateurs"
                tableHead={[
                    'N°',
                    "Date d'inscription",
                    'Prenom',
                    'Nom',
                    'Boutique',
                    'Telephone',
                    'Etat du compte',
                    'Action',
                ]}
                tableRows={tableRows}
            />
        </div>
    )
}
