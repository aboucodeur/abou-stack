import React from 'react'
import {
    Box,
    Button,
    Group,
    Image,
    Notification,
    NumberInput,
    Select,
    Text,
    TextInput,
} from '@mantine/core'
import useForm from '../../hooks/useForm'
import { useMutation, useQuery, useQueryClient } from 'react-query'
import { getShopDepotAdaptSelect, editProduct } from '../../services/api'
import { getError } from '../../utils'
import { Unity } from '../../mock'
import Barcode from '../../components/barcode/Barcode'

const MIMES_TYPES = {
    'image/jpeg': 'jpg',
    'image/jpg': 'jpg',
    'image/png': 'png',
}

export default function EditProduct({ deId, boId, data, handleClose }) {
    const initialValues = { nom: '', unite: '', file: '', pv: 0, pa: 0, de_id: deId, code: '' }
    const {
        formValues,
        formErr,
        handleChange,
        setValues,
        setFormErr,
        setErrors,
        cleanForm,
        onError,
    } = useForm(initialValues)
    const query = useQueryClient()
    const { data: getShopDepot = [] } = useQuery(['dep_adapt', boId], ({ queryKey }) =>
        getShopDepotAdaptSelect(queryKey[1]),
    )
    const { mutate } = useMutation(['prod'], editProduct)

    const handleUpload = (e) => {
        const isFile = e.target.files[0]
        if (!isFile) return
        setValues('file', isFile)
    }
    // ** Coherence : trim name not trust to user
    const handleSubmit = (e) => {
        e.preventDefault()
        const formData = new FormData()
        formData.append('nom', formValues.nom.trim())
        formData.append('unite', formValues.unite)
        formData.append('file', formValues.file)
        formData.append('pa', formValues.pa || '')
        formData.append('pv', formValues.pv || '')
        formData.append('de_id', formValues.de_id)
        if (formValues.code) formData.append('code', formValues.code)
        onError({ ...formValues }, (values, err) => {
            const { pv, pa, file } = values
            if (pa > pv) err.pa = 'Oops pas de benefice !!!'
            if (file && !MIMES_TYPES[file.type]) err.file = 'Fichier :(.jpeg,.jpg,.png)'
            if (Object.entries(err).length === 0) {
                mutate(
                    { formData, prId: data.pr_id },
                    {
                        onSuccess() {
                            query.invalidateQueries('prod')
                            cleanForm()
                            handleClose()
                            setFormErr({})
                        },
                        onError(err) {
                            const error = getError(err)
                            if (error) setErrors('message', error)
                        },
                    },
                )
            }
        })
    }
    React.useEffect(() => {
        setValues('nom', data.pr_nom)
        setValues('unite', data.pr_unite)
        setValues('pv', parseFloat(data.pr_pv))
        setValues('pa', parseFloat(data.pr_pa))
        if (data.pr_code) setValues('code', data.pr_code)
    }, [data, setValues])

    return (
        <div>
            {formErr.message && (
                <Notification m={5} onClose={() => setErrors('message', '')} color="red">
                    {formErr.message}
                </Notification>
            )}
            <form onSubmit={handleSubmit}>
                {data.pr_url ? (
                    <Image
                        width={120}
                        src={data.pr_url}
                        alt={`photo de ${data.pr_url}`}
                        fit="contain"
                    />
                ) : null}
                <Barcode onScan={(barcode) => setValues('code', barcode)} />
                <TextInput
                    label="Nom du produit"
                    autoComplete="off"
                    autoCorrect="off"
                    name="nom"
                    value={formValues.nom}
                    onChange={handleChange}
                />
                <Box mt={5}>
                    <input type="file" onChange={handleUpload} />
                </Box>
                <Select
                    label="Unite du produit"
                    description="Liste des unités standard"
                    placeholder="Donner l'unité du produit"
                    autoComplete="off"
                    autoCorrect="off"
                    clearable
                    searchable
                    data={Unity}
                    defaultValue={data.pr_unite}
                    onChange={(value) => setValues('unite', value)}
                />
                <Group spacing={3}>
                    <NumberInput
                        label="Prix d'achat"
                        autoComplete="off"
                        autoCorrect="off"
                        placeholder="Donner le prix d'achat"
                        style={{ width: '193px' }}
                        value={formValues.pa}
                        onChange={(value) => setValues('pa', value)}
                        required
                        maxLength={20}
                        min={0}
                        error={formErr.pa}
                        precision={2} // decimal
                    />
                    <NumberInput
                        label="Prix de vente"
                        autoComplete="off"
                        autoCorrect="off"
                        style={{ width: '193px' }}
                        value={formValues.pv}
                        onChange={(value) => setValues('pv', value)}
                        required
                        maxLength={20}
                        min={0}
                        error={formErr.pv}
                        precision={2} // decimal
                    />
                </Group>
                <Select
                    label="Changer de depot"
                    data={getShopDepot}
                    clearable
                    searchable
                    defaultValue={data.de_id}
                    onChange={(value) => setValues('de_id', value)}
                />
                <TextInput
                    label="Code du produit"
                    value={formValues.code}
                    onChange={(e) => setValues('code', e.target.value)}
                    autoComplete="off"
                    autoCorrect="off"
                />
                {!['transport', 'reliquat'].includes(formValues.nom.toLowerCase()) ? (
                    <Button mt={5} type="submit" fullWidth color="orange" variant="outline">
                        Modifier
                    </Button>
                ) : (
                    <Text mt={5} color="red">
                        Reserved
                    </Text>
                )}
            </form>
        </div>
    )
}
