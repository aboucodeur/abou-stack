import React from 'react'
import { Anchor, Button, Card, Grid, List, NumberInput, Text } from '@mantine/core'
import { modals } from "@mantine/modals"
import { addVendreRetour, addVendreRetourContenu, editVendreRetourContenu, getVendreRetour, getVendreRetourContenu } from '../../services/api'
import { useMutation, useQuery, useQueryClient } from 'react-query'
import { getError } from '../../utils'
import useForm from '../../hooks/useForm'
import { IconCheck, IconEdit } from '@tabler/icons-react'
import { AppTable } from '../../components'

export default function VenteRetour({ vendId, vendreInfo }) {
    const [viewTable, setViewTable] = React.useState({ isView: false, data: {}, isEdit: false, editData: {} })
    const [rowsId, setRowsId] = React.useState(null)

    const query = useQueryClient()

    const { data: achatRetour = [] } = useQuery(["vendres_retd", vendId], ({ queryKey }) => getVendreRetour(queryKey[1]))
    const { data: achatRetourContenu = [] } = useQuery(["vendres_retc", viewTable.data.vr_id], ({ queryKey }) => getVendreRetourContenu(queryKey[1]))
    const { mutate: addRetour } = useMutation(["vendres_retd"], addVendreRetour)
    const { mutate: addRetourContenu } = useMutation(["vendres_retc"], addVendreRetourContenu)
    const { formValues, setValues, cleanForm } = useForm({ qte: 0 })
    const { mutate } = useMutation(["vendres_retc"], editVendreRetourContenu)

    const handleClick = (id) => {
        if (viewTable.isView) return
        addRetour({ date: new Date().toISOString(), vendId: id }, {
            onSuccess() { query.invalidateQueries("vendres_retd") },
            onError(err) {
                const error = getError(err)
                if (error) {
                    modals.open({
                        title: "Notification",
                        centered: true,

                        children: error
                    })
                }
            }
        })
    }
    const handlePlaceContent = (id) => addRetourContenu(id, { onSuccess: () => query.invalidateQueries("vendres_retc") })
    const handleEdit = (id) => {
        mutate({ ...formValues, vrcId: id }, {
            onSuccess() {
                query.invalidateQueries("vendres_retc")
                query.invalidateQueries("vendres_info")
                query.invalidateQueries("vendres_cmd")
                setRowsId(null)
                cleanForm()
            },
            onError(err) {
                const error = getError(err)
                if (error) setRowsId(null)
            }
        })
    }

    const tableRows = achatRetourContenu.map(d => (
        <tr key={d.vrc_id}>
            <td><Text>{d.pr_nom}</Text></td>
            <td>{d.vrc_id === rowsId ?
                <NumberInput
                    autoComplete="off"
                    autoCorrect="off"
                    max={d.reste_reel}
                    defaultValue={d.vrc_qte}
                    onChange={value => setValues("qte", value)}
                /> : <Text>{d.vrc_qte}</Text>}</td>
            <td><Text color="red">{d.reste_reel}</Text></td>
            <td>
                {d.vrc_id === rowsId ?
                    <Button
                        onClick={() => handleEdit(d.vrc_id)}
                        color="green"
                        children={<IconCheck size={21} />}
                    /> :
                    <Button
                        disabled={parseInt(d.reste_reel, 10) === 0}
                        onClick={() => setRowsId(d.vrc_id)}
                        children={<IconEdit size={21} />}
                    />
                }
            </td>
        </tr>
    ))

    return (
        <Grid columns={30}>
            <Grid.Col md={6}>
                <Card direction="column" shadow="lg" sx={theme => ({ backgroundColor: theme.colors.blue[2], color: "white", width: "100%" })}>
                    {vendreInfo.vend_etat > 0 && <Button variant="white" onClick={() => handleClick(vendId)}>+</Button>}
                    <Text weight="bold" mt={5} order={4}>Dates</Text>
                    <List listStyleType="none">
                        {achatRetour.map(d => (
                            <List.Item key={d.vr_id}>
                                <Anchor onClick={() => {
                                    setViewTable(prevData => ({ ...prevData, isView: true, data: { ...d } }))
                                    handlePlaceContent(d.vr_id)
                                }}>{new Date(d.vr_date).toLocaleDateString()}</Anchor>
                            </List.Item>
                        ))}
                    </List>
                </Card>
            </Grid.Col>
            <Grid.Col md={24}>
                {viewTable.isView &&
                    <div>
                        <AppTable
                            title={`Retour du ${new Date(viewTable.data.vr_date).toLocaleDateString()}`}
                            tableHead={["Designation", "Retourner", "Reste", "Action"]}
                            tableRows={tableRows}
                        />
                    </div>
                }
            </Grid.Col>
        </Grid>
    )
}