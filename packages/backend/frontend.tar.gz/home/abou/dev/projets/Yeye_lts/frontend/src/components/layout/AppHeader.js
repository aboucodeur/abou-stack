import React from "react"
import { Fragment, useEffect, useState } from "react"
import {
    Header,
    Burger,
    MediaQuery,
    useMantineTheme,
    Group,
    Tooltip,
    Title,
    Button,
    Flex,
    UnstyledButton,
    Radio,
    Text,
} from "@mantine/core"
import { useAppState } from "../../context/AppContext"
import { NavLink } from "react-router-dom"
import { APP_NAME } from "../../constant"
import { modals, useModals } from "@mantine/modals"
import Caisse from "../../pages/action/Caisse"
import { IconCash, IconFocus, IconHelp, IconSettings } from "@tabler/icons-react"
import { currencys } from "../../helper"
import Cookies from "js-cookie"
import { useMultipleOnboardContext } from "../../onboard"
import { useLocalStorage, useTimeout } from "@mantine/hooks"
import useWindowSize from "react-use/lib/useWindowSize"
import Confetti from "react-confetti"

// layoutMode, setLayoutMode, cRole, toggle
export default function AppHeader({ opened, setOpened, cRole, tabMode }) {
    const { getUser, getShop } = useAppState()
    const isAdmin = getUser.us_role === "admin"
    const rootLink = isAdmin ? "/admin/dashboard" : "/acceuil"
    const theme = useMantineTheme()
    const [pick, setPick] = useState("XOF")
    const [pickLng, setPickLng] = useState("fr")

    const modal = useModals()
    const { setState } = useMultipleOnboardContext()

    // COMMENCER LE TOUR
    const [, setValue] = useLocalStorage({ key: "yy_start_tour" })
    const { width, height } = useWindowSize()
    const [show, setShow] = useState(false)
    const { start, clear } = useTimeout(() => setShow(false), 15 * 1000) // 15s

    const BREAKPOINTS = 0

    const consulationCaisse = () => {
        modals.open({
            title: "Consultation du caisse",
            children: <Caisse boId={getShop.bo_id} handleClose={() => modals.closeAll()} />,
        })
    }

    const openSettingPanel = () => {
        modals.open({
            title: "Settings",
            children: (
                <Fragment>
                    <Flex gap="md">
                        <Radio.Group
                            defaultValue={pick}
                            onChange={(value) => {
                                Cookies.set("yy_user_devis", value, {
                                    sameSite: "Strict",
                                    expires: 365,
                                })
                                setPick(value)
                            }}
                            label="Money devis"
                            withAsterisk
                        >
                            {currencys.map(({ value, label }, _idx) => (
                                <Radio
                                    m={5}
                                    key={_idx + 1}
                                    value={value}
                                    label={label}
                                    style={{ cursor: "pointer" }}
                                />
                            ))}
                        </Radio.Group>
                    </Flex>
                    <Flex gap="md">
                        <Radio.Group
                            defaultValue={pickLng}
                            onChange={(value) => {
                                Cookies.set("yy_user_lng", value, {
                                    sameSite: "Strict",
                                    expires: 365,
                                })
                                setPickLng(value)
                            }}
                            label="Styles"
                            withAsterisk
                        >
                            {[
                                { label: "Francais", value: "fr" },
                                { label: "Anglais", value: "en" },
                            ].map(({ value, label }, _idx) => (
                                <Radio
                                    m={5}
                                    key={_idx + 1}
                                    value={value}
                                    label={label}
                                    style={{ cursor: "pointer" }}
                                />
                            ))}
                        </Radio.Group>
                    </Flex>
                </Fragment>
            ),
        })
    }

    const handleClickStart = () => {
        modal.openModal({
            title: <Text>Tutoriels utilisateurs !</Text>,
            children: (
                <Button
                    onClick={() => {
                        setValue("y")
                        setState({ run: true, tourActive: true, stepIndex: BREAKPOINTS })
                        setShow(true)
                        modal.closeAll()
                    }}
                    color="orange"
                    radius="lg"
                >
                    Commencer !
                </Button>
            ),
        })
    }

    const MemoConfetti = React.memo(() => <Confetti run={show} width={width} height={height} />)

    useEffect(() => {
        const yy_user_devis = Cookies.get("yy_user_devis")
        const yy_user_lng = Cookies.get("yy_user_lng")
        if (yy_user_devis) setPick(yy_user_devis)
        if (yy_user_lng) setPickLng(yy_user_lng)
    }, [])

    useEffect(() => {
        if (show) start()

        return () => {
            clear()
        }
    }, [clear, show, start])

    return (
        <Header
            height={43}
            p="lg"
            sx={(theme) => ({
                backgroundColor: theme.colors.blue[9],
                color: "white",
                display: "flex",
                alignItems: "center",
            })}
        >
            {/* Prevent re-render  */}
            <MemoConfetti />
            {/* Mobile hamburger */}
            <MediaQuery largerThan="sm" styles={{ display: "none" }}>
                <Burger
                    opened={opened}
                    onClick={() => setOpened((o) => !o)}
                    size="sm"
                    color={theme.colors.gray[6]}
                    mr="xl"
                />
            </MediaQuery>
            {/* Menu */}
            <Group position="apart" style={{ width: "100%" }}>
                <Title order={3}>
                    <NavLink style={{ textDecoration: "none", color: "white" }} to={rootLink}>
                        {APP_NAME}
                    </NavLink>
                </Title>
                {cRole !== "admin" ? (
                    <Flex gap="xs">
                        <Tooltip label="Comment utiliser ?" withArrow>
                            <Button
                                variant="white"
                                color="orange"
                                radius="lg"
                                onClick={handleClickStart}
                            >
                                <IconHelp />
                            </Button>
                        </Tooltip>
                        <Tooltip label="Se concentrer" withArrow>
                            <UnstyledButton onClick={tabMode}>
                                <IconFocus />
                            </UnstyledButton>
                        </Tooltip>
                        <Tooltip label="Parametres" withArrow>
                            <UnstyledButton onClick={openSettingPanel}>
                                <IconSettings color="white" />
                            </UnstyledButton>
                        </Tooltip>
                        <Tooltip label="Ma caise" withArrow>
                            <Button onClick={consulationCaisse} variant="white">
                                <IconCash />
                            </Button>
                        </Tooltip>
                    </Flex>
                ) : null}
            </Group>
        </Header>
    )
}
