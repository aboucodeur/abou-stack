import { useState } from 'react'
import { Button, Group, Notification, NumberInput, Select } from '@mantine/core'
import useForm from '../../hooks/useForm'
import { useMutation, useQuery, useQueryClient } from 'react-query'
import {
    addVendreCommand,
    addVendreCommandWithCode,
    editProduct,
    getShopProductAdaptSelect,
} from '../../services/api'
import { useAppState } from '../../context/AppContext'
import { getError } from '../../utils'
import { Barcode } from '../../components'
import { Unity } from '../../mock'

export default function AddForm({ vendId }) {
    const { getShop } = useAppState()
    const shopId = getShop.bo_id
    const [max, setMax] = useState(0)
    const { formValues, formErr, setErrors, setValues } = useForm({ pr_id: '', qte: '', prix: 0 })
    const { data: shopProduct = [] } = useQuery(['pro_adapt', shopId], ({ queryKey }) =>
        getShopProductAdaptSelect(queryKey[1]),
    )
    const query = useQueryClient()
    const { mutate } = useMutation(['vendres_cmd'], addVendreCommand)
    const { mutate: addCommandWithCode } = useMutation(['vendres_cmd'], addVendreCommandWithCode)
    const { mutate: editProductUnite } = useMutation(['prod'], editProduct)

    const parsedProductId = formValues.pr_id
    const getUnite = parsedProductId
        ? shopProduct.find((d) => d.value === parsedProductId).pr_unite
        : ''

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate(
            { ...formValues, vendId },
            {
                onSuccess() {
                    query.invalidateQueries('vendres_cmd')
                    query.invalidateQueries('vendres_info')
                    setValues('qte', undefined)
                    setValues('prix', undefined)
                },
                onError(err) {
                    const error = getError(err)
                    if (error) setErrors('message', error)
                },
            },
        )
    }
    const handleAdd = (code) => {
        addCommandWithCode(
            { vendId, code },
            {
                onSuccess: () => {
                    query.invalidateQueries('vendres_cmd')
                    query.invalidateQueries('vendres_info')
                },
                onError: (err) => {
                    const error = getError(err)
                    if (error) setErrors('message', error)
                },
            },
        )
    }
    const handleEdit = (unite) => {
        if (parsedProductId) {
            const formData = new FormData()
            formData.append('unite', unite || getUnite)
            editProductUnite(
                { formData, prId: parsedProductId },
                {
                    onSuccess() {
                        query.invalidateQueries('prod')
                        query.invalidateQueries('pro_adapt')
                    },
                    onError(err) {
                        const error = getError(err)
                        if (error) setErrors('message', error)
                    },
                },
            )
        }
    }

    return (
        <div>
            {formErr.message && (
                <Notification color="red" m={5} onClose={() => setErrors('message', '')}>
                    {formErr.message}
                </Notification>
            )}
            <Barcode onScan={(barcode) => handleAdd(barcode)} notOff={true} />
            <form onSubmit={handleSubmit}>
                <Group spacing={3}>
                    <Select
                        label="Chercher ou selectionne"
                        nothingFound="Produit introuvable"
                        data={shopProduct}
                        searchable
                        clearable
                        defaultValue={formValues.pr_id}
                        required
                        onChange={(value) => {
                            if (!value) return
                            setValues('pr_id', value)
                            setValues('qte', 1)
                            setValues(
                                'prix',
                                parseFloat(shopProduct.find((d) => d.value === value).pr_pv),
                            )
                            setMax(parseInt(shopProduct.find((d) => d.value === value).pr_qte, 10))
                        }}
                        limit={300} // ** user perform search
                    />
                    <Select
                        label="Unites de vente"
                        placeholder="unites de vente"
                        data={Unity}
                        searchable
                        value={getUnite}
                        onChange={(value) => handleEdit(value)}
                        style={{ maxWidth: '150px' }}
                    />
                    <NumberInput
                        label={`En stock  (${max})`}
                        min={0}
                        maxLength={20}
                        autoComplete="off"
                        autoCorrect="off"
                        value={formValues.qte}
                        onChange={(value) => setValues('qte', value)}
                        required
                    />
                    <NumberInput
                        label="Le prix de vente"
                        min={0}
                        maxLength={20}
                        autoComplete="off"
                        autoCorrect="off"
                        value={formValues.prix}
                        onChange={(value) => setValues('prix', value)}
                        required
                        precision={2} // decimal
                    />
                    {max !== 0 && (
                        <Button type="submit" mt={25}>
                            +
                        </Button>
                    )}
                </Group>
            </form>
        </div>
    )
}
