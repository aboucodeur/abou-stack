// import 'whatwg-fetch'
import Cookies from 'js-cookie'

// ** CODE MONETAIRES
export const currencys = [
    { value: '', label: 'FRANCS' }, // directement vas macher avec le FR
    { value: 'XOF', label: 'Franc CFA d\'Afrique de l\'ouest' },
    { value: 'XAF', label: 'Franc CFA d\'Afrique centrale' },
    { value: 'DZD', label: 'Dinar algérien' },
    { value: 'EGP', label: 'Livre égyptienne' },
    { value: 'NGN', label: 'Naira nigérian' },
    { value: 'ZAR', label: 'Rand sud-africain' },
    { value: 'EUR', label: 'Euro' }
]

/**
 * @param {Intl.NumberFormatOptions} options 
 */
const formatWari = (value = 0, options) => {
    let formatter
    const getLng = Cookies.get('yy_user_devis') || 'fr'
    const getCurr = Cookies.get('yy_user_devis') || 'XOF'
    formatter = new Intl.NumberFormat(getLng, {
        style: 'currency',
        currency: getCurr,
        minimumFractionDigits: 0,
        maximumFractionDigits: 2,
        ...options
    })
    return formatter.format(value)
}

/**
 * @param {number} value 
 * @param {Intl.NumberFormatOptions} options 
 */
const formatNumber = (value = 0, options) => {
    const getLng = Cookies.get('yy_user_devis') || 'fr'
    const formatNumber = new Intl.NumberFormat(getLng, {
        style: 'decimal',
        minimumFractionDigits: 0,
        maximumFractionDigits: 2,
        ...options
    }).format(value)
    return formatNumber
}

export { formatWari, formatNumber }