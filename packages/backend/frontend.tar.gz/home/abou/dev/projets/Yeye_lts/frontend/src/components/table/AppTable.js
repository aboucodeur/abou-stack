import React from 'react'
import { createStyles, Table, Text, NumberInput, Group, UnstyledButton, ScrollArea } from '@mantine/core'
import { IconArrowLeft, IconArrowRight } from '@tabler/icons-react'

const useStyles = createStyles((theme) => ({
    header: {
        backgroundColor: theme.colorScheme === 'dark' ? theme.colors.dark[7] : theme.white,
        transition: 'box-shadow 150ms ease',
        // '&::after': {
        //     content: '""',
        //     position: 'absolute',
        //     left: 0,
        //     right: 0,
        //     bottom: 0,
        //     borderBottom: `1px solid ${theme.colorScheme === 'dark' ? theme.colors.dark[3] : theme.colors.gray[2]}`,
        // },
    },

}))

export default function AppTable({
    tableHead = [],
    tableRows = [],
    mw,
    h,
    title = "",
    paginate,
    page = 1,
    setPage,
    lim,
    tableContainerRef,
    ...props
}) {
    const { classes } = useStyles()
    const limit = lim || 6
    const total = tableRows.length || 0
    const pageCond = Math.ceil((total / limit))
    const pages = pageCond < 1 ? 1 : pageCond || 0
    const offset = ((page - 1) * limit) || 0
    const prevPage = () => setPage((prev) => prev === 1 ? 1 : prev - 1)
    const nextPage = () => setPage((prev) => prev === pages ? pages : prev + 1)

    React.useEffect(() => {
        if (!paginate) return
        if (pages) setPage(1)
    }, [paginate, pages, setPage])

    return (
        <div>
            <ScrollArea mb={5}>
                <Table
                    sx={{ minWidth: mw || "auto" }}
                    verticalSpacing={11}
                    highlightOnHover
                    fontSize={15}
                    mt={5}
                    style={{ userSelect: paginate ? "none" : undefined, maxHeight: "100%" }}
                    {...props}
                >
                    <thead className={classes.header}>
                        <tr style={{ userSelect: "none" }}>
                            {tableHead.map(d => <th key={d}><Text weight="bold" color="dimmed">{d}</Text></th>)}
                        </tr>
                    </thead>
                    <tbody>
                        {paginate ? Array.isArray(tableRows) && tableRows.slice(offset, page * limit) : tableRows}
                    </tbody>
                </Table>
            </ScrollArea>
            {
                paginate && pages > 1 ?
                    <Group style={{ userSelect: "none" }} spacing={3}>
                        <UnstyledButton onClick={() => prevPage()}>
                            <IconArrowLeft color="green" />
                        </UnstyledButton>
                        <NumberInput
                            min={1}
                            max={parseInt(pages, 10)}
                            maxLength={6}
                            style={{ width: "63px" }}
                            value={page}
                            onChange={(value) => (value > 0 && value <= pages) && setPage(value)}
                            hideControls
                            placeholder="pages"
                        />
                        <Text>Pages : {page} / {pages}</Text>
                        <UnstyledButton onClick={() => nextPage()}>
                            <IconArrowRight color="green" />
                        </UnstyledButton>
                    </Group>
                    : null
            }
        </div >
    )
}