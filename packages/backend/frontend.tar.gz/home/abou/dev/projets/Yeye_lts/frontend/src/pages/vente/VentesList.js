import { ActionIcon, Anchor, Button, Group, Paper, Select, Text, Tooltip } from '@mantine/core'
import { Link } from 'react-router-dom'
import { pgDate } from '../../utils'
import { DatePickerInput } from '@mantine/dates'
import { useAppState } from '../../context/AppContext'
import { modals } from '@mantine/modals'
import useSearch from '../../hooks/useSearch'
import 'dayjs/locale/fr'
import { useQuery } from 'react-query'
import { getShopClientAdaptSelect, getShopVendre } from '../../services/api'
import AddVendreModal from './AddVendreModal'
import RemVendreModal from './RemVendreModal'
import { IconCalendar, IconSelect, IconTrash } from '@tabler/icons-react'
import useHeight from '../../hooks/useHeight'
import VirtualTable from '../../components/table/VirtualTable'
import { SearchFound } from '../../components'
import { formatNumber, formatWari } from '../../helper'
import { useMemo } from 'react'

export default function VentesList() {
    const { getShop, getUser } = useAppState()
    const { searchVal, setSearch } = useSearch({ date: new Date(), clId: null })
    const shopId = getShop.bo_id
    const userId = getUser.us_id
    const { data: shopClient = [] } = useQuery(['clt_adapt', shopId], ({ queryKey }) =>
        getShopClientAdaptSelect(queryKey[1]),
    )
    const { data: shopVendre = [] } = useQuery(
        ['vendres', shopId, pgDate(searchVal.date)],
        ({ queryKey }) => getShopVendre(queryKey[1], queryKey[2]),
    )
    const { wH } = useHeight(80)

    const addModal = () => {
        modals.open({
            title: 'Operation de vente',
            children: (
                <AddVendreModal
                    boId={shopId}
                    usId={userId}
                    shopClient={shopClient}
                    handleClose={() => modals.closeAll()}
                />
            ),
        })
    }
    const delModal = (Id) => {
        modals.open({
            title: 'Suppression de la vente',
            children: <RemVendreModal id={Id} handleClose={() => modals.closeAll()} />,
        })
    }

    const isArr = Array.isArray(shopVendre)
    const vTotal = useMemo(
        () => isArr && shopVendre.reduce((curr, acc) => curr + parseFloat(acc.total), 0),
        [isArr, shopVendre],
    )
    const filtereShopVendre = isArr
        ? shopVendre.filter((d) => (!searchVal.clId ? d : d.cl_id === searchVal.clId))
        : []
    const Rows = ({ index }) => {
        const { vend_id, vend_date, nom, cl_nom, vend_etat, total } = filtereShopVendre[index]
        return (
            <tr>
                <td style={{ height: '36px' }}>
                    <Text>{index + 1}</Text>
                </td>
                <td>{new Date(vend_date).toLocaleString()}</td>
                <td>{nom}</td>
                <td>{cl_nom}</td>
                <td>{formatNumber(total)}</td>
                <td>
                    <Group spacing={15}>
                        <Tooltip withArrow label="Detail de la vente">
                            <Anchor component={Link} to={`/ventes/${vend_id}`}>
                                Details
                            </Anchor>
                        </Tooltip>
                        {(vend_etat === 0 || total <= 0) && (
                            <ActionIcon
                                color="red"
                                onClick={() => delModal(vend_id)}
                                disabled={vend_etat !== '0' && total > 0 && true}
                            >
                                <IconTrash />
                            </ActionIcon>
                        )}
                    </Group>
                </td>
            </tr>
        )
    }

    return (
        <div>
            <Group algin="normal" mt={5} spacing={3}>
                <DatePickerInput
                    locale="fr"
                    placeholder="Date ..."
                    value={searchVal.date}
                    onChange={(value) => setSearch('date', value)}
                    icon={<IconCalendar size={21} />}
                    clearable
                />
                <Select
                    data={shopClient}
                    placeholder="Nom du client"
                    clearable
                    searchable
                    nothingFound="Client introuvable"
                    onChange={(value) => setSearch('clId', value)}
                    icon={<IconSelect size={21} />}
                />
                <Tooltip label="Operation de vente">
                    <Button onClick={addModal} variant="outline">
                        VENDRE
                    </Button>
                </Tooltip>
            </Group>
            {shopVendre.length === 0 ? (
                <SearchFound message="Aucune vente pour cette date" />
            ) : (
                <div>
                    <Paper shadow="lg" mt={3} p={12} style={{ userSelect: 'none' }}>
                        <Text color="blue">Montant(s) Total(s) : {formatWari(vTotal)} </Text>
                    </Paper>
                    <VirtualTable
                        header={['N°', 'Date', 'Vendeur', 'Client', 'Montant', 'Action']}
                        height={wH}
                        itemCount={filtereShopVendre.length}
                        row={Rows}
                    />
                </div>
            )}
        </div>
    )
}
