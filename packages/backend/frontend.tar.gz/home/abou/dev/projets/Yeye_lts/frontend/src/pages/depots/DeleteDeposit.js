import React from 'react'
import { Button } from '@mantine/core'
import { useMutation, useQueryClient } from 'react-query'
import { removeDepot } from '../../services/api'

export default function DeleteDeposit({ data, handleClose }) {
    const { mutate } = useMutation(removeDepot)
    const query = useQueryClient()
    const handleDelete = () => {
        mutate({ deId: data.de_id }, {
            onSuccess: () => {
                query.invalidateQueries("dep")
                handleClose()
            }
        })
    }

    return <Button color="red" onClick={() => handleDelete()}>Suppression du depot :  {data.de_nom}</Button>
}