import React from 'react'
import { Button, Notification, Textarea, TextInput, Title } from '@mantine/core'
import useForm from "../../hooks/useForm"
import { useMutation, useQueryClient } from 'react-query'
import Cookies from 'js-cookie'
import { useAppState } from '../../context/AppContext'
import { editBoutique } from '../../services/api'
import { getError } from '../../utils'
import { SHOP_EDIT } from "../../context/action/action"

export default function EditShop({ data, boId, handleClose }) {
    const { dispatch } = useAppState()
    const { formValues, formErr, handleChange, setValues, setErrors } = useForm({ nom: "", tel: "", email: "", adr: "" })
    const query = useQueryClient()
    const { mutate } = useMutation(["shop"], editBoutique)

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ ...formValues, boId }, {
            onSuccess: (data) => {
                query.invalidateQueries("shop")
                Cookies.remove("yy_shop_token")
                Cookies.set("yy_shop_token", JSON.stringify(data), { sameSite: "Strict", expires: 365 })
                dispatch({
                    type: SHOP_EDIT,
                    payload: {
                        edit: {
                            id: boId,
                            nom: data.bo_nom,
                            tel: data.bo_tel,
                            email: data.bo_email,
                            adr: data.bo_adr
                        }
                    }
                })
                handleClose()
            },
            onError: (err) => {
                const error = getError(err)
                if (error) setErrors("message", error)
            }
        })
    }

    React.useEffect(() => {
        setValues("nom", data.bo_nom)
        setValues("tel", data.bo_tel)
        setValues("adr", data.bo_adr)
        setValues("email", data.bo_email)
    }, [data, setValues])

    return (
        <div>
            {formErr.message && <Notification m={5} onClose={() => setErrors("message", "")} color="red" title={<Title order={3}>Erreur</Title>}>{formErr.message}</Notification>}
            <form onSubmit={handleSubmit}>
                <TextInput
                    label="Nom de la boutique"
                    autoComplete="off"
                    autoCorrect="off"
                    name="nom"
                    value={formValues.nom}
                    onChange={handleChange}
                />
                <TextInput
                    label="Telephone"
                    autoComplete="off"
                    autoCorrect="off"
                    name="tel"
                    value={formValues.tel}
                    onChange={handleChange}
                />
                <TextInput
                    label="Email"
                    type="email"
                    autoComplete="off"
                    autoCorrect="off"
                    name="email"
                    value={formValues.email}
                    onChange={handleChange}
                />
                <Textarea
                    spellCheck={false}
                    label="Adresse"
                    autoComplete="off"
                    autoCorrect="off"
                    name="adr"
                    value={formValues.adr}
                    onChange={handleChange}
                />
                <Button mt={5} type="submit">Modifier</Button>
            </form>
        </div>
    )
}