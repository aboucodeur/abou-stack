import React from "react";
import { Anchor, Badge, Button, Card, Grid, Group, Loader, Tabs, Text, Title, Tooltip, } from "@mantine/core";
import { modals } from "@mantine/modals";
import { useParams } from "react-router-dom";
import VenteContenu from "./VenteContenu";
import VenteValidation from "./VenteValidation";
import VentePaiement from "./VentePaiement";
import VenteLivraison from "./VenteLivraison";
import VenteRetour from "./VenteRetour";
import { useQuery } from "react-query";
import {
  getClientCcompte,
  getVendre,
  getVendreCommand,
  getVendrePaiement,
} from "../../services/api";
import { API_URL } from "../../constant";
import { ImageIcon } from "../../components";
import { carsIcon, cashIcon, pannierIcon } from "../../constants";
import { IconArrowLeft, IconPrinter } from "@tabler/icons-react";
import { formatWari } from "../../helper";

const VenteDetails = React.memo(() => {
  const { id } = useParams()
  const vendId = parseInt(id, 10)

  const { data: vendreInfo = [], isLoading } = useQuery(["vendres_info", vendId], ({ queryKey }) => getVendre(queryKey[1]));
  const { data: vendreCommand = [] } = useQuery(["vendres_cmd", vendId], ({ queryKey }) => getVendreCommand(queryKey[1]));
  const { data: vendrePaiement = [] } = useQuery(["vendres_pay", vendId], ({ queryKey }) => getVendrePaiement(queryKey[1]));
  // ** l'argent de compte du client
  const { data: clientCompte = [] } = useQuery(["clt_comp", vendreInfo.cl_id], ({ queryKey }) => getClientCcompte(queryKey[1]));

  const handleValidate = (vendId, etat = "") => {
    modals.open({
      title: <Title order={4}>Valider la vente pour la suite ?</Title>,
      children: (
        <VenteValidation
          vendId={vendId}
          handleClose={() => modals.closeAll()}
          etat={etat}
        />
      ),
    });
  }

  if (isLoading)
    return (
      <div>
        <Text>Chargements des ventes en cours ... </Text>
        <Loader />
      </div>
    )

  const total = parseFloat(vendreInfo.montant)
  const payer = parseFloat(vendreInfo.payer)
  const reste = total - payer

  return (
    <Grid columns={30}>
      <Grid.Col md={8}>
        <Card
          shadow="lg"
          sx={(theme) => ({
            backgroundColor: theme.colors.blue[6],
            color: "white",
          })}
        >
          <Text>
            Date de vente :{" "}
            {new Date(vendreInfo.vend_date).toLocaleDateString()}
          </Text>
          <Text>Client : {vendreInfo.cl_nom}</Text>
          {Array.isArray(clientCompte) ? (
            <Text>
              Son compte : {formatWari(clientCompte[0]?.cc_mte)}
            </Text>
          ) : null}
          <Text>Vendeur : {vendreInfo.vend_nom}</Text>
          <Text>Montant Total(s) : {formatWari(total)} </Text>
          <Text>Payer : {formatWari(payer)} </Text>
          <Text weight="bold">Reste : {formatWari(reste)} </Text>
          <Text>
            Etat de la vente :{" "}
            {vendreInfo.vend_etat === 0
              ? "En cours"
              : vendreInfo.vend_etat === 1
                ? "Valider"
                : vendreInfo.vend_etat === 2
                  ? "Payer"
                  : "Livrer"}
          </Text>
          <Group spacing={3}>
            {vendreInfo.vend_etat === 0 && vendreCommand.length > 0 ? (
              <Button variant="white" onClick={() => handleValidate(vendId)}>
                Valider la vente
              </Button>
            ) : null}
            {vendreInfo.vend_etat > 0 ? (
              <Group spacing={1}>
                <Tooltip label="Impirmer">
                  <Button
                    m={5}
                    variant="white"
                    component={Anchor}
                    href={`${API_URL}/documents/vendre/${vendId}`}

                    target="_blank"
                    color="green"
                  >
                    <IconPrinter />
                    {" "}
                    Facture
                  </Button>
                </Tooltip>
                <Button
                  m={5}
                  variant="white"
                  component={Anchor}
                  href={`${API_URL}/documents/vendre/${vendId}?type=p`}
                  target="_blank"
                // color="green"
                >
                  <IconPrinter />
                  {" "}
                  Proforma
                </Button>
              </Group>
            ) : null}
            {/* Afficher seulement pour le proprietaire de la boutique */}
            {vendreInfo.vend_etat > 0 ? (
              <Tooltip label="Attention" withArrow>
                <Button
                  m={5}
                  variant="white"
                  color="orange"
                  onClick={() => handleValidate(vendId, "0")}
                >
                  Devalider
                </Button>
              </Tooltip>
            ) : null}
          </Group>
        </Card>
      </Grid.Col>
      <Grid.Col md={22}>
        <Tabs defaultValue="first">
          <Tabs.List m={5}>
            <Tabs.Tab
              icon={<ImageIcon src={pannierIcon} alt="basket_icon" />}
              value="first"
            >
              Contenu{" "}
              {vendreInfo.vend_etat > 0 ? <Badge m={5}>OK</Badge> : null}
            </Tabs.Tab>
            <Tabs.Tab
              icon={<ImageIcon src={cashIcon} alt="cash_icon" />}
              value="second"
            >
              Paiement{" "} {vendreInfo.vend_etat > 1 ? <Badge m={5}>OK</Badge> : null}
            </Tabs.Tab>
            <Tabs.Tab
              icon={<ImageIcon src={carsIcon} alt="cars_icon" />}
              value="third"
            >
              Livraison{" "} {vendreInfo.is_liv ? <Badge m={5}>OK</Badge> : null}
            </Tabs.Tab>
            <Tabs.Tab icon={<IconArrowLeft />} value="four">
              Retour {vendreInfo.is_ret ? <Badge m={5}>OK</Badge> : null}
            </Tabs.Tab>
          </Tabs.List>
          <Tabs.Panel value="first">
            <VenteContenu
              vendId={vendId}
              getSum={total}
              vendreInfo={vendreInfo}
              vendreCommand={vendreCommand}
            />
          </Tabs.Panel>
          <Tabs.Panel value="second">
            <VentePaiement
              vendId={vendId}
              vendreInfo={vendreInfo}
              vendrePaiement={vendrePaiement}
              getPaySum={payer}
              rest={reste}
            />
          </Tabs.Panel>
          <Tabs.Panel value="third">
            <VenteLivraison vendId={vendId} vendreInfo={vendreInfo} />
          </Tabs.Panel>
          <Tabs.Panel value="four">
            <VenteRetour vendId={vendId} vendreInfo={vendreInfo} />
          </Tabs.Panel>
        </Tabs>
      </Grid.Col>
    </Grid>
  );
}, []);
export default VenteDetails;
