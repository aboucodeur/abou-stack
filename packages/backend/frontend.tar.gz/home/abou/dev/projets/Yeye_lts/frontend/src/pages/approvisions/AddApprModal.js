import { Button, Notification, Textarea } from "@mantine/core"
import { useMutation, useQueryClient } from "react-query"
import { useNavigate } from "react-router-dom"
import useForm from "../../hooks/useForm"
import { addShopApprovision } from "../../services/api"
import { getError } from "../../utils"
import { useFocusTrap } from "@mantine/hooks"

export default function AddApprModal({ boId, handleClose }) {
    const { formValues, formErr, handleChange, getInputProps, cleanForm, setErrors } = useForm(
        { motif: `approvisionnement du ${new Date().toLocaleString().split(" ").join(" à ")}` }
    )
    const query = useQueryClient()
    const navigate = useNavigate()
    const { mutate } = useMutation(["appr"], addShopApprovision)
    const focusTrap = useFocusTrap()

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ ...formValues, bo_id: boId }, {
            onSuccess: (data) => {
                const { apId } = data
                query.invalidateQueries("appr")
                cleanForm()
                handleClose()
                navigate(`/approvisions/${apId}`)
            },
            onError: (err) => {
                const error = getError(err)
                if (error) setErrors("message", err)
            }
        })
    }

    return (
        <div>
            <form onSubmit={handleSubmit} ref={focusTrap}>
                {formErr.message && <Notification m={5} color="red">{formErr.message}</Notification>}
                <Textarea
                    label="Description"
                    description="300 caracteres maximum"
                    maxLength={300}
                    {...getInputProps("motif")}
                    onChange={handleChange}
                    data-autofocus
                />
                <Button mt={5} type="submit" fullWidth variant='outline' color='green'>Ajouter</Button>
            </form>
        </div>
    )
}