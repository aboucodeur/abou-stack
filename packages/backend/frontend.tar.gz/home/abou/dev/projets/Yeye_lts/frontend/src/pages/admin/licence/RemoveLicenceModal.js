import { Button } from '@mantine/core'
import { useMutation, useQueryClient } from "react-query"
import { removeShopLicence } from '../../../services/api'

export default function RemoveLicenceModal({ licId, handleClose }) {
    const query = useQueryClient()
    const { mutate } = useMutation(["lic"], removeShopLicence)
    const handleRemove = (licId) => {
        mutate(licId, {
            onSuccess() {
                query.invalidateQueries("lic")
                handleClose()
            }
        })
    }
    return <Button color="red" onClick={() => handleRemove(licId)}>Oui, Supprimer</Button>
}