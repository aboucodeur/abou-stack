import { Tabs } from "@mantine/core"
import VentesList from "./VentesList"
import VentePayPage from "./VentePayPage"
import VenteLivPage from "./VenteLivPage"
import VenteIa from "./VenteIa"
import ImageIcon from "../../components/icons/ImageIcon"
import { cashIcon, contentIcon, iaIcon } from "../../constants"
import { IconReceipt } from "@tabler/icons-react"

export default function VentePage() {
    return (
        <Tabs defaultValue="1">
            <Tabs.List>
                <Tabs.Tab icon={<ImageIcon src={iaIcon} alt="ia_icon" />} value="0">Predictions (IA) </Tabs.Tab>
                <Tabs.Tab icon={<ImageIcon src={contentIcon} alt="content_icon" />} value="1">Principale</Tabs.Tab>
                <Tabs.Tab icon={<ImageIcon src={cashIcon} alt="cash_icon" />} value="2">Paiements et Credits</Tabs.Tab>
                <Tabs.Tab icon={<IconReceipt size={21} />} value="3">Livraison</Tabs.Tab>
            </Tabs.List>
            <Tabs.Panel value="0"><VenteIa /></Tabs.Panel>
            <Tabs.Panel value="1"><VentesList /></Tabs.Panel>
            <Tabs.Panel value="2"><VentePayPage /></Tabs.Panel>
            <Tabs.Panel value="3"><VenteLivPage /></Tabs.Panel>
        </Tabs >
    )
}