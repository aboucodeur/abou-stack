import { useLocation, useNavigate } from 'react-router-dom'
import { Title, Card, Button, Text } from "@mantine/core"
import Cookies from 'js-cookie'
import { useMutation, useQueryClient } from 'react-query'
import { SHOP_GET } from '../../context/action/action'
import { useAppState } from '../../context/AppContext'
import { instance } from '../../axios'
import { redirectUser } from '../../utils'

export default function UserChoice({ data, handleClose }) {
    const location = useLocation()
    const navigate = useNavigate()
    const { dispatch, getUser } = useAppState()
    const origin = redirectUser(location?.state?.from?.pathname, getUser.us_role)
    // ** boot element
    const query = useQueryClient()
    const { mutate: appMock } = useMutation(["app-mock"], async (boId) => instance.post(`/mock/${boId}`).then(res => res.data))
    const handlePlaceClient = (id) => {
        appMock(id, {
            onSuccess() {
                query.invalidateQueries("clt")
                query.invalidateQueries("clt_adapt")
            }
        })
    }

    return (
        <Card mt={1} shadow="lg" sx={(theme) => ({ backgroundColor: theme.colors.blue[6], color: "white" })}>
            {data.map((d, idx) => {
                return (
                    <div key={idx}>
                        <Title order={4}>{d.bo_nom}</Title>
                        <Text>Telephone : {d.bo_tel}</Text>
                        <Text>Adresse : {d.bo_adr}</Text>
                        <Text>Eamil : {d.bo_email}</Text>
                        <Button
                            variant="white"
                            onClick={() => {
                                dispatch({ type: SHOP_GET, payload: { shops: d } })
                                const onedayInMS = 1000 * 60 * 60 * 24 // ** expiration pour une journee
                                Cookies.set("yy_shop_token", JSON.stringify(d),
                                    {
                                        sameSite: "Strict",
                                        expires: new Date(Date.now() + onedayInMS),
                                    })
                                handlePlaceClient(d.bo_id)
                                navigate(origin)
                                handleClose()
                            }}
                        >se connecter</Button>
                    </div>
                )
            })}
        </Card>
    )
}