import { useQuery } from 'react-query'
import HomeCard from './HomeCard'
import { Group, Loader, Text, TextInput } from "@mantine/core"
import { getBoutiqueToday } from '../../services/api'
import { toLower } from '../../utils'
import { IconSearch } from '@tabler/icons-react'
import useSearch from '../../hooks/useSearch'
import { SearchFound, VirtualTable } from '../../components'
import useHeight from '../../hooks/useHeight'
import { formatNumber } from '../../helper'
import { useMemo } from 'react'

export default function StockToday({ boId }) {
    const { data: shopToday = {}, isLoading } = useQuery(["stock_prev", boId], ({ queryKey }) => getBoutiqueToday(queryKey[1]))
    const { searchVal, handleSearch, getSearchProps } = useSearch({ nom: "" })
    const { wH } = useHeight(170)

    const searchFilter = (data) => {
        const { pr_nom } = data
        const query = searchVal.nom.trim()
        if (!query) return data
        if (toLower(pr_nom).includes(toLower(query))) return data
    }

    const isArr = Array.isArray(shopToday?.data?.ventes)
    const filteredShopDatas = isArr ? shopToday?.data?.ventes.filter(searchFilter) : []
    const Rows = ({ index }) => {
        const { createdAt, pr_nom, ven_prix, ven_qte, pr_appr, montant } = filteredShopDatas[index]
        return (
            <tr>
                <td style={{ height: "36px" }}><Text>{index + 1}</Text></td>
                <td><Text>{new Date(createdAt).toLocaleString()}</Text></td>
                <td><Text>{pr_nom}</Text></td>
                <td><Text>{formatNumber(ven_prix)}</Text></td>
                <td><Text>{formatNumber(ven_qte)}</Text></td>
                <td><Text color={pr_appr <= "0" ? "green" : "red"}>{formatNumber(montant)}</Text></td>
            </tr>
        )
    }

    const total = useMemo(() => isArr && shopToday?.data?.ventes.reduce((acc, curr) => acc + parseFloat(curr.ven_qte, 10), 0), [isArr, shopToday])

    if (isLoading) return <Loader />
    return (
        <div>
            <Group align='normal' spacing={3}>
                {Array.isArray(shopToday.carte)
                    ? shopToday.carte.map(d => (
                        <HomeCard
                            title={d.title}
                            desc={d.desc}
                            total={d.total}
                            key={d.title}
                        />))
                    : null}
            </Group>
            <Text>Quantite totals vendus : {total}</Text>
            {isArr && shopToday?.data?.ventes.length === 0
                ? <SearchFound message="Vous n'avez pas fait de vente aujourd'hui !" />
                : <div>
                    <TextInput
                        mt={5}
                        placeholder="Chercher un produit"
                        autoComplete="off"
                        autoCorrect="off"
                        icon={<IconSearch size={21} />}
                        {...getSearchProps("nom")}
                        onChange={handleSearch}
                    />
                    <VirtualTable
                        header={["N°", "Date/Heure", "Produit", "P. vente", "Qte", "Montants"]}
                        height={wH}
                        itemCount={filteredShopDatas?.length}
                        row={Rows}
                    />
                </div>
            }
        </div>
    )
}