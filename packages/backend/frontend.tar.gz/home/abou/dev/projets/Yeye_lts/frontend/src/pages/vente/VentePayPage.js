import { useQuery } from "react-query"
import { Link } from "react-router-dom"
import { getVendreInfoPaiement } from "../../services/api"
import { Anchor, Badge } from "@mantine/core"
import { useAppState } from "../../context/AppContext"
import { MTRTable } from "../../components"
import { formatNumber } from "../../helper"

export default function VentePayPage() {
    const { getShop } = useAppState()
    const shopId = getShop.bo_id
    const { data: venteInfoPay = [], isLoading, isFetching, isError } = useQuery(["vendres_info_p", shopId], ({ queryKey }) => getVendreInfoPaiement(queryKey[1]))


    return (
        <MTRTable
            uId='vend_id'
            columns={[
                {
                    accessorKey: 'v_date',
                    accessorFn: (originalRow) => new Date(originalRow.v_date).toLocaleDateString(),
                    header: 'Date',
                    enableGrouping: true,
                },
                {
                    accessorKey: 'cl_nom',
                    header: 'Client',
                    enableGrouping: true,
                },
                {
                    accessorKey: 'montant',
                    header: 'Montant',
                    enableGrouping: false,
                    Cell: ({ cell }) => formatNumber(cell.getValue()),
                },
                {
                    accessorKey: 'payer',
                    header: 'Payer',
                    enableGrouping: false,
                    Cell: ({ cell }) => formatNumber(cell.getValue()),
                },
                {
                    accessorKey: 'appr',
                    header: 'Etat',
                    Cell: ({ cell }) => {
                        return <Badge
                            color={cell.getValue() === 0 ? "red" : cell.getValue() === 1 ? "green" : "gray"}>
                            {cell.getValue() === 0 ? "Pas Payer" : cell.getValue() === 1 ? "Payer" : "Retourner"}
                        </Badge>
                    }
                },
            ]}
            data={venteInfoPay}
            enableGrouping={true}
            initialState={{
                grouping: ['appr']
            }}
            hooksEditingOptions={{
                enableEditing: true,
                positionActionsColumn: 'last'
            }}
            enableColumnFilters={true}
            renderRowActions={({ row }) => {
                return <Anchor component={Link} to={`/ventes/${row.original.vend_id}`}>
                    Details
                </Anchor>
            }}
            visual={{
                dataLoader: isLoading,
                dataError: isError,
                dataFetching: isFetching,
            }}
        />
    )
}