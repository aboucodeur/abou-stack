import { createContext, useCallback, useContext, useReducer } from "react"
import Cookies from "js-cookie"
import { instance } from "../axios"
// ** LES ACTIONS
import {
    AUTH_LOGIN,
    AUTH_LOGOUT,
    SHOP_EDIT,
    SHOP_GET,
    SHOP_LOGOUT,
    USER_LOGIN,
    USER_LOGOUT,
} from "./action/action"
import { useLocalStorage } from "@mantine/hooks"

const GlobalContext = createContext()
// ** APPLICATION STATE
const generateReducerCase = (stateKey) => (state, payload) => ({
    ...state,
    [stateKey]: { ...state[stateKey], ...payload },
})

const reducer = (state, { type, payload }) => {
    switch (type) {
        case AUTH_LOGIN:
            return { ...state, isAuth: true }
        case AUTH_LOGOUT:
            return { ...state, isAuth: false }
        case SHOP_GET:
            return generateReducerCase("shops")(state, payload.shops)
        case SHOP_EDIT:
            return generateReducerCase("shops")(state, payload.edit)
        case USER_LOGIN:
            return generateReducerCase("users")(state, payload.users)
        case USER_LOGOUT:
            return { ...state, isAuth: false }
        default:
            return state
    }
}
export default function AppContext({ children }) {
    const initialStates = { isAuth: false, users: {}, shops: {} }
    const [state, dispatch] = useReducer(reducer, initialStates)

    const [, setLocalSSID] = useLocalStorage({
        key: "yy_srv_socket_ssID",
    })
    const [, setLocalTour] = useLocalStorage({ key: "yy_start_tour" })

    const useSelector = useCallback((cb) => cb(state), [state])
    const getAuth = useSelector((state) => state.isAuth)
    const getUser = useSelector((state) => state.users)
    const getShop = useSelector((state) => state.shops)

    // api authorization request
    const token = Cookies.get(getUser.us_role === "admin" ? "yy_admin_token" : "yy_user_token")
    if (token) instance.defaults.headers.authorization = `Bearer ${token}`

    // deconnexion à l'application
    const logOut = () => {
        const currentRole = getUser.us_role
        dispatch({ type: AUTH_LOGOUT })
        if (currentRole !== "admin") {
            dispatch({ type: SHOP_LOGOUT })
            Cookies.remove("yy_user_token")
            Cookies.remove("yy_shop_token")
            setLocalSSID("")
            setLocalTour("n")
        } else Cookies.remove("yy_admin_token")
    }

    const value = {
        state,
        dispatch,
        useSelector,
        getAuth,
        getUser,
        getShop,
        logOut,
    }
    return <GlobalContext.Provider value={value}>{children}</GlobalContext.Provider>
}
export const useAppState = () => useContext(GlobalContext)
