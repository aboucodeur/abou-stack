import { Button, Notification, NumberInput, Select } from '@mantine/core'
import useForm from '../../hooks/useForm'
import { useMutation, useQuery, useQueryClient } from 'react-query'
import { getAdaptInvestisseur, payeApaiement } from '../../services/api'
import { useAppState } from '../../context/AppContext'
import { getError } from '../../utils'
import { useFocusTrap } from '@mantine/hooks'

export default function ARetraits({ acId, closeModal }) {
    const { getShop } = useAppState()
    const shopId = getShop.bo_id
    const { formValues, formErr, setErrors, setValues } = useForm({ inv_id: '', mte: 0 })
    const { data: actionnaires = [] } = useQuery(['act_adapt', shopId], ({ queryKey }) =>
        getAdaptInvestisseur(queryKey[1]),
    )
    const { mutate } = useMutation(['act_detail'], payeApaiement)
    const query = useQueryClient()
    const focusTrap = useFocusTrap()

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate(
            { ...formValues, ac_id: acId },
            {
                onSuccess() {
                    query.invalidateQueries('achats_pay')
                    setValues('mte', undefined)
                    closeModal()
                },
                onError(err) {
                    const error = getError(err)
                    if (error) setErrors('message', error)
                },
            },
        )
    }

    return (
        <div>
            {formErr.message && (
                <Notification color="red" m={5} onClose={() => setErrors('message', '')}>
                    {formErr.message}
                </Notification>
            )}
            <form onSubmit={handleSubmit} ref={focusTrap}>
                <Select
                    label="Choisir un actionnaire"
                    data={actionnaires}
                    searchable
                    clearable
                    nothingFound="Actionnaire introuvable"
                    defaultValue={formValues.pr_id}
                    onChange={(value) => {
                        if (!value) return
                        setValues('inv_id', value)
                    }}
                    required
                    data-autofocus
                    maxDropdownHeight={80}
                    dropdownPosition="bottom"
                />
                <NumberInput
                    label="Montant"
                    min={1}
                    maxLength={20}
                    autoComplete="off"
                    autoCorrect="off"
                    value={formValues.mte}
                    onChange={(value) => setValues('mte', value)}
                    required
                    precision={2}
                />
                <Button type="submit" color="green" fullWidth variant="outline">
                    Confirmer le paiement
                </Button>
            </form>
        </div>
    )
}
