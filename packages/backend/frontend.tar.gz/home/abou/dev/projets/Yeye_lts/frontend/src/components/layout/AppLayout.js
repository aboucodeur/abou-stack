import { Fragment, useEffect, useState } from "react"
import { Anchor, AppShell, Breadcrumbs, ScrollArea } from "@mantine/core"
import { NavLink, Outlet, useLocation } from "react-router-dom"
import AppHeader from "./AppHeader"
import AppNavbar, { mockdata } from "./AppNavbar"
import { useFullscreen, useLocalStorage } from "@mantine/hooks"
import { useAppState } from "../../context/AppContext"
import SEO from "../seo/SEO"

// ** FOCUS LINKS
const TabletLinks = ({ toDesk }) => {
    const [hasMany, setHasMany] = useState(false)
    const [links, setLinks] = useState([])
    const handleClick = (data) => {
        const subLinks = Array.isArray(data.links)
        if (subLinks) {
            setHasMany(true)
            setLinks([...links, ...data.links])
        }
    }
    const handleQuit = () => {
        setHasMany(false)
        setLinks([])
    }
    return (
        <ScrollArea pb={20} style={{ userSelect: "none" }}>
            {!hasMany ? (
                <Breadcrumbs m={5} separator="|">
                    {mockdata.map((d) => (
                        <Anchor
                            key={d.label}
                            component={NavLink}
                            to={d.link}
                            onClick={() => handleClick({ ...d })}
                        >
                            {d.label}
                        </Anchor>
                    ))}
                    <Anchor color="orange" onClick={() => toDesk()}>
                        Revenir en mode Bureau
                    </Anchor>
                </Breadcrumbs>
            ) : (
                <Breadcrumbs separator="Y">
                    {links.map((d) => (
                        <Anchor key={d.label} component={NavLink} to={d.link}>
                            {d.label}
                        </Anchor>
                    ))}
                    <Anchor color="red" onClick={() => handleQuit()}>
                        Fermer l'onglet{" "}
                    </Anchor>
                </Breadcrumbs>
            )}
        </ScrollArea>
    )
}

// ** APP LAYOUT
export default function AppLayout({ children }) {
    const [opened, setOpened] = useState(false)
    const { getUser } = useAppState()
    const currentRole = getUser.us_role
    const [layoutMode, setLayoutMode] = useLocalStorage({
        key: "yy_app_mode",
        defaultValue: "desk",
    })
    const { toggle } = useFullscreen()

    const tabMode = () => {
        setLayoutMode((prev) => (prev === "desk" ? "tab" : "desk"))
        toggle()
    }

    useEffect(() => {
        if (currentRole === "admin") setLayoutMode("desk")
    }, [currentRole, setLayoutMode])

    const location = useLocation()
    const [title, setTitle] = useState("Yeye | Stock & Entreprise")
    const pathname = location.pathname

    useEffect(() => {
        const DEFAULT_TITLE = "Yeye | Stock & Entreprise"
        const titlesPaths = {
            "/acceuil": "Stats | Yeye",
            "/depots": "Depots | Yeye",
            "/commandes/fournisseurs": "Achats | Yeye",
            "/ventes": "Ventes | Yeye",
            "/banque": "Banques | Yeye",
            "/ia": "IA | Yeye",
            "/clients": "Clients | Yeye",
            "/fournisseurs": "Fournisseurs | Yeye",
            "/depenses": "Depenses | Yeye",
            "/gerants": "Gerants | Yeye",
            "/moi/boutique": "Infos | Yeye",
            "/moi/password": "Password | Yeye",
        }
        if (titlesPaths[pathname]) setTitle(titlesPaths[pathname])
        else setTitle(DEFAULT_TITLE)
    }, [pathname])

    return (
        <AppShell
            position="fixed"
            navbarOffsetBreakpoint="sm"
            padding="md"
            styles={(theme) => ({
                main: {
                    backgroundColor:
                        theme.colorScheme === "dark" ? theme.colors.dark[8] : theme.colors.gray[0],
                },
            })}
            header={
                layoutMode === "tab" ? null : (
                    <AppHeader
                        opened={opened}
                        setOpened={setOpened}
                        cRole={currentRole}
                        tabMode={tabMode}
                    />
                )
            }
            navbar={
                layoutMode === "desk" ? <AppNavbar opened={opened} setOpened={setOpened} /> : null
            }
        >
            {layoutMode === "tab" ? <TabletLinks toDesk={tabMode} /> : null}

            <Fragment>
                <SEO title={title} />
                {children ? children : <Outlet />}
            </Fragment>
        </AppShell>
    )
}
