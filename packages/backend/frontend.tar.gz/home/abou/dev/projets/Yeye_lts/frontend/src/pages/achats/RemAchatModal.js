import { Button } from '@mantine/core'
import { removeShopAchat } from '../../services/api'
import { useMutation, useQueryClient } from "react-query"

export default function RemAchatModal({ id, handleClose }) {
    const query = useQueryClient()
    const { mutate } = useMutation(["achats"], removeShopAchat)
    const handleRemove = (id) => {
        mutate(id, {
            onSuccess() {
                query.invalidateQueries("achats")
                handleClose()
            }
        })
    }
    return <Button color="red" onClick={() => handleRemove(id)}>Oui, Supprimer</Button>
}