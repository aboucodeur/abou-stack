import { useState } from 'react';
import { createStyles, Image, Grid, Col, Container, Title, Button, TextInput, Textarea, Text, Group, Divider, Anchor, Notification, Tooltip } from '@mantine/core';
import { mobileLanding } from '../../constants';
import { IconArrowRight, IconMail, IconMessage, IconPhoneCall, IconSend, IconUser } from '@tabler/icons';
import { NavLink } from "react-router-dom"
import useForm from '../../hooks/useForm';
import { instance } from '../../axios';
import { getError, getUserLocation } from '../../utils';
import { useFocusTrap } from '@mantine/hooks';
import Cookies from 'js-cookie';
import { decodeToken } from 'react-jwt';

const useStyles = createStyles((theme) => ({
    wrapper: {
        paddingTop: `calc(${theme.spacing.xl} * 2)`,
        paddingBottom: `calc(${theme.spacing.xl} * 2)`,
    },
    title: {
        color: theme.colors.blue[6],
        fontFamily: `Greycliff CF, ${theme.fontFamily}`,
    },
}));

export default function Support() {
    const { classes } = useStyles()
    const [succes, setSucces] = useState("")
    const focusTrapRef = useFocusTrap();
    const { formValues, formErr, getInputProps, onError, cleanForm, setErrors, handleChange } = useForm({
        username: '',
        tel: '',
        email: '',
        message: "Ercivez ce que vous penser , ",
        metadata: []
    })

    // Avec tracking du geolocalisation
    const handleSubmit = (e) => {
        e.preventDefault()
        onError({ ...formValues }, async (values, err) => {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            const usernameRegex = /^[a-zA-Z0-9_]+(\s[a-zA-Z0-9_]+)*$/;
            // si c'est true c'est valide on veut le contraire
            if (!usernameRegex.test(values.username)) err.username = "Nom d'utilisateur incorrect"
            if (!emailRegex.test(values.email)) err.email = "Email incorrecte"
            // ** SEND TO SERVER AFTER PROCESSING
            if (Object.entries(err).length === 0) {
                const getUserToken = Cookies.get("yy_user_token")
                let decodedToken = null
                let metadata = ""
                if (getUserToken) decodedToken = decodeToken(getUserToken).users
                if (decodedToken) metadata += `[PROVIDER]prenom:${decodedToken.us_prenom},nom:${decodedToken.us_nom};`
                metadata += `[PLATFORM :${navigator.userAgent}];[DATE : ${new Date().toLocaleDateString()}];`
                try {
                    const userGEO = await getUserLocation()
                    metadata += `[GEO : IP:${userGEO.ip},COUNTRY:${userGEO.countryCode},LOC:${userGEO.loc}];`
                    const postedFeedback = await instance.post("/support", { ...values, metadata: metadata })
                    if (postedFeedback) { 
                        alert("Merci de nous avoir contacter !")
                        setSucces("Message envoyer avec success : " + values.username)
                        cleanForm()
                    }
                } catch (err) {
                    const error = getError(err)
                    setErrors("message", error)
                }
            }
        })
    }

    return (
        <div className={classes.wrapper}>
            <Container size="lg">
                <Grid id="faq-grid" gutter={50}>
                    <Col span={12} md={6}>
                        <Title mt={35} order={2} ta="left" className={classes.title}>
                            Nous contacter !
                        </Title>
                        <Divider mb={5} color="blue" />
                        <Text mb={5} color="dimmed">
                            Avec yeye tout le monde peut utiliser un logiciel de gestion
                            de stock portable et disponible partout.
                            Le support technique est actif 24H/7J pour vous repondre
                            au plutot possible ! dites ce que vous pensez.
                        </Text>
                        <Anchor href="mailto:codeurabou123@gmail.com">
                            <Button mb={5}>Contact par email</Button>
                        </Anchor>
                        {succes ? <Notification m={5} color="green" onClose={() => setSucces("")}>
                            {succes}
                        </Notification>
                            : null
                        }
                        <form onSubmit={handleSubmit} ref={focusTrapRef}>
                            <TextInput
                                label="Nom"
                                placeholder="Eg : Company Name or Name"
                                description="90 caracteres"
                                maxLength={90}
                                autoComplete="off"
                                autoCorrect="off"
                                {...getInputProps("username")}
                                onChange={handleChange}
                                error={formErr.username}
                                required
                                data-autofocus
                                icon={<IconUser />}
                                variant="filled"
                            />
                            <TextInput
                                label="Numero de telephone"
                                placeholder="Eg : 00223 94 86 00 00"
                                description="21 caracteres"
                                required
                                type="tel"
                                maxLength={21}
                                autoComplete="off"
                                autoCorrect="off"
                                onChange={handleChange}
                                {...getInputProps("tel")}
                                error={formErr.tel}
                                icon={<IconPhoneCall />}
                                variant="filled"
                            />
                            <TextInput
                                type="email"
                                label="Email"
                                placeholder="Eg : test@gmail.com"
                                description="100 caracteres"
                                maxLength={100}
                                autoComplete="off"
                                autoCorrect="off"
                                onChange={handleChange}
                                {...getInputProps("email")}
                                error={formErr.email}
                                icon={<IconMail />}
                                variant="filled"
                            />
                            <Textarea
                                label="Votre message (soyez respectueux dans votre message)"
                                description="300 caracteres"
                                required
                                placeholder=""
                                rows={45}
                                autosize
                                minRows={3}
                                maxRows={3}
                                maxLength={300}
                                onChange={handleChange}
                                {...getInputProps("message")}
                                error={formErr.message}
                                icon={<IconMessage />}
                                variant="filled"
                            />
                            <Group spacing={10} mt={10}>
                                <Tooltip label="Envoyer votre message" withArrow>
                                <Button
                                        color="green"
                                        leftIcon={<IconSend />}
                                    type="submit"
                                >
                                    Envoyez votre message
                                </Button>
                                </Tooltip>
                                <Button
                                    type="button"                                
                                    component={NavLink}
                                    to="/"
                                    leftIcon={<IconArrowRight />} color="orange"
                                >
                                    Retourner dans l'application
                                </Button>
                            </Group>
                        </form>
                    </Col>
                    <Col span={12} md={6}>
                        <Image mt={5} src={mobileLanding} alt="Yeye mobile image" width={345} />
                    </Col>
                </Grid>
            </Container>
        </div>
    );
}