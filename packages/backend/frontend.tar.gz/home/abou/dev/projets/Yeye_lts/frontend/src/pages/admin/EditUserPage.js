import React from 'react'
import useForm from "../../hooks/useForm"
import { Alert, Button, TextInput, Title } from '@mantine/core'
import { useMutation, useQueryClient } from 'react-query'
import { editUserInfo } from '../../services/api'
import { getError } from '../../utils'

export default function EditUserPage({ data, handleClose }) {
    const { formValues, formErr, handleChange, setValues, cleanForm, setErrors, getInputProps } = useForm({
        prenom: "",
        nom: "",
        tel: "",
        email: ""
    })

    const query = useQueryClient()
    const { mutate } = useMutation(["user"], editUserInfo)

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ ...formValues, usId: data.us_id }, {
            onSuccess() {
                query.invalidateQueries("user")
                cleanForm()
                handleClose()
            },
            onError(err) {
                const error = getError(err)
                setErrors("message", error)
            }
        })
    }

    React.useEffect(() => {
        setValues("prenom", data.us_prenom)
        setValues("nom", data.us_nom)
        setValues("tel", data.us_tel)
        setValues("email", data.us_email)
    }, [data, setValues])

    return (
        <div>
            {formErr.message && <Alert title={<Title order={3}>Erreur</Title>}>{formErr.message}</Alert>}
            <form onSubmit={handleSubmit}>
                <TextInput
                    label="Prenom"
                    placeholder="entrez le nouveau prenom"
                    autoComplete="off"
                    autoCorrect="off"
                    {...getInputProps("prenom")}
                    onChange={handleChange}
                />
                <TextInput
                    label="Nom"
                    placeholder="entrez le nouveau nom"
                    autoComplete="off"
                    autoCorrect="off"
                    {...getInputProps("nom")}
                    onChange={handleChange}
                />
                <TextInput
                    label="Telephone"
                    placeholder="entrez le numero de telephone"
                    autoComplete="off"
                    autoCorrect="off"
                    {...getInputProps("tel")}
                    onChange={handleChange}
                />
                <TextInput
                    type="email"
                    label="Email"
                    placeholder="entrez le nouveau email"
                    autoComplete="off"
                    autoCorrect="off"
                    {...getInputProps("email")}
                    onChange={handleChange}
                />
                <Button mt={5} type="submit">Modifier</Button>
            </form>
        </div>
    )
}