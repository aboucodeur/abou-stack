import { Button, Notification, Select, Textarea, TextInput } from '@mantine/core'
import { modals } from '@mantine/modals'
import { useMutation, useQueryClient } from 'react-query'
import { addShopAchat } from '../../services/api'
import useForm from '../../hooks/useForm'
import { useNavigate } from 'react-router-dom'
import AddFrs from '../fournisseurs/AddFrs'
import { getError } from '../../utils'
import { useFocusTrap } from '@mantine/hooks'
import { useEffect } from 'react'

export default function AddAchatModal({ boId, handleClose, shopFrs, setState = () => undefined }) {
    const navigate = useNavigate()
    const { formValues, formErr, setValues, handleChange, setErrors, cleanForm, getInputProps } =
        useForm({
            fo_id: null,
            ach_date: '',
            date: '',
            desc: `Commande du ${new Date().toLocaleString().split(' ').join(' a ')}`,
        })

    const { mutate } = useMutation(['achats'], addShopAchat)
    const focusTrap = useFocusTrap()
    const query = useQueryClient()

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate(
            { ...formValues, bo_id: boId },
            {
                onSuccess({ acId }) {
                    query.invalidateQueries('achats')
                    cleanForm()
                    handleClose()
                    navigate(`/commandes/fournisseurs/${acId}`)
                    // ** force user click no next, no prev
                    setState({ run: true, stepIndex: 16, acId })
                },
                onError(err) {
                    const error = getError(err)
                    if (error) setErrors('message', error)
                },
            },
        )
    }

    const handleAddFrs = () => {
        modals.open({
            title: 'Ajout rapide du fournisseur',
            children: <AddFrs boId={boId} handleClose={() => modals.closeAll()} />,
        })
    }

    useEffect(() => {
        if (Array.isArray(shopFrs) && shopFrs.length > 0) setValues('fo_id', shopFrs[0].value)
    }, [setValues, shopFrs])

    return (
        <div>
            {formErr.message && (
                <Notification color="red" onClose={() => setErrors('message', '')}>
                    {formErr.message}
                </Notification>
            )}
            <form onSubmit={handleSubmit} ref={focusTrap}>
                <TextInput
                    label="Saisir date manuel (automatique par defaut)"
                    type="date"
                    autoComplete="off"
                    autoCorrect="false"
                    {...getInputProps('ach_date')}
                    onChange={handleChange}
                />
                <TextInput
                    id="dateinput_add_achat_11"
                    label="Date de reception"
                    type="date"
                    autoComplete="off"
                    autoCorrect="off"
                    {...getInputProps('date')}
                    onChange={handleChange}
                    required
                    data-autofocus
                />
                <Select
                    id="select_add_achat_12"
                    label="Fournisseur"
                    value={formValues.fo_id}
                    data={shopFrs}
                    searchable
                    clearable
                    nothingFound={
                        <Button onClick={() => handleAddFrs()}>Ajouter le fournisseur</Button>
                    }
                    onChange={(value) => setValues('fo_id', value)}
                    required
                    dropdownPosition="bottom"
                    maxDropdownHeight={100}
                />
                <Textarea
                    spellCheck
                    label="Description"
                    description="300 caracteres maximum"
                    maxLength={300}
                    autoComplete="off"
                    autoCorrect="off"
                    {...getInputProps('desc')}
                    onChange={handleChange}
                    required
                />
                <Button
                    id="button_add_achat_submit_13"
                    color="green"
                    fullWidth
                    mt={5}
                    variant="outline"
                    type="submit"
                >
                    Ajouter
                </Button>
            </form>
        </div>
    )
}
