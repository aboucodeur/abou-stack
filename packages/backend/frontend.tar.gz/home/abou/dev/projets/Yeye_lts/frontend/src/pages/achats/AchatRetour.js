import React from 'react'
import { Anchor, Button, Card, Grid, List, NumberInput, Text } from '@mantine/core'
import { modals } from "@mantine/modals"
import { addAchatRetour, addAchatRetourContenu, editAchatRetourContenu, getAchatRetour, getAchatRetourContenu } from '../../services/api'
import { useMutation, useQuery, useQueryClient } from 'react-query'
import { getError } from '../../utils'
import useForm from '../../hooks/useForm'
import { IconCheck, IconPencil } from '@tabler/icons-react'
import { AppTable } from '../../components'

export default function AchatRetour({ acId }) {
    const [viewTable, setViewTable] = React.useState({ isView: false, data: {}, isEdit: false, editData: {} })
    const [rowsId, setRowsId] = React.useState(null)
    const { formValues, setValues, cleanForm } = useForm({ qte: 0 })

    const { mutate: addRetour } = useMutation(["achats_retd"], addAchatRetour)
    const { mutate: addRetourContenu } = useMutation(["achats_retc"], addAchatRetourContenu)
    const { mutate } = useMutation(["achats_retc"], editAchatRetourContenu)
    const { data: achatRetour = [] } = useQuery(["achats_retd", acId], ({ queryKey }) => getAchatRetour(queryKey[1]))
    const { data: achatRetourContenu = [] } = useQuery(["achats_retc", viewTable.data.ar_id], ({ queryKey }) => getAchatRetourContenu(queryKey[1]))
    const query = useQueryClient()

    const handleClick = (id) => {
        addRetour({ date: new Date().toISOString(), acId: id }, {
            onSuccess() {
                query.invalidateQueries("achats_retd")
                query.invalidateQueries("achats_retc")
            },
            onError(err) {
                const error = getError(err)
                if (error) {
                    modals.open({
                        title: "Notification",
                        children: error
                    })
                }
            }
        })
    }
    const handlePlaceContent = (id) => {
        if (viewTable.isView) return
        addRetourContenu(id, {
            onSuccess() { query.invalidateQueries("achats_retc") }
        })
    }
    const handleEdit = (id) => {
        mutate({ ...formValues, arcId: id }, {
            onSuccess() {
                query.invalidateQueries("achats_retc")
                query.invalidateQueries("achats_info")
                query.invalidateQueries("achats_cmd")
                setRowsId(null)
                cleanForm()
            },
            onError(err) {
                const error = getError(err)
                if (error) setRowsId(null)
            }
        })
    }
    const tableRows = achatRetourContenu.map(d => (
        <tr key={d.arc_id}>
            <td>{d.pr_nom}</td>
            <td>{d.arc_id === rowsId ?
                <NumberInput
                    autoComplete="off"
                    autoCorrect="off"
                    max={parseInt(d.reste_reel, 10)}
                    value={parseInt(formValues.qte, 10)}
                    onChange={value => setValues("qte", value)}
                /> : d.arc_qte}</td>
            <td><Text color="red">{d.reste_reel}</Text></td>
            <td>
                {d.arc_id === rowsId ?
                    <Button
                        onClick={() => handleEdit(d.arc_id)}
                        color="green"
                        children={<IconCheck size={21} />}
                    /> :
                    <Button
                        disabled={parseInt(d.reste_reel, 10) === 0}
                        onClick={() => setRowsId(d.arc_id)}
                        children={<IconPencil size={21} />}
                    />
                }
            </td>
        </tr>
    ))

    return (
        <Grid columns={30}>
            <Grid.Col md={6}>
                <Card direction="column" shadow="lg" sx={theme => ({ backgroundColor: theme.colors.blue[2], color: "white", width: "100%" })}>
                    <Button variant="white" onClick={() => handleClick(acId)}>+</Button>
                    <Text weight="bold" mt={5} order={4}>Dates</Text>
                    <List listStyleType="none">
                        {achatRetour.map(d => (
                            <List.Item key={d.ar_id}>
                                <Anchor onClick={() => {
                                    setViewTable(prevData => ({ ...prevData, isView: true, data: { ...d } }))
                                    handlePlaceContent(d.ar_id)
                                }}>{new Date(d.ar_date).toLocaleDateString()}</Anchor>
                            </List.Item>
                        ))}
                    </List>
                </Card>
            </Grid.Col>
            <Grid.Col md={24}>
                {viewTable.isView &&
                    <AppTable
                        title={`Retour du ${new Date(viewTable.data.ar_date).toLocaleDateString()}`}
                        tableHead={["Designation", "Retourner", "Reste", "Action"]}
                        tableRows={tableRows}
                    />}
            </Grid.Col>
        </Grid >
    )
}