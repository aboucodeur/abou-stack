import { Button, Group, Notification, NumberInput } from '@mantine/core'
import { useCallback } from 'react'
import { useMutation, useQueryClient } from 'react-query'
import useForm from '../../../hooks/useForm'
import { addShopLicence } from '../../../services/api'
import { getError } from '../../../utils'

export default function AddLicenceModal({ boId, handleClose }) {
    const { formValues, setValues, formErr, setErrors, cleanForm } = useForm({ j: 0, m: 0, a: 0 })
    const { mutate } = useMutation(["lic"], addShopLicence)
    const query = useQueryClient()

    const convertToday = useCallback(({ j = 0, m = 0, a = 0 }) => {
        const monthToDay = 30
        const yearToDay = 365
        const day = j >= 0 ? j : 0
        const month = m >= 0 ? m : 0
        const year = a >= 0 ? a : 0
        const calculDate = (day + (monthToDay * month) + (year * yearToDay))
        return calculDate
    }, [])
    
    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({
            bo_id: boId,
            time: convertToday({ ...formValues })
        }, {
            onSuccess: () => {
                query.invalidateQueries("lic")
                cleanForm()
                handleClose()
            },
            onError: (err) => {
                const error = getError(err)
                if (error) setErrors("message", error)
            }
        })
    }

    return (
        <div>
            <form onSubmit={handleSubmit}>
                {formErr.message && <Notification m={5} color="red">{formErr.message}</Notification>}
                <Group>
                    <NumberInput
                        style={{ width: 120 }}
                        autoComplete="off"
                        autoCorrect="off"
                        min={0}
                        max={365}
                        label="Jour"
                        placeholder="jour"
                        value={formValues.j}
                        onChange={(value) => setValues("j", value)}
                    />
                    <NumberInput
                        style={{ width: 120 }}
                        autoComplete="off"
                        autoCorrect="off"
                        min={0}
                        max={12}
                        label="Mois"
                        placeholder="mois"
                        value={formValues.m}
                        onChange={(value) => setValues("m", value)}
                    />
                    <NumberInput
                        style={{ width: 120 }}
                        autoComplete="off"
                        autoCorrect="off"
                        min={0}
                        max={360}
                        label="Année"
                        placeholder="annee"
                        value={formValues.a}
                        onChange={(value) => setValues("a", value)}
                    />
                </Group>
                <Button type="submit" fullWidth mt={5}>Confirmer</Button>
            </form>
        </div>
    )
}