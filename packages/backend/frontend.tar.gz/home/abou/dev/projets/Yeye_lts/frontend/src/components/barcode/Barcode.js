import React from "react"
import { TextInput } from "@mantine/core"
import { IconScan } from "@tabler/icons-react"

export default function Barcode({ onScan, notOff = false }) {
    const barcodeRef = React.useRef()
    const [active, setActive] = React.useState(false)
    const onOffScan = () => setActive(prev => !prev)
    const handleScan = (e) => {
        if (!active) return
        let barcode = ""
        const { keyCode } = e
        const { value } = e.target
        barcode += value
        if (barcode.length > 11 && keyCode === 13) {
            onScan(barcode)
            if (!notOff) setActive(false)
            barcode = ""
            barcodeRef.current.value = ""
        }
    }
    const autoFocus = React.useCallback(() => barcodeRef.current.focus(), [])
    React.useEffect(() => {
        if (!active || !barcodeRef.current) return
        const timeId = setInterval(() => autoFocus(), 100)
        return () => clearInterval(timeId)
    }, [active, autoFocus])

    return (
        <div>
            <IconScan
                size={25}
                style={{ color: active ? "green" : "red" }}
                onClick={() => onOffScan()}
            />
            <TextInput
                ref={barcodeRef}
                autoFocus={active}
                id="barcode"
                onKeyDown={(e) => handleScan(e)}
                style={{ width: 0, height: 0, opacity: 0 }}
            />
        </div>
    )
}