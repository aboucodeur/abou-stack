import React from 'react'
import { Button, Modal, Title, PasswordInput, Group, Notification } from '@mantine/core'
import { modals } from "@mantine/modals"
import { useNavigate, useParams } from 'react-router-dom'
import useForm from '../../hooks/useForm'
import { instance } from '../../axios'
import { Link } from "react-router-dom"
import AdminSignup from './AdminSignup'
import { getError } from '../../utils'
import { useDisclosure } from '@mantine/hooks'

export default function ChangeAdminPass() {
    const { token } = useParams()
    const navigate = useNavigate()

    // const [opened, setOpened] = React.useState(true)

    // ** change et pris en changer du modal
    const [opened, { open, close }] = useDisclosure(true)

    const { formErr, handleSubmit, handleChange, setErrors, cleanForm, getInputProps } = useForm({ newPass: "", confirmNewPass: "" }, (values) => {
        instance.put(`/admins/password/recovery/confirm/${token}`, { ...values })
            .then(() => {
                cleanForm()
                close()
                navigate("/admin")
            })
            .catch(err => {
                const error = getError(err)
                setErrors("message", error)
            })
    }
    )
    const validate = (values, err) => {
        const { newPass, confirmNewPass } = values
        if (newPass.length < 8) err.newPass = "8 ou plus de caractères"
        if (confirmNewPass.length < 8) err.confirmNewPass = "8 plus de caractéres"
        else if (confirmNewPass !== newPass) err.confirmNewPass = "Confirmer le nouveau mot de passe"
    }
    const createAccountModal = () => {
        if (opened) close()
        modals.open({
            title: "Creation de compte",

            children: <AdminSignup setOpened={open} token={token} handleClose={() => {
                if (!opened) open()
                modals.closeAll()
            }} />,
        })
    }

    return (
        <Modal opened={opened} onClose={close} title="Changer de mot de passe" yOffset="1vh" xOffset={0}>
            {formErr.message && <Notification onClose={() => setErrors("message", "")} color="red" title={<Title order={3}>Erreur</Title>}>{formErr.message}</Notification>}
            <form onSubmit={(e) => handleSubmit(e, validate)}>
                <PasswordInput
                    label="Noveau mot de passe"
                    autoCapitalize="off"
                    autoCorrect="off"
                    autoComplete="offf"
                    required
                    {...getInputProps("newPass")}
                    onChange={handleChange}
                    error={formErr.newPass}
                />
                <PasswordInput
                    label="Confirmer le nouveau mot de passe"
                    autoCapitalize="off"
                    autoCorrect="off"
                    autoComplete="offf"
                    required
                    {...getInputProps("confirmNewPass")}
                    onChange={handleChange}
                    error={formErr.confirmNewPass}
                />
                <Group spacing={5} mt={5}>
                    <Button type="submit">Confirmer</Button>
                    <Button onClick={() => createAccountModal()}>Creer Compte</Button>
                    <Button color="orange" type="button" component={Link} to="/admin" >Retour</Button>
                </Group>
            </form>
        </Modal>
    )
}
