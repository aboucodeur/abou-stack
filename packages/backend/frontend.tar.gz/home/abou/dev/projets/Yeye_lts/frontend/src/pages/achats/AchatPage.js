import { Tabs } from '@mantine/core'
import AchatLists from './AchatLists'
import AchatPayPage from './AchatPayPage'
import AchatRecepPage from './AchatRecepPage'
import ImageIcon from '../../components/icons/ImageIcon'
import { cashIcon, contentIcon } from '../../constants'
import { IconReceipt } from '@tabler/icons-react'

export default function AchatPage() {
    return (
        <Tabs defaultValue="1">
            <Tabs.List >
                <Tabs.Tab icon={<ImageIcon src={contentIcon} alt="content_icon" />} value="1">
                    Principale
                </Tabs.Tab>
                <Tabs.Tab icon={<ImageIcon src={cashIcon} alt="cash_icon" />} value="2">
                    Paiements
                </Tabs.Tab>
                <Tabs.Tab
                    icon={<IconReceipt size={21} />}
                    value="3"
                >
                    Reception
                </Tabs.Tab>
            </Tabs.List>
            <Tabs.Panel value="1">
                <AchatLists />
            </Tabs.Panel>
            <Tabs.Panel value="2">
                <AchatPayPage />
            </Tabs.Panel>
            <Tabs.Panel value="3">
                <AchatRecepPage />
            </Tabs.Panel>
        </Tabs>
    )
}
