import { useEffect } from 'react'
import ReactGA from 'react-ga'

const useGAnalytics = (l) => {
    useEffect(() => {
        const TRACKING_ID = 'GTM-MSPN5G7R'
        ReactGA.initialize(TRACKING_ID)
        ReactGA.pageview(window.location.pathname + window.location.search)
    }, [])

    // *** utilisation l'api ga depuis wnidow
    // const sendGAEvent = (name = '', action = '', title) => {
    //     window.dataLayer.push({
    //         category: name,
    //         action: action,
    //         title: title
    //     });
    // };
}
export default useGAnalytics
