import { useEffect } from 'react'
import { Button, Group, Notification, NumberInput, TextInput } from '@mantine/core'
import { modals } from '@mantine/modals'
import useForm from '../../hooks/useForm'
import { addAchatPaiement } from '../../services/api'
import { useMutation, useQueryClient } from 'react-query'
import { getError } from '../../utils'
import ARetraits from '../action/ARetraits'

export default function AddPaiementForm({ acId, rest }) {
    const { formValues, setValues, handleChange, setErrors, formErr, cleanForm, getInputProps } = useForm(
        { motif: `${new Date().toLocaleString().split(" ").join(" à ")}`, mte: 0 }
    )
    const query = useQueryClient()
    const { mutate } = useMutation(["achats_pay"], addAchatPaiement)

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ ...formValues, acId }, {
            onSuccess() {
                query.invalidateQueries("achats_info")
                query.invalidateQueries("achats_pay")
                cleanForm()
            },
            onError(err) {
                const error = getError(err)
                if (error) setErrors("message", error)
            }
        })
    }
    const addModal = (acId) => {
        modals.open({
            title: "Paiement actionnaire",
            children: <ARetraits acId={acId} closeModal={() => modals.closeAll()} />,
        })
    }

    useEffect(() => {
        setValues("mte", rest)
    }, [rest, setValues])

    return (
        <div>
            {formErr.message && <Notification color="red" onClose={() => setErrors("message", "")} m={5}>{formErr.message}</Notification>}
            <form onSubmit={handleSubmit}>
                <Group spacing={3}>
                    <TextInput
                        placeholder="Motif"
                        autoComplete="off"
                        autoCorrect="off"
                        required
                        {...getInputProps("motif")}
                        onChange={handleChange}
                    />
                    <NumberInput
                        placeholder="Montant"
                        autoComplete="off"
                        autoCorrect="off"
                        max={rest}
                        min={1}
                        maxLength={20}
                        value={formValues.mte}
                        onChange={value => setValues("mte", value)}
                        required
                        precision={2}
                    />
                    <Button type="submit" disabled={rest <= 0 && true}>Payer</Button>
                    <Button color="green" onClick={() => addModal(acId)}>Paiement actionnaire</Button>
                </Group>
            </form>
        </div>
    )
}