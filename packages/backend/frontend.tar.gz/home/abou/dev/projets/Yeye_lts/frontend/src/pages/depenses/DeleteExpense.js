import { Button } from '@mantine/core'
import { useMutation, useQueryClient } from "react-query"
import { removeShopDepense } from '../../services/api'

export default  function DeleteExpense({ data, handleClose }) {
    const query = useQueryClient()
    const { mutate } = useMutation(["depenses"], removeShopDepense)

    const handleDelete = (id) => {
        mutate(id, {
            onSuccess: () => {
                query.invalidateQueries("depenses")
                handleClose()
            }
        })
    }

    return <Button color="red" onClick={() => handleDelete(data.dep_id)}>Supprimer</Button>
}