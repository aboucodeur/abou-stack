import React from 'react'
import { Button, PasswordInput, TextInput } from '@mantine/core'
import useForm from "../../hooks/useForm"
import { instance } from '../../axios'
import { getError } from '../../utils'

export default function AdminSignup({ token, setOpened, handleClose }) {
    const { formValues, handleChange, handleSubmit, cleanForm } = useForm({
        prenom: "Aboubacar",
        nom: "Barry",
        email: "codeurabou123@gmail.com",
        pass: "",
        tel: "00223 94865879"
    }, (values) => {
        instance.post(`/admins/create/${token}`, { ...values })
            .then(() => {
                cleanForm()
                handleClose()
                setOpened(true)
            })
            .catch(err => {
                const error = getError(err)
                alert(error)
            })
    })

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <TextInput
                    label="Prenom"
                    placeholder="votre prenom"
                    required
                    name="prenom"
                    autoComplete="off"
                    autoCorrect="off"
                    value={formValues.prenom}
                    onChange={handleChange}
                />
                <TextInput
                    label="Nom"
                    placeholder="votre nom"
                    required
                    name="nom"
                    autoCorrect="off"
                    autoComplete="off"
                    value={formValues.nom}
                    onChange={handleChange}
                />
                <TextInput label="Email"
                    type="email"
                    placeholder="votre email"
                    required
                    name="email"
                    autoComplete="off"
                    autoCorrect="off"
                    value={formValues.email}
                    onChange={handleChange}
                />
                <PasswordInput
                    label="Mot de passe"
                    placeholder="votre mot de passe"
                    required
                    autoCorrect="off"
                    autoComplete="off"
                    name="pass"
                    value={formValues.pass}
                    onChange={handleChange}
                />
                <TextInput
                    type="tel"
                    label="Telephone"
                    placeholder="votre telephone"
                    required
                    autoComplete="off"
                    autoCorrect="off"
                    name="tel"
                    value={formValues.tel}
                    onChange={handleChange}
                />
                <Button type="submit" mt={5}>Creer</Button>
            </form>
        </div>
    )
}