import { useEffect } from "react"
import { Button, Notification, Textarea } from "@mantine/core"
import { useMutation, useQueryClient } from "react-query"
import useForm from "../../hooks/useForm"
import { editApprovision } from "../../services/api"
import { getError } from "../../utils"

export default function EditApprModal({ data, handleClose }) {
    const { formValues, formErr, handleChange, getInputProps, cleanForm, setErrors, setValues } = useForm({ motif: "" })
    const query = useQueryClient()
    const { mutate } = useMutation(["appr"], editApprovision)

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ ...formValues, apId: data.ap_id }, {
            onSuccess: () => {
                query.invalidateQueries("appr")
                cleanForm()
                handleClose()
            },
            onError: (err) => {
                const error = getError(err)
                if (error) setErrors("message", err)
            }
        })
    }

    useEffect(() => setValues("motif", data.ap_motif), [setValues, data])
    return (
        <div>
            <form onSubmit={handleSubmit}>
                {formErr.message && <Notification m={5} color="red">{formErr.message}</Notification>}
                <Textarea
                    label="Description"
                    description="300 caracteres maximum"
                    maxLength={300}
                    {...getInputProps("motif")}
                    onChange={handleChange}
                />
                <Button mt={5} type='submit' color='orange' fullWidth variant='outline'>Modifier</Button>
            </form>
        </div>
    )
}