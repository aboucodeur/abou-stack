import React from 'react'
import { useQuery } from 'react-query'
import { instance } from '../../axios'
import { Badge, Text, TextInput, Title } from '@mantine/core'
import { VirtualTable } from '../../components'
import useHeight from '../../hooks/useHeight'
import { IconSearch } from '@tabler/icons'
import useSearch from '../../hooks/useSearch'
import { toLower } from '../../utils'

export default function Feedback() {
    const { searchVal, getSearchProps, handleSearch } = useSearch({ userInput: "" })
    const { data: getFeedBacks = [], isLoading } = useQuery(["feeds"], () => instance.get("/support").then(res => res.data))
    const { wH } = useHeight()

    const searchFilter = (datas = [], searchTerm = "") => {
        const searchKeys = ["username", "tel", "message", "metadata", "createdAt", "email"]
        const term = toLower(searchTerm).trim()
        return datas.filter(data => searchKeys.some(key => {
            if (key === "tel") return data[key].split(" ").join("").includes(searchTerm.split(" ").join(""))
            else if (key === "createdAt") return new Date(datas[key]).toLocaleDateString().includes(term)
            else return toLower(data[key]).includes(term)
        }))
    }

    const filteredDatas = searchFilter(getFeedBacks, searchVal.userInput)
    const Rows = ({ index }) => {
        const { createdAt, username, tel, message, metadata, email } = filteredDatas[index]
        return (
            <tr>
                <td style={{ height: "36px" }}><Text>{index + 1}</Text></td>
                <td><Text>{username}</Text></td>
                <td><Text>{new Date(createdAt).toLocaleString()}</Text></td>
                <td>{tel}</td>
                <td><Text>{message}</Text></td>
                <td><Text>{metadata}</Text></td>
                <td>{email ? <Text>{email}</Text> : <Badge color="red">Pas definis</Badge>}</td>
            </tr>
        )
    }

    if (isLoading) return <div>Chargements des avis en cours ...</div>
    return (
        <div>
            <div>
                <Title order={3}>Feedbacks</Title>
                <TextInput
                    placeholder="Rechercher dans les feedbacks"
                    label="Recherche"
                    autoComplete="off"
                    autoCorrect="off"
                    icon={<IconSearch />}
                    onChange={handleSearch}
                    {...getSearchProps("userInput")}
                />
            </div>
            <div>
                {getFeedBacks.length === 0
                    ? <Text weight="bold" mt={5}>Auncune feedbacks trouver</Text>
                    : <VirtualTable
                        header={["N°", "Nom", "DATE", "TEL", "MESSAGE", "METADATA", "EMAIL"]}
                        height={wH}
                        itemCount={filteredDatas.length}
                        row={Rows}
                    />
                }
            </div>
        </div>
    )
}
