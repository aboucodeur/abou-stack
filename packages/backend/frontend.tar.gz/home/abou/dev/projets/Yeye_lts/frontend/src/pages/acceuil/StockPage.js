import { Loader, Tabs } from "@mantine/core"
import ImageIcon from "../../components/icons/ImageIcon"
import StockToday from "./StockToday"
import Home from "./Home"
import { useQuery } from "react-query"
import { getBoutiqueDash } from "../../services/api"
import { useAppState } from "../../context/AppContext"
import { cashBag, globalIcon, todayIcon, yearsIcon } from "../../constants"
import StockStats from "./StockStats"
import { IconChartBar, IconCheck } from "@tabler/icons-react"
import { ProductChart } from "../charts/ProductChart"
import Benefice from "./Benefice"
import HomeStats from "./HomeStats"
import Recette from "./Recette"

export default function StockPage() {
    const { getShop } = useAppState()
    const shopInfos = getShop
    const { data: shopDash = [], isLoading } = useQuery(["dash", shopInfos.bo_id], ({ queryKey }) => getBoutiqueDash(queryKey[1]))

    if (isLoading) return <Loader />
    return (
        <Tabs defaultValue="1">
            <Tabs.List mb={5}>
                <Tabs.Tab icon={<ImageIcon src={todayIcon} alt="today" />} value="1">
                    Ajourd'hui
                </Tabs.Tab>
                <Tabs.Tab icon={<ImageIcon src={cashBag} alt="cash_bag" />} value="2">Benefices</Tabs.Tab>
                <Tabs.Tab icon={<ImageIcon src={yearsIcon} alt="stats" />} value="3">Statistiques</Tabs.Tab>
                <Tabs.Tab icon={<IconChartBar />} value="4">Graphes</Tabs.Tab>
                <Tabs.Tab icon={<ImageIcon src={globalIcon} alt="global" />} value="5">Global</Tabs.Tab>
                <Tabs.Tab icon={<IconCheck />} value="6">Recette vente</Tabs.Tab>
            </Tabs.List>
            <Tabs.Panel value="1"><StockToday boId={shopInfos.bo_id} /></Tabs.Panel>
            <Tabs.Panel value="2"><Benefice boId={shopInfos.bo_id} /></Tabs.Panel>
            <Tabs.Panel value="3"><StockStats boId={shopInfos.bo_id} /></Tabs.Panel>
            <Tabs.Panel value="4">
                <ProductChart />
                <HomeStats graph={shopDash.graph} />
            </Tabs.Panel>
            <Tabs.Panel value="5"><Home shopDash={shopDash} /></Tabs.Panel>
            <Tabs.Panel value="6"><Recette boId={shopInfos.bo_id} /></Tabs.Panel>
        </Tabs>
    )
}
