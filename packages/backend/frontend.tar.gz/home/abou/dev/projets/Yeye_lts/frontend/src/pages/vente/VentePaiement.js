import React from 'react'
import useForm from '../../hooks/useForm'
import { Button, Group, NumberInput, Text, TextInput } from '@mantine/core'
import { getError } from '../../utils'
import AddPaiementForm from './AddPaiementForm'
import { useMutation, useQueryClient } from 'react-query'
import { editVendrePaiement, removeVendrePaiement } from '../../services/api'
import { IconCheck, IconPencil, IconTrash } from '@tabler/icons-react'
import { AppTable } from '../../components'

export default function VentePaiement({ vendId, vendreInfo, vendrePaiement, getPaySum, rest }) {
    const query = useQueryClient()
    const [rowsId, setRowsId] = React.useState(null)
    const { formValues, handleChange, setValues, cleanForm } = useForm({ motif: "", mte: 0 })
    const { mutate } = useMutation(["vendres_pay"], editVendrePaiement)
    const { mutate: remPay } = useMutation(["vendres_pay"], removeVendrePaiement)

    const handleEdit = (id) => {
        mutate({ ...formValues, vpId: id }, {
            onSuccess() {
                query.invalidateQueries("vendres_pay")
                query.invalidateQueries("vendres_info")
                cleanForm()
                setRowsId(null)
            },
            onError(err) {
                const error = getError(err)
                if (error) setRowsId(null)
            }
        })
    }
    const handleRemove = (id) => remPay(id, {
        onSuccess: () => {
            query.invalidateQueries("vendres_info")
            query.invalidateQueries("vendres_pay")
        }
    })

    const tableRows = vendrePaiement.map(d => (
        <tr key={d.vp_id}>
            <td><Text>{new Date(d.createdAt).toLocaleString()}</Text></td>
            <td>{d.vp_id === rowsId ?
                <TextInput
                    autoComplete="off"
                    autoCorrect="off"
                    name="motif"
                    defaultValue={formValues.motif}
                    onChange={handleChange}
                /> :
                <Text>{d.vp_motif}</Text>
            }
            </td>
            <td>{d.vp_id === rowsId ?
                <NumberInput
                    autoComplete="off"
                    autoCorrect="off"
                    max={rest}
                    min={0}
                    maxLength={20}
                    defaultValue={formValues.mte}
                    onChange={value => setValues("mte", value)}
                    placeholder="Donner le montant"
                /> :
                <Text>{d.vp_mte}</Text>
            }</td>
            <td>
                <Group spacing={3}>
                    {d.vp_id === rowsId ?
                        <Button
                            onClick={() => handleEdit(d.vp_id)}
                            color="green"
                            children={<IconCheck size={21} />}
                        />
                        : <Button
                            children={<IconPencil size={21} />}
                            onClick={() => {
                                setRowsId(d.vp_id)
                                setValues("motif", d.vp_motif)
                            }}
                        />}
                    <Button
                        onClick={() => handleRemove(d.vp_id)}
                        color="red"
                        children={<IconTrash size={21} />}
                    />
                </Group>
            </td>
        </tr>
    ))

    return (
        <div>
            {vendreInfo.vend_etat > 0 ? <AddPaiementForm vendId={vendId} rest={rest} /> : null}
            <AppTable
                tableHead={["Date", "Motif", "Montant", "Action"]}
                tableRows={tableRows}
            />
        </div>
    )
}