import { ActionIcon, Anchor, Badge, Button, Flex, Group, Tooltip } from '@mantine/core'
import { DatePickerInput } from '@mantine/dates'
import { modals } from '@mantine/modals'
import { useQuery } from 'react-query'
import "dayjs/locale/fr"
import { Link } from "react-router-dom"
import { useAppState } from '../../context/AppContext'
import { IconCalendar, IconEdit, IconTrash } from "@tabler/icons-react"
import useSearch from '../../hooks/useSearch'
import { getBoutiqueApprovision } from '../../services/api'
import { pgDate } from '../../utils'
import AddApprModal from './AddApprModal'
import EditApprModal from './EditApprModal'
import RemAchatModal from './RemApprModal'
import MTRTable from '../../components/table/MTRTable'
import { formatNumber } from '../../helper'

export default function ApprList() {
    const { getShop } = useAppState()
    const shopId = getShop.bo_id
    const { searchVal, setSearch } = useSearch({ date: new Date() })
    const { data: shopApprovision = [], isLoading, isFetching, isError } = useQuery(["appr", shopId, pgDate(searchVal.date)], ({ queryKey }) => getBoutiqueApprovision(queryKey[1], queryKey[2]))

    const addModal = () => {
        modals.open({
            title: "Approvisions",
            children: <AddApprModal
                boId={shopId}
                handleClose={() => modals.closeAll()}
            />
        })
    }
    const editModal = (data) => {
        modals.open({
            title: "Modification",
            children: <EditApprModal data={data} handleClose={() => modals.closeAll()} />
        })
    }
    const removeModal = (apId) => {
        modals.open({
            title: "Suppression",
            children: <RemAchatModal apId={apId} handleClose={() => modals.closeAll()} />
        })
    }

    const columns = [
        {
            accessorKey: 'ap_date',
            header: 'Date / Heure',
            enableGrouping: true,
            accessorFn: (originalRow) => new Date(originalRow.ap_date).toLocaleDateString()
        },
        {
            accessorKey: 'ap_motif',
            header: 'Motif',
            size: 90,
        },
        {
            accessorKey: 'ap_etat',
            header: "Etat",
            Cell: ({ cell }) => {
                return (cell.getValue() === '1'
                    ? <Badge color="green">Valider</Badge>
                    : <Badge color="red">Pas valider</Badge>
                )
            }
        },
        {
            accessorKey: 'total',
            header: "Totals",
            Cell: ({ cell }) => formatNumber(cell.getValue())
        },
    ]

    return <MTRTable
        uId='ap_id'
        columns={columns}
        data={shopApprovision}
        visual={{
            dataLoader: isLoading,
            dataError: isError,
            dataFetching: isFetching,
        }}
        renderTopToolbarCustomActions={({ table }) => (
            <Group align="normal" mt={5} spacing={3}>
                <DatePickerInput
                    locale="fr"
                    placeholder="Recherche par date"
                    autoComplete="off"
                    autoCorrect="off"
                    value={searchVal.date}
                    onChange={(value) => setSearch("date", value)}
                    icon={<IconCalendar size={21} />}
                    // style={{ width: '100%' }}
                    clearable
                />
                <Button color='green' variant='outline' onClick={addModal}>
                    Nouvelle entree
                </Button>
            </Group>
        )}
        renderRowActions={({ row }) => (
            <Flex gap="md">
                <Anchor
                    component={Link}
                    to={`/approvisions/${row.original.ap_id}`}
                >Details
                </Anchor>
                <Tooltip label="Edit">
                    <ActionIcon color="orange" onClick={() => editModal({ ...row.original })}>
                        <IconEdit />
                    </ActionIcon>
                </Tooltip>
                {row.original.ap_etat < "1" &&
                    <Tooltip label="Delete">
                        <ActionIcon color="red" onClick={() => removeModal(row.original.ap_id)}>
                            <IconTrash />
                        </ActionIcon>
                    </Tooltip>
                }
            </Flex>
        )}
    />
}