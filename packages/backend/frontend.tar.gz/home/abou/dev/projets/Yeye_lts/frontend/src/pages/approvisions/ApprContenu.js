import React from 'react'
import { Button, Group, NumberInput, Text, TextInput } from '@mantine/core'
import AppTable from '../../components/table/AppTable'
import { toLower } from '../../utils'
import AddForm from './AddForm'
import useForm from '../../hooks/useForm'
import { useMutation, useQueryClient } from 'react-query'
import { editApprovisionCommand, removeApprovisionCommand } from '../../services/api'
import { IconCheck, IconEdit, IconSearch, IconTrash } from "@tabler/icons-react"
import useSearch from '../../hooks/useSearch'
import { formatNumber } from '../../helper'

export default function ApprContenu({ apprCommand, apId, apprInfo }) {
    const { formValues, setValues, cleanForm } = useForm({ qte: undefined })
    const [rowsId, setRowsId] = React.useState(null)
    const query = useQueryClient()
    const { mutate } = useMutation(["appr_cmd"], editApprovisionCommand)
    const { mutate: remCmd } = useMutation(["appr_cmd"], removeApprovisionCommand)
    const { searchVal, getSearchProps, handleSearch } = useSearch({ nom: "" })

    const handleEdit = (id) => {
        mutate({ ...formValues, apcId: id }, {
            onSuccess() {
                query.invalidateQueries("appr_cmd")
                query.invalidateQueries("appr_info")
                query.invalidateQueries("appr_prod")
                setRowsId(null)
                cleanForm()
            },
        })
    }
    const handleRemove = (id) => {
        remCmd(id, {
            onSuccess() {
                query.invalidateQueries("appr_cmd")
                query.invalidateQueries("appr_info")
                query.invalidateQueries("appr_prod")
                setRowsId(null)
            }
        })
    }
    const searchFilter = (data) => {
        const { pr_nom } = data
        if (!searchVal.nom) return data
        if (toLower(pr_nom).includes(toLower(searchVal.nom.trim()))) return data
    }

    const tableRows = apprCommand
        .filter(searchFilter)
        .map(d => (
            <tr key={d.apc_id}>
                <td>{d.apc_id === rowsId ?
                    <TextInput value={d.pr_nom} disabled={true} /> :
                    <Text>{d.pr_nom}</Text>}
                </td>
                <td>{d.apc_id === rowsId ?
                    <NumberInput
                        placeholder="Donner la quantité"
                        autoComplete="off"
                        autoCorrect="off"
                        defaultValue={d.apc_qte}
                        onChange={(value) => setValues("qte", value)}
                        maxLength={20}
                        min={1}
                    /> :
                    <Text>{formatNumber(d.apc_qte)}</Text>}
                </td>
                <td>
                    <Group spacing={5}>
                        {d.apc_id === rowsId ?
                            <Button
                                onClick={() => handleEdit(d.apc_id)}
                                type="submit"
                                children={<IconCheck size={21} />}
                                color="green"
                            /> :
                            <Button
                                disabled={apprInfo.ap_etat !== "0" && true}
                                onClick={() => {
                                    setRowsId(d.apc_id)
                                    setValues("qte", d.apc_qte)
                                }}
                                children={<IconEdit size={21} />}
                            />}
                        <Button
                            disabled={apprInfo.ap_etat !== "0" && true}
                            onClick={() => handleRemove(d.apc_id)}
                            color="red"
                            children={<IconTrash size={21} />}
                        />
                    </Group>
                </td>
            </tr>
        ))
    return (
        <div>
            {apprInfo.ap_etat === "0" && <AddForm apId={apId} />}
            <TextInput
                icon={<IconSearch size={21} />}
                autoComplete="off"
                autoCorrect="off"
                placeholder="Rechercher dans le pannier"
                mt={5}
                {...getSearchProps("nom")}
                onChange={handleSearch}
            />
            <div>
                <AppTable
                    title={`Nombre(s) de produit(s) : ${apprCommand.length}`}
                    tableHead={["Designation", "Quantite", "Action"]}
                    tableRows={tableRows}
                    h={360}
                />
            </div>
        </div>
    )
}