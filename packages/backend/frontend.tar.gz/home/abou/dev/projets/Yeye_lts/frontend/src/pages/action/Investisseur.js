import { useMemo } from 'react'
import { useAppState } from '../../context/AppContext'
import { modals } from '@mantine/modals'
import { ActionIcon, Anchor, Button, Group, Loader, Paper, Text, TextInput } from '@mantine/core'
import { IconEdit, IconSearch, IconTrash } from '@tabler/icons-react'
import useSearch from '../../hooks/useSearch'
import { useQuery } from 'react-query'
import { getAllInvestisseurs } from '../../services/api'
import AppTable from '../../components/table/AppTable'
import { NavLink } from 'react-router-dom'
import { toLower } from '../../utils'
import AInvestisseur from './AInvestisseur'
import MInvestisseur from './MInvestisseurs'
import DInvestisseur from './DInvestisseur'
import { formatNumber } from '../../helper'

export default function Investisseur() {
    const { getShop } = useAppState()
    const shopId = getShop.bo_id

    const { searchVal, handleSearch, getSearchProps } = useSearch({ nom: "", etat: "0" })
    const { data = [], isLoading } = useQuery(["act", shopId], ({ queryKey }) => getAllInvestisseurs(queryKey[1]))

    const searchFilter = (data) => {
        const query = toLower(searchVal.nom).trim()
        const { nom, solde } = data
        if (!query) return data
        if (toLower(nom).includes(query)) return data
        // separateur de l'arnegt espace,point,virgule
        if (`${solde}`.includes(query.split(/[ ,.]/).join(''))) return data
    }
    const addModal = () => {
        modals.open({
            title: "Nouveau actionnaire",
            children: <AInvestisseur boId={shopId} closeModal={() => modals.closeAll()} />
        })
    }
    const editModal = (data) => {
        modals.open({
            title: `Modification de l'actionnaire ${data.nom}`,
            children: <MInvestisseur data={data} closeModal={() => modals.closeAll()} />
        })
    }
    const removeModal = (data) => {
        modals.open({
            title: `Suppression de l'actionnaire ${data.nom}`,
            children: <DInvestisseur data={data} closeModal={() => modals.closeAll()} />
        })
    }

    const rows = data.filter(searchFilter).map((d, _idx) => (
        <tr key={d.inv_id}>
            <td><Text>{(_idx + 1)}</Text></td>
            <td>
                <Anchor underline component={NavLink} to={`/action/detail/${d.co_id}?solde=${d.solde}&nom=${d.nom}`}>
                    <Text weight="bold" >{d.nom}</Text>
                </Anchor>
            </td>
            <td><Text>{formatNumber(d.depots)}</Text></td>
            <td><Text>{formatNumber(d.retraits)}</Text></td>
            <td><Text>{formatNumber(d.solde)}</Text></td>
            <td>
                {toLower(d.nom) === toLower("fonds initial")
                    ? 'FONDS'
                    : <Group>
                        <ActionIcon
                            onClick={() => editModal({ ...d })}
                            color="orange"
                            children={<IconEdit />}
                        />
                        <ActionIcon
                            color="red"
                            onClick={() => removeModal({ ...d })}
                            children={<IconTrash />}
                        />
                    </Group>
                }
            </td>
        </tr >

    ))
    const sum = useMemo(() => {
        return data.reduce((acc, curr) => {
            acc.depots += curr.depots
            acc.retraits += curr.retraits
            return acc
        }, { depots: 0, retraits: 0 })
    }, [data])

    if (isLoading) return (
        <div>
            <Text>Chargement en cours ...</Text>
            <Loader />
        </div>
    )

    return (
        <div>
            <Group spacing={3}>
                <TextInput
                    icon={<IconSearch />}
                    placeholder="Nom de l'actionnaire"
                    {...getSearchProps("nom")}
                    onChange={handleSearch}
                />
                <Button onClick={addModal}>Ajouter un actionnaire</Button>
            </Group>
            <Paper shadow="lg" p="md" mt={5}>
                <Text color="blue">Depots actionnaires : {formatNumber(sum.depots)} F</Text>
                <Text color="blue">Retraits actionnaires : {formatNumber(sum.retraits)} F</Text>
            </Paper>
            <AppTable
                tableHead={["No", "Nom", "Depots", "Retraits", "Solde", "Action"]}
                tableRows={rows}
            />
        </div>
    )
}