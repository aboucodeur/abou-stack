import React from 'react'
import useForm from '../../hooks/useForm'
import { useMutation, useQueryClient } from 'react-query'
import { Button, Group, Notification, NumberInput, Select } from '@mantine/core'
import { IconCash } from '@tabler/icons-react'
import { retraitBanque } from '../../services/api'
import { getError } from '../../utils'

export default function ASorties({ coId, closeModal }) {
    const { formValues, formErr, setValues, cleanForm, setErrors } = useForm({ mte: 0, type: "e" })
    const { mutate } = useMutation(["act_detail"], retraitBanque)
    const query = useQueryClient()
    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ ...formValues, co_id: coId }, {
            onSuccess() {
                query.invalidateQueries("act_detail")
                closeModal()
                cleanForm()
            },
            onError: (err) => {
                const error = getError(err)
                if (error) setErrors("message", error)
            }
        })
    }

    return (
        <div>
            {formErr.message ? <Notification color="red" onClose={() => setErrors("message", "")}>{formErr.message}</Notification> : null}
            <form onSubmit={handleSubmit}>
                <Group spacing={3} mt={5}>
                    <NumberInput
                        max={30000000}
                        min={0}
                        placeholder="Montant"
                        autoComplete="off"
                        autoCorrect="off"
                        value={formValues.mte}
                        onChange={(value) => setValues("mte", value)}
                        maxLength={20}
                        required
                        hideControls
                        icon={<IconCash />}
                        style={{ width: "100%" }}
                        precision={2}
                    />
                    <Select
                        label="Type de transaction"
                        data={[
                            // { value: 'r', label: "Operation retrait" },
                            { value: 'e', label: "Operation remboursement" },
                        ]}
                        value={formValues.type}
                        onChange={(value) => setValues("type", value ? value : 'e')}
                        style={{ width: "100%" }}
                    />
                </Group>
                <Button fullWidth mt={10} color="green" type="submit">Valider</Button>
            </form>
        </div>
    )
}