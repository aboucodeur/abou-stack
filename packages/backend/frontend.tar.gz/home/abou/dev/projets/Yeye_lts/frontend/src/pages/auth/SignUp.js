import { Box, Button, Container, Flex, Notification, PasswordInput, Text, TextInput, Title } from '@mantine/core'
import { useFocusTrap } from '@mantine/hooks'
import { IconPassword, IconUser } from '@tabler/icons-react'
import { useNavigate } from 'react-router-dom'
import { useMutation } from "react-query"
import { instance } from '../../axios'
import { getError } from '../../utils'
import SEO from '../../components/seo/SEO'
import useForm from '../../hooks/useForm'
import { PhoneInput } from 'react-international-phone'
import "react-international-phone/style.css"

export default function SignUp() {
    const focusTrap = useFocusTrap()
    const { formValues, formErr, setValues, setErrors, getInputProps, handleChange } = useForm({
        prenom: '',
        nom: '',
        tel: '',
        pass: '',
        e_nom: '',
        e_tel: '',
        e_email: '',
        e_adr: ''
    })

    // create user account
    const { mutate } = useMutation(['usignup'], (values) => instance.post('/users_auth/usignup', { ...values }).then(res => res.data))
    const navigate = useNavigate()
    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ ...formValues }, {
            onSuccess() {
                alert("Compte creer avec success")
                navigate('/')
            },
            onError(err) {
                const error = getError(err)
                if (error) setErrors("message", error)
            }
        })
    }

    return (
        <>
            <SEO
                title="Nouveau compte | Yeye"
                name="Aboubacar Barry" // createur de yeye
                type="webapp"
                description="Une application web innovante et conviviale conçue pour simplifier et accélérer la gestion de vos stocks. !"
            />
            <Container my={55}>
                <div className='annonce-signup'>
                    <p>
                        Une semaine gratuit pour les nouveaux comptes ! 🌟
                        {" "}
                        <a href="https://yeye.onrender.com" target='_blank' rel="noreferrer">Plus d'informations !</a>
                    </p>
                </div>
                <Title order={2}>Creation de mon compte !</Title>
                <form onSubmit={handleSubmit} ref={focusTrap}>
                    {formErr?.message && <Notification color="red" onClose={() => setErrors('message', '')}>{formErr.message}</Notification>}
                    <Flex gap="md" wrap="wrap">
                        <TextInput
                            label="Votre prenom"
                            placeholder="Aboubacar"
                            data-autofocus
                            required
                            icon={<IconUser />}
                            style={{ flex: '0.5' }}
                            autoComplete='off'
                            autoCorrect='off'
                            {...getInputProps('prenom')}
                            onChange={handleChange}
                            maxLength={60}
                        />
                        <TextInput
                            label="Votre nom"
                            placeholder="Barry"
                            required
                            icon={<IconUser />}
                            style={{ flex: '0.5' }}
                            autoComplete='off'
                            autoCorrect='off'
                            {...getInputProps('nom')}
                            onChange={handleChange}
                            maxLength={30}
                        />
                    </Flex>
                    <PasswordInput
                        required
                        label="Votre mot de passe"
                        placeholder="Mot de passe"
                        icon={<IconPassword />}
                        autoComplete='off'
                        autoCorrect='off'
                        {...getInputProps('pass')}
                        onChange={handleChange}
                        min={5}
                        max={100}
                    />
                    <Box m={5}>
                        <Text>Numero de connexion </Text>
                        <PhoneInput
                            inputStyle={{
                                width: '100%',
                                fontSize: '16px'
                            }}
                            inputProps={{
                                placeholder: '+223 94865879',
                                required: true
                            }}
                            defaultCountry='ml'
                            {...getInputProps('tel')}
                            onChange={(phone) => setValues('tel', phone)}
                        />
                    </Box>
                    <Box m={5}>
                        <Text>Numero de l'entreprise</Text>
                        <PhoneInput
                            inputStyle={{
                                width: '100%',
                                fontSize: '16px'
                            }}
                            inputProps={{
                                placeholder: '+223 94865879',
                                required: true
                            }}
                            defaultCountry='ml'
                            {...getInputProps('e_tel')}
                            onChange={(phone) => setValues('e_tel', phone)}
                        />
                    </Box>
                    <TextInput
                        label="Nom de l'entreprise"
                        placeholder="Entreprise Yeye"
                        required
                        // icon={<IconBuilding />}
                        autoComplete='off'
                        autoCorrect='off'
                        {...getInputProps('e_nom')}
                        onChange={handleChange}
                        maxLength={180}
                    />
                    <TextInput
                        label="Email de l'entreprise"
                        placeholder="contact@example.com"
                        type='email'
                        required
                        // icon={<IconMail />}
                        autoComplete='off'
                        autoCorrect='off'
                        {...getInputProps('e_email')}
                        onChange={handleChange}
                        maxLength={80}
                    />
                    <TextInput
                        label="Adresse de l' entreprise"
                        placeholder="Hamdallaye ACI 2000"
                        required
                        // icon={<IconLocation />}
                        autoComplete='off'
                        autoCorrect='off'
                        {...getInputProps('e_adr')}
                        onChange={handleChange}
                        maxLength={200}
                    />
                    <Button type='submit' fullWidth radius='lg' mt={5}>
                        Créer mon compte
                    </Button>
                </form>
            </Container>
        </>
    )
}