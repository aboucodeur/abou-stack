import { Alert, Button, Text, } from '@mantine/core'
import { useMutation, useQueryClient } from 'react-query'
import { deleteInvestisseur } from '../../services/api'

export default function DInvestisseur({ data, closeModal }) {
    const { inv_id } = data
    const { mutate } = useMutation(["act"], deleteInvestisseur)
    const query = useQueryClient()

    const handleDelete = (invId) => {
        mutate(invId, {
            onSuccess: () => {
                query.invalidateQueries("act")
                closeModal()
            }
        })
    }

    return (
        <div>
            <Alert color="red">
                <Text>
                    Attention a la suppression de l'actionnaire <br />
                    Elle peut entrainer la suppression de ses comptes et toutes les transactions
                </Text>
            </Alert>
            <Button mt={5} color="red" onClick={() => handleDelete(inv_id)}>Oui , supprimer</Button>
        </div>
    )
}