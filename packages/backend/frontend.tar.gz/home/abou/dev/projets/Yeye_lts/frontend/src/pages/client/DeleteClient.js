import React from 'react'
import { Alert, Button, Text, } from '@mantine/core'

import { useMutation, useQueryClient } from 'react-query'
import { removeShopClient } from '../../services/api'

export default function DeleteClient({ data, handleClose }) {
    const { cl_id } = data

    const query = useQueryClient()
    const { mutate } = useMutation(["clt"], removeShopClient)
    const handleDelete = (clId, type) => {
        mutate({ clId, type }, {
            onSuccess: () => {
                query.invalidateQueries("clt")
                handleClose()
            }
        })
    }

    return (
        <div>
            <Alert color="red">
                <Text>Attention la suppression d'un client supprimer
                    ses ventes et les services rendus a cet client
                    c'est pour cela que vous pouvez confirmer
                    la suppression depuis le corbeille
                </Text>
            </Alert>
            <Button mt={5} color="orange" onClick={() => handleDelete(cl_id, "des")}>Mettre dans le corbeille</Button>
        </div>
    )
}