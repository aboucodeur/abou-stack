import { Badge, Box, Button, Card, Checkbox, Divider, Grid, Group, ScrollArea, Text, TextInput } from "@mantine/core"
import { useMutation, useQuery, useQueryClient } from "react-query"
import { useParams } from "react-router-dom"
import { modals } from "@mantine/modals"
import { addApprovisionCommand, getApprovision, getApprovisionCommand, getApprRuptureProduct } from "../../services/api"
import { toLower } from "../../utils"
import ApprContenu from "./ApprContenu"
import ApprValidation from "./ApprValidation"
import useSearch from "../../hooks/useSearch"
import { IconSearch } from "@tabler/icons-react"
import { formatNumber } from "../../helper"

export default function ApprovisionDetail() {
    const { id } = useParams()
    const apId = parseInt(id, 10)

    const { searchVal, getSearchProps, handleSearch } = useSearch({ nom: "" })
    const { data: apprInfo = {} } = useQuery(["appr_info", apId], ({ queryKey }) => getApprovision(queryKey[1]))
    const { data: apprCmd = [] } = useQuery(["appr_cmd", apId], ({ queryKey }) => getApprovisionCommand(queryKey[1]))
    const { data: apprRuptureProduct = [] } = useQuery(["appr_prod", apId], ({ queryKey }) => getApprRuptureProduct(queryKey[1]))
    const query = useQueryClient()
    const { mutate } = useMutation(["appr_cmd"], addApprovisionCommand)

    const handleValidate = () => {
        modals.open({
            title: "Validation",
            children: <ApprValidation
                apId={apId}
                handleClose={() => modals.closeAll()}
            />
        })
    }
    const handleClick = (data) => {
        const { pr_id } = data
        mutate({ pr_id, qte: 1, apId }, {
            onSuccess: () => {
                query.invalidateQueries("appr_cmd")
                query.invalidateQueries("appr_prod")
            }
        })

    }
    const searchFilter = (data) => {
        const { pr_nom } = data
        if (!searchVal.nom) return data
        if (toLower(pr_nom).includes(toLower(searchVal.nom.trim()))) return data
    }

    return (
        <Grid columns={30}>
            <Grid.Col md={8}>
                <Card p={12} sx={(theme) => ({ backgroundColor: theme.colors.blue[6], color: "white" })}>
                    <Text>Date : {new Date(apprInfo.ap_date).toLocaleDateString()}</Text>
                    <Text>Quantité(s) : {formatNumber(apprInfo.total)}</Text>
                    <Badge color={apprInfo.ap_etat > "0" ? "green" : "red"} size="md">Etat : {apprInfo.ap_etat > "0" ? "Valider" : "Non Valider"}</Badge>
                </Card>
                {apprInfo.ap_etat < "1" && apprCmd.length > 0 && <Button
                    mt={5}
                    onClick={() => handleValidate()}
                    fullWidth
                    color='green'
                >
                    Valider l'approvisionnement
                </Button>
                }
                {apprInfo.ap_etat < "1" && apprRuptureProduct.length > 0 &&
                    <Box>
                        <Divider label={<Text color="dimmed" weight='bold'>Produit en rupture de stock ({formatNumber(apprRuptureProduct.length)})</Text>} />
                        <TextInput
                            icon={<IconSearch size={21} />}
                            placeholder="Chercher un produit"
                            autoComplete="off"
                            autoCorrect="off"
                            {...getSearchProps("nom")}
                            onChange={handleSearch}
                        />
                        <Box component={ScrollArea} style={{ height: 120 }} type="hover">
                            {Array.isArray(apprRuptureProduct) && apprRuptureProduct
                                .filter(searchFilter)
                                .map(d => {
                                    return (
                                        <Group mt={5} key={d.pr_id} spacing={4}>
                                            <Checkbox onClick={() => handleClick({ ...d })} />
                                            <Text weight="bold" color="red">{d.pr_nom}</Text>
                                        </Group>
                                    )
                                })}
                        </Box>
                    </Box>}
            </Grid.Col>
            <Grid.Col md={22}>
                <ApprContenu
                    apprCommand={apprCmd}
                    apprInfo={apprInfo}
                    apId={apId}
                />
            </Grid.Col>
        </Grid>
    )
}