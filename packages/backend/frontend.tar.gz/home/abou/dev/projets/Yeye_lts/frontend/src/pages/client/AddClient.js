import { Notification, Button, Textarea, TextInput } from "@mantine/core"
import useForm from "../../hooks/useForm"
import { addShopClient } from '../../services/api'
import { useMutation, useQueryClient } from "react-query"
import { getError } from '../../utils'

export default function AddClient({ boId, closeModal }) {
    const { formValues, formErr, handleChange, setErrors, cleanForm } = useForm({ nom: "", tel: "", adr: "" })
    const query = useQueryClient()
    const { mutate } = useMutation(["clt"], addShopClient)

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({
            ...formValues,
            nom: formValues.nom.trim(),
            bo_id: boId
        }, {
            onSuccess: () => {
                query.invalidateQueries("clt")
                query.invalidateQueries("clt_adapt")
                cleanForm()
                closeModal()
            },
            onError: (err) => {
                const error = getError(err)
                if (error) setErrors("message", error)
            }
        })
    }

    return (
        <div>
            {formErr.message && <Notification m={5} color="red" onClose={() => setErrors("message", "")}>{formErr.message}</Notification>}
            <form onSubmit={handleSubmit}>
                <TextInput
                    label="Nom du client"
                    placeholder="Nom du client"
                    description="100 caracteres maximum"
                    autoComplete="off"
                    autoCorrect="off"
                    name="nom"
                    value={formValues.nom}
                    onChange={handleChange}
                    required
                    maxLength={100}
                />
                <TextInput
                    label="Telephone"
                    placeholder="Numero de telephone"
                    description="60 caracteres maximun"
                    type="tel"
                    autoComplete="off"
                    autoCorrect="off"
                    name="tel"
                    value={formValues.tel}
                    onChange={handleChange}
                    maxLength={60}
                />
                <Textarea
                    spellCheck={false}
                    label="Adresse du client"
                    description="300 caracteres maximun"
                    placeholder="Adresse du client"
                    autoComplete="off"
                    autoCorrect="off"
                    name="adr"
                    value={formValues.adr}
                    onChange={handleChange}
                    maxLength={300}
                />
                <Button mt={5} type="submit">Ajouter</Button>
            </form>
        </div>
    )
}