import { Alert, Button, Text } from "@mantine/core"
import { useMutation, useQueryClient } from 'react-query'
import { editShopVendre } from '../../services/api'

export default function VenteValidation({ vendId, handleClose, etat }) {
    const query = useQueryClient()
    const { mutate } = useMutation(["vendres"], editShopVendre)
    const handleConfirm = (id) => {
        mutate({ etat: etat || "1", vendId: id }, {
            onSuccess() {
                query.invalidateQueries("vendres_info")
                handleClose()
            }
        })
    }
    return (
        <div>
            {etat === "0" ? <div>
                <Alert color="red" title="Devalidation de la vente">
                    <Text>Cette action est dangereuse vous êtes responsable des actes</Text>
                    <Text>Doit être utiliser pour mettre à jour l'existant </Text>
                </Alert>
                <Button color="orange" mt={5} onClick={() => handleConfirm(vendId)}>Oui, devalider</Button>
            </div> : <Button mt={5} onClick={() => handleConfirm(vendId)}>Oui, valider</Button>}
        </div>
    )
}