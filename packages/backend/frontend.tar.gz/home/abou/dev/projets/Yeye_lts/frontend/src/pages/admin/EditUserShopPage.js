import React from 'react'
import useForm from '../../hooks/useForm'
import { Button, Textarea, TextInput } from '@mantine/core'
import { useMutation, useQueryClient } from 'react-query'
import { editUserShopInfo } from '../../services/api'
import { getError } from '../../utils'

export default function EditUserShopPage({ data, handleClose }) {
    const { formValues, handleChange, setValues, cleanForm, setErrors, getInputProps } = useForm({ nom: "", tel: "", email: "", adr: "" })
    const query = useQueryClient()
    const { mutate } = useMutation(["shop"], editUserShopInfo)

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ ...formValues, boId: data.bo_id }, {
            onSuccess() {
                query.invalidateQueries("shop")
                cleanForm()
                handleClose()
            },
            onError(err) {
                const error = getError(err)
                setErrors("message", error)
            }
        })
    }

    React.useEffect(() => {
        setValues("nom", data.bo_nom)
        setValues("tel", data.bo_tel)
        setValues("email", data.bo_email)
        setValues("adr", data.bo_adr)
    }, [data, setValues])

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <TextInput
                    label="Nom de l'entreprise"
                    placeholder="entrez ici le nom de l'entreprise"
                    autoComplete="off"
                    autoCorrect="off"
                    {...getInputProps("nom")}
                    onChange={handleChange}
                />
                <TextInput
                    label="Telehpone"
                    placeholder="le numero de telephone"
                    autoComplete="off"
                    autoCorrect="off"
                    {...getInputProps("tel")}
                    onChange={handleChange}
                />
                <TextInput
                    type="Email"
                    label="Email"
                    placeholder="entrez ici l'email"
                    autoComplete="off"
                    autoCorrect="off"
                    {...getInputProps("email")}
                    onChange={handleChange}
                />
                <Textarea
                    spellCheck={false}
                    label="Adresse"
                    placeholder="entrez ici l'adresse"
                    autoComplete="off"
                    autoCorrect="off"
                    {...getInputProps("adr")}
                    onChange={handleChange}
                />
                <Button mt={5} type="submit">Modifier</Button>
            </form>
        </div>
    )
}