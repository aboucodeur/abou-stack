import React from 'react'
import { modals } from "@mantine/modals"
import { useLocalStorage } from "@mantine/hooks"
import { instance } from '../../axios'
import useForm from "../../hooks/useForm"
import Cookies from 'js-cookie'
import { useLocation, useNavigate } from "react-router-dom"
import { Button, PasswordInput, TextInput, Anchor, Group, Notification, Checkbox } from '@mantine/core'
import SecureQuestion from './SecureQuestion'
import { useAppState } from "../../context/AppContext"
import { AUTH_LOGIN, USER_LOGIN } from '../../context/action/action'

export default function AdminLogin() {
    const navigate = useNavigate()

    const location = useLocation()
    const [isChecked, setIsChecked] = React.useState(false)
    const { dispatch } = useAppState()
    const origin = location?.state?.from?.pathname || "/admin/dashboard"
    const [getAdminTel, setAdminTel] = useLocalStorage({ key: "yy_admin_tel", defaultValue: "" })

    const { formValues, formErr, handleSubmit, setErrors, setValues, getInputProps, handleChange } = useForm({ tel: "", pass: "" }, async (values) => {
        try {
            const adminLogin = await instance.post("/users_auth/login", { ...values })
            const { data } = adminLogin
            dispatch({ type: AUTH_LOGIN })
            dispatch({ type: USER_LOGIN, payload: { users: data } })
            Cookies.set("yy_admin_token", data.token, { sameSite: "Strict", expires: 365 })
            navigate(origin)
        } catch (err) {
            const getErr = err?.response?.data.message
            setErrors("message", getErr)
        }
    })

    const validates = (values, err) => {
        const { pass } = values
        if (pass.length < 8) err.pass = "Au moins huits(8) caractères"
    }
    const remenberMe = () => {
        setIsChecked(!isChecked)
        if (!formValues.tel) return
        setAdminTel(formValues.tel)
    }
    const securityQuestionModal = () => {
        modals.open({
            title: "Question de secuirté",

            children: <SecureQuestion handleClose={() => modals.closeAll()} />

        })
    }
    React.useEffect(() => {
        if (!getAdminTel) return
        setValues("tel", getAdminTel)
        setIsChecked(true)
    }, [setValues, getAdminTel])

    return (
        <div>
            {formErr.message && <Notification m={5} onClose={() => setErrors("message", "")} color="red">{formErr.message}</Notification>}
            <form onSubmit={(e) => handleSubmit(e, validates)}>
                <TextInput
                    label="Telephone"
                    placeholder="telehpone"
                    type="tel"
                    autoComplete="off"
                    autoCorrect="off"
                    {...getInputProps("tel")}
                    onChange={handleChange}
                    required
                    error={formErr.tel}
                    autoFocus
                />
                <PasswordInput
                    label="Mot de passe"
                    placeholder="Mot de passe"
                    autoComplete="off"
                    autoCorrect="off"
                    {...getInputProps("pass")}
                    onChange={handleChange}
                    required
                    error={formErr.pass}

                />
                <Group spacing={5}>
                    <Anchor onClick={() => securityQuestionModal()}>Oublier mon mot de passe</Anchor>
                </Group>
                <Checkbox
                    checked={isChecked}
                    mt={5}
                    label="Se souvenir de moi"
                    onChange={() => remenberMe()}
                />
                <Button mt={5} fullWidth type="submit">Se Connecter</Button>
            </form>
        </div>
    )
}