import { useMemo } from "react"
import {
    MantineReactTable,
    useMantineReactTable,
    MRT_TablePagination,
    MRT_ToolbarAlertBanner,
} from "mantine-react-table"
import { MRT_Localization_FR } from "mantine-react-table/locales/fr"
import { Box, Flex } from "@mantine/core"

export default function MTRTable({
    // ** Proprietes de base
    uId = "",
    columns = [],
    data,
    hooksCreatingOptions = {
        // ** custom | modal | row
        createDisplayMode: undefined,
    },
    hooksEditingOptions = {
        // ** true | false
        enableEditing: false,
        // ** custom | modal | row
        editDisplayMode: undefined,
        // ** last | first
        positionActionsColumn: "",
    },
    minH = undefined,
    maxH = undefined,
    // ** REGISTER METHOD (TOOLTOPBAR,CUSTOM_ACTION)
    handleCreate = async ({ values, exitCreatingMode }) => {},
    handleEdit = async ({ values, exitCreatingMode }) => {},
    renderRowActions = ({ row, table }) => {},
    renderTopToolbarCustomActions = ({ table }) => {},
    // ** VALEUR INITIALS
    initialState = {},
    // ** ERRORS MANAGEMENT STATE AND VISUAL ERROR
    validationErrors = {},
    setValidationErrors = () => {},
    visual = {
        // ** loaders
        dataLoader: false,
        addLoader: false,
        editLoader: false,
        removeLoader: false,
        // ** errors
        dataError: false,
        addError: false,
        editError: false,
        removeError: false,
        // ** fecthing
        dataFetching: false,
    },
    ...rest
}) {
    // ** prepare table colums and dynamic id (hide to edit page)
    const getColums = useMemo(
        () => [
            {
                accessorKey: uId,
                header: "No",
                enableEditing: false,
                enableColumnActions: false,
                enableSorting: false,
                enableHiding: false,
                enableGlobalFilter: false,
                enableColumnFilter: false,
                enableGrouping: false,
                // ** Alias the id value to index
                Cell: ({ row }) => row.index + 1,
                // ** Masquer lors de la modification
                mantineEditTextInputProps: {
                    style: { display: "none" },
                },
                size: 10,
            },
            ...columns,
        ],
        [columns, uId],
    )

    const table = useMantineReactTable({
        columns: getColums,
        data: data,
        ...hooksCreatingOptions,
        ...hooksEditingOptions,
        // ** STYLE DU TABLEAUX
        mantineTableContainerProps: {
            sx: {
                minHeight: minH || undefined,
                maxHeight: maxH || undefined,
            },
        },
        mantineTableProps: {
            striped: true,
        },
        // ** PERFORMANCE SETTINGS
        enableDensityToggle: true,
        initialState: {
            // a permis de render la modification sans voir l'id avec le camouflage et enableEditing
            // columnVisibility: { [uId]: false }, bug pour la modification
            ...initialState,
        },
        // ** INDEXATION & RECHERCHER
        enableColumnFilters: false,
        // enableGlobalFilterModes: true,
        // ** METHODE DE RENDU ET OPERATIONS CRUD
        getRowId: (row) => row[uId],
        onCreatingRowCancel: () => {},
        onCreatingRowSave: handleCreate || undefined,
        onEditingRowCancel: () => {},
        onEditingRowSave: handleEdit || undefined,
        renderRowActions: renderRowActions || undefined,
        renderTopToolbarCustomActions: renderTopToolbarCustomActions || undefined,
        // ** INTERNATIONALIZATION ~ ICI PAR DEFAUT FRANCAIS
        localization: MRT_Localization_FR,
        // ** Info visuels
        mantineToolbarAlertBannerProps:
            visual?.dataError || visual?.addError || visual?.editError || visual?.removeError
                ? {
                      color: "red",
                      children: validationErrors?.message || "Impossible de charger les donnees",
                  }
                : undefined,
        state: {
            isLoading: visual?.dataLoader,
            isSaving: visual?.addLoader || visual?.editLoader || visual?.removeLoader,
            showAlertBanner:
                visual?.dataError || visual?.addError || visual?.editError || visual?.removeError,
            showProgressBars: visual?.dataFetching,
        },
        // ** seulement pour le positionnement de la pagination
        renderBottomToolbar: ({ table }) => {
            return (
                <Box>
                    <Flex justify="flex-start">
                        {/* eslint-disable-next-line react/jsx-pascal-case */}
                        <MRT_TablePagination table={table} />
                    </Flex>
                    <Box sx={{ display: "grid", width: "100%" }}>
                        {/* eslint-disable-next-line react/jsx-pascal-case */}
                        <MRT_ToolbarAlertBanner stackAlertBanner table={table} />
                    </Box>
                </Box>
            )
        },
        // ** bare de recherche
        positionGlobalFilter: "right",
        mantineSearchTextInputProps: {
            placeholder: "Rechercher globale",
            sx: { minWidth: "300px" },
            variant: "outlined",
        },
        ...rest,
    })

    return <MantineReactTable table={table} />
}
