import React, { Fragment } from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { useAppState } from '../../context/AppContext';
import { useQuery } from 'react-query';
import { instance } from '../../axios';
import { Loader, Text } from '@mantine/core';

// ** les composants des graphes
export const ProductChart = () => {
    const { getShop } = useAppState()
    const shopId = getShop.bo_id
    const { data: iaData = [], isLoading } = useQuery(["ia", shopId],
        ({ queryKey }) => instance.get(`/ia/info_ia/${queryKey[1]}`).then(res => res.data)
    )

    if (isLoading) return <Loader />
    return (
        <Fragment>
            <Text weight="bold" align="center">Top 10 des produits vendus</Text>
            <ResponsiveContainer width="80%" height={500}>
                <LineChart data={iaData.product}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis padding={{ left: 0, right: 0 }} dataKey="pr_nom" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="total_ventes" stroke="#8884d8" />
                </LineChart>
            </ResponsiveContainer>
        </Fragment>
    )
}