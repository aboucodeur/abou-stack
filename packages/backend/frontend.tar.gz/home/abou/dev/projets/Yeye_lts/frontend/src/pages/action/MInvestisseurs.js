import React from 'react'
import { Notification, Button, TextInput } from "@mantine/core"
import useForm from "../../hooks/useForm"
import { updateInvestisseur } from '../../services/api'
import { useMutation, useQueryClient } from "react-query"
import { getError } from '../../utils'

export default function MInvestisseur({ data, closeModal }) {
    const { formValues, formErr, handleChange, setErrors, setValues, cleanForm } = useForm({ nom: "" })
    const query = useQueryClient()
    const { mutate } = useMutation(["act"], updateInvestisseur)

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({
            ...formValues,
            nom: formValues.nom.trim(),
            invId: data.inv_id
        }, {
            onSuccess: () => {
                query.invalidateQueries("act")
                cleanForm()
                closeModal()
            },
            onError: (err) => {
                const error = getError(err)
                if (error) setErrors("message", error)
            }
        })
    }

    // ** default Value
    React.useEffect(() => {
        setValues("nom", data.nom)
    }, [data, setValues])

    return (
        <div>
            {formErr.message && <Notification m={5} color="red" onClose={() => setErrors("message", "")}>{formErr.message}</Notification>}
            <form onSubmit={handleSubmit}>
                <TextInput
                    label="Nom actionnaire"
                    description="200 caracteres maximum"
                    autoComplete="off"
                    autoCorrect="off"
                    name="nom"
                    value={formValues.nom}
                    onChange={handleChange}
                    required
                    maxLength={200}
                />
                <Button mt={5} type="submit">Modifier</Button>
            </form>
        </div>
    )
}