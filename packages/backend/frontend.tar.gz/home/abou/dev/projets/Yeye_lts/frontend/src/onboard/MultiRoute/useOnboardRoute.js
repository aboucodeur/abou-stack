import { useCallback } from 'react'
import { useNavigate } from 'react-router-dom'

export default function useOnboardRoute() {
    const navigate = useNavigate()

    // TODO : implement direct user navigation
    const ta = useCallback(
        (to = '') => {
            if (to !== null) navigate(to)
        },
        [navigate],
    )

    // TODO : implement direct user navigation with current path verification
    const taPath = useCallback(
        (to = '') => {
            if (to !== null && window.location.pathname !== to) navigate(to)
        },
        [navigate],
    )

    return { ta, taPath }
}
