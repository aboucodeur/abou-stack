import { useEffect, useState } from 'react'
import {
    Notification,
    Button,
    NumberInput,
    TextInput,
    Select,
    Box,
    Text,
    Group,
} from '@mantine/core'
import useForm from '../../hooks/useForm'
import { addProduct, getShopDepotAdaptSelect } from '../../services/api'
import { useMutation, useQuery, useQueryClient } from 'react-query'
import { getError } from '../../utils'
import Barcode from '../../components/barcode/Barcode'
import { Unity } from '../../mock'
import { useFocusTrap } from '@mantine/hooks'
import { CLOSE } from '../../onboard'

// static-datas
const MIMES_TYPES = {
    'image/jpeg': 'jpg',
    'image/jpg': 'jpg',
    'image/png': 'png',
}

export default function AddProduct({
    deId,
    boId,
    handleClose,
    isStock = false,
    setState = () => undefined,
}) {
    const initialValues = { nom: '', unite: '', pv: 0, pa: 0, file: null }
    const {
        formValues,
        formErr,
        setErrors,
        handleChange,
        getInputProps,
        cleanForm,
        setValues,
        onError,
    } = useForm(initialValues)
    const [code, setCode] = useState('')

    const { data: shopDepot = [], isFetched } = useQuery(['dep_adapt', boId], ({ queryKey }) =>
        getShopDepotAdaptSelect(queryKey[1]),
    )
    const { mutate } = useMutation(['prod'], addProduct)

    const [getDeId, setGetDeId] = useState()

    const query = useQueryClient()
    const focusTrap = useFocusTrap()

    // ** one file upload
    const handleUpload = (e) => {
        const isFile = e.target.files[0]
        if (!isFile) return null
        setValues('file', isFile)
    }

    const handleSubmit = (e) => {
        e.preventDefault()
        const formData = new FormData()
        formData.append('nom', formValues.nom.trim())
        formData.append('unite', formValues.unite || 'unites')
        formData.append('file', formValues.file)
        formData.append('pa', formValues.pa)
        formData.append('pv', formValues.pv)
        formData.append('de_id', isStock ? getDeId : deId)
        formData.append('bo_id', boId)
        if (code) formData.append('code', code)
        onError({ ...formValues }, (values, err) => {
            const { pv, pa, file } = values
            if (pa > pv) err.pa = 'Oops pas de benefice !!!'
            if (file && !MIMES_TYPES[file.type]) err.file = 'Fichier :( .jpeg, .jpg, .png)'
            if (isStock ? !getDeId : !deId) err.depot = 'Selectionner un depots !'
            if (Object.entries(err).length === 0) {
                mutate(formData, {
                    onSuccess: () => {
                        query.invalidateQueries('prod')
                        query.invalidateQueries('stock_prev')
                        query.invalidateQueries('prod_adapt')
                        cleanForm()
                        handleClose()
                        setState({ run: true, stepIndex: CLOSE.product.modal })
                    },
                    onError: (err) => {
                        const error = getError(err)
                        setErrors('message', error)
                        handleClose()
                    },
                })
            }
        })
    }

    useEffect(() => {
        if (isFetched && isStock) setGetDeId(shopDepot[0].value)
    }, [isFetched, isStock, shopDepot])

    return (
        <div>
            {formErr.message && (
                <Notification m={5} onClose={() => setErrors('message', '')} color="red">
                    {formErr.message}
                </Notification>
            )}
            <form onSubmit={handleSubmit} ref={focusTrap}>
                <Barcode onScan={(barcode) => setCode(barcode)} />
                <TextInput
                    id="input_add_product_name_2"
                    label="Nom du produit"
                    autoComplete="off"
                    autoCorrect="off"
                    required
                    {...getInputProps('nom')}
                    onChange={handleChange}
                    data-autofocus
                />
                <Box mt={5}>
                    <input
                        type="file"
                        autoComplete="off"
                        autoCorrect="off"
                        onChange={handleUpload}
                    />
                    <Text color="red">{formErr.file}</Text>
                </Box>
                <Select
                    id="input_add_product_unity_3"
                    label="Unite du produit"
                    autoComplete="off"
                    autoCorrect="off"
                    clearable
                    searchable
                    data={Unity}
                    defaultValue="unites"
                    onChange={(value) => setValues('unite', value)}
                    required
                    maxDropdownHeight={190}
                />
                {isStock && (
                    <Select
                        id="select_add_product_depot_4"
                        label="Choisir le depot"
                        data={shopDepot}
                        value={isStock ? getDeId : deId}
                        onChange={(value) => setGetDeId(value)}
                        autoComplete="off"
                        autoCorrect="off"
                        required
                        error={formErr.depot}
                        maxDropdownHeight={190}
                    />
                )}
                <Group spacing={3}>
                    <NumberInput
                        id="numberinput_add_product_aprice_5"
                        label="Prix d'achat"
                        autoComplete="off"
                        autoCorrect="off"
                        style={{ width: '193px' }}
                        value={formValues.pa}
                        onChange={(value) => setValues('pa', value)}
                        required
                        maxLength={20}
                        min={0}
                        error={formErr.pa}
                        precision={2} // decimal
                    />
                    <NumberInput
                        id="numberinput_add_product_vprice_6"
                        label="Prix de vente"
                        autoComplete="off"
                        autoCorrect="off"
                        style={{ width: '193px' }}
                        value={formValues.pv}
                        onChange={(value) => setValues('pv', value)}
                        required
                        maxLength={20}
                        min={0}
                        error={formErr.pv}
                        precision={2} // decimal
                    />
                </Group>
                <TextInput
                    label="Code bare"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    autoComplete="off"
                    autoCorrect="off"
                />
                <Button
                    id="button_add_product_submit_7"
                    fullWidth
                    type="submit"
                    mt={5}
                    color="green"
                    variant="outline"
                >
                    Ajouter
                </Button>
            </form>
        </div>
    )
}
