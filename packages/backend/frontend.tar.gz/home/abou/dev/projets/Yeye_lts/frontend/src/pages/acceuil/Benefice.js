import { useMemo } from 'react'
import { Group, Paper, Select, Text, TextInput } from '@mantine/core'
import useSearch from '../../hooks/useSearch'
import useYear from '../../hooks/useYear'
import { months } from '../../mock'
import { useQuery } from 'react-query'
import { getBenefice } from '../../services/api'
import { SearchFound, VirtualTable } from '../../components'
import useHeight from '../../hooks/useHeight'
import { IconSearch } from '@tabler/icons-react'
import { formatNumber, formatWari } from '../../helper'
import { toLower } from '../../utils'

export default function Benefice({ boId }) {
    const { wH } = useHeight(110)
    const { searchVal, setSearch, getSearchProps, handleSearch } = useSearch({
        m: new Date().getUTCMonth() + 1,
        a: new Date().getFullYear(),
        nom: ""
    })
    const year = useYear()
    const { data = [], isLoading } = useQuery(['benefice', boId], ({ queryKey }) => getBenefice(queryKey[1]))

    // rows 
    // ! fix bugs 
    function filterBf(datas, mois, annee, term = "") {
        const query = toLower(term)
        return datas
            .filter((d) => mois ? d.mois === parseFloat(searchVal.m - 1) : d)
            .filter((d) => annee ? d.annee === parseFloat(searchVal.a) : d)
            .filter((d) => term ? toLower(d.pr_nom).includes(query) : d)

    }
    const filteredDatas = filterBf(data, searchVal.m, searchVal.a, searchVal.nom)
    const Rows = ({ index }) => {
        const { pr_nom, benefice } = filteredDatas[index]
        return (
            <tr>
                <td><Text>{index + 1}</Text></td>
                <td><Text size={16}>{pr_nom}</Text></td>
                <td><Text size={16}>{formatNumber(benefice)}</Text></td>
            </tr>
        )
    }

    const totalBenefice = formatWari(useMemo(() => filteredDatas.reduce((acc, curr) => acc + parseFloat(curr.benefice, 10), 0), [filteredDatas]))
    if (isLoading) return
    return (
        <div>
            <Paper shadow="lg" p="md">
                <Text color="dimmed">Recherche</Text>
                <Group spacing={3}>
                    <TextInput
                        icon={<IconSearch />}
                        placeholder="Chercher un produit ..."
                        {...getSearchProps("nom")}
                        onChange={handleSearch}
                        autoCorrect="off"
                    />
                    <Select
                        data={[{ label: "Tous les mois", value: "" }, ...months]}
                        placeholder="Mois"
                        searchable
                        clearable
                        nothingFound="Mois introuvable"
                        value={searchVal.m}
                        onChange={(value) => setSearch("m", value ? value : "")}
                    />
                    <Select
                        data={[{ label: "Tous les ans", value: "" }, ...year]}
                        placeholder="Année"
                        searchable
                        clearable
                        nothingFound="Annee introuvable ou depasser"
                        value={searchVal.a}
                        onChange={(value) => setSearch("a", value ? value : "")}
                    />
                </Group>
                <Text mt={5} size={19}>Benefice totals : {totalBenefice} </Text>
            </Paper>
            {filteredDatas?.length === 0
                ? <SearchFound message='Aucun produit pour le moment' />
                : <VirtualTable
                    header={["N°", "Produit", "Benefice"]}
                    height={wH}
                    itemCount={filteredDatas?.length}
                    row={Rows}
                />
            }
        </div>
    )
}
