import ReactDOM from 'react-dom/client'
import AppContext from './context/AppContext'
import { BrowserRouter } from 'react-router-dom'
import { MantineProvider } from '@mantine/core'
import { ModalsProvider } from '@mantine/modals'
import { QueryClient, QueryClientProvider } from 'react-query'
import { HelmetProvider } from 'react-helmet-async'
import { DatesProvider } from '@mantine/dates'
import './styles/index.css'
import App from './App'
import { MultipleRouteOnboardProvider } from './onboard/MultiRoute/context'
import { ErrorBoundaries } from './components'

const client = new QueryClient({
    defaultOptions: {
        queries: {
            refetchOnWindowFocus: false,
        },
    },
})

const helmetContext = {}
ReactDOM.createRoot(document.getElementById('root')).render(
<ErrorBoundaries>
    <HelmetProvider context={helmetContext}>
        <AppContext>
            <QueryClientProvider client={client}>
                <BrowserRouter>
                    <MantineProvider withNormalizeCSS withGlobalStyles>
                        <DatesProvider settings={{ locale: 'fr' }}>
                            {/* Modal de mantine */}
                            <ModalsProvider>
                                <MultipleRouteOnboardProvider>                                    
                                        <App />
                                </MultipleRouteOnboardProvider>
                            </ModalsProvider>
                        </DatesProvider>
                    </MantineProvider>
                </BrowserRouter>
            </QueryClientProvider>
        </AppContext>
    </HelmetProvider>
</ErrorBoundaries>
)
