import { Button, Card, Group, Menu, Text, Title } from "@mantine/core";
import { modals } from "@mantine/modals";
import { useQuery } from "react-query";
import { AppTable } from "../../../components";
import { getShopLicence } from "../../../services/api";
import AddLicenceModal from "./AddLicenceModal";
import RemoveLicenceModal from "./RemoveLicenceModal";

export default function LicencePage({ boId, handleClose }) {
    const { data: shopLicence = {} } = useQuery(["lic", boId], ({ queryKey }) => getShopLicence(queryKey[1]))

    const addModal = () => {
        modals.open({
            title: "Nouvelle licence",

            children: <AddLicenceModal
                boId={boId}
                handleClose={() => modals.closeAll()}
            />
        })
    }
    const removeModal = (licId) => {
        modals.open({
            title: "Suppression du licence",

            children: <RemoveLicenceModal
                licId={licId}
                handleClose={() => modals.closeAll()}
            />
        })
    }

    const rows = <tr>
        <td><Text>{new Date(shopLicence.createdAt).toLocaleDateString()}</Text></td>
        <td>
            <Menu trigger="click">
                <Menu.Target>
                    <Button>Options</Button>
                </Menu.Target>
                <Menu.Dropdown>
                    <Menu.Item
                        color="red"
                        onClick={() => removeModal(shopLicence.lic_id)}
                    >Supprimer</Menu.Item>
                </Menu.Dropdown>
            </Menu>
        </td>
    </tr>

    if (Object.entries(shopLicence).length === 0) return (
        <div>
            <Text>Auncun licence</Text>
            <Button mt={5} onClick={() => addModal()}>Nouvelle licence</Button>
        </div>
    )
    return (
        <div>
            <div>
                <Card shadow="lg" sx={(theme) => ({ backgroundColor: theme.colors.blue[6], color: "white" })} mt={5}>
                    <Title order={3}>Informations</Title>
                    <Text>Date d'expiration : {new Date((shopLicence.exp * 1000)).toLocaleString()}</Text>
                </Card>
                <Group spacing={4}>
                    <Button mt={5} onClick={() => addModal()}>Nouvelle licence</Button>
                    <Button mt={5} color="orange" onClick={() => handleClose()}>Fermer</Button>
                </Group>
            </div>
            <div>
                <AppTable
                    title="Licence en cours"
                    tableHead={["Date", "Action"]}
                    tableRows={rows}
                    mw="auto"
                />
            </div>
        </div>
    )
}