import { useEffect, useState } from 'react'
import {
    Group,
    PasswordInput,
    Checkbox,
    Paper,
    Title,
    Container,
    Button,
    Notification,
    Text,
    Anchor,
} from '@mantine/core'
import UserChoice from './UserChoice'
import useForm from '../../hooks/useForm'
import { modals } from '@mantine/modals'
import { useLocalStorage } from '@mantine/hooks'
import Cookies from 'js-cookie'
import { instance } from '../../axios'
import { getError } from '../../utils'
import { useFocusTrap } from '@mantine/hooks'
import { APP_NAME } from '../../constant'
import { NavLink } from 'react-router-dom'
import { PhoneInput } from 'react-international-phone'
import 'react-international-phone/style.css'

export default function Login() {
    const [isChecked, setisChecked] = useState(false)
    const [getUserTel, setUserTel] = useLocalStorage({
        key: 'yy_user_tel',
        defaultValue: '+223 ', // cette valeur par defaut vas aider les anciens utilisateur
    })
    const focusTrap = useFocusTrap()

    const { formValues, formErr, handleChange, handleSubmit, getInputProps, setErrors, setValues } =
        useForm({ tel: '', pass: '' }, async (values) => {
            try {
                const userLogin = await instance.post('/users_auth/login', { ...values })
                const { data } = userLogin
                const token = data.token
                const usId = data.us_id
                Cookies.set('yy_user_token', token, { sameSite: 'Strict', expires: 365 })
                const { data: shopDatas } = await instance.get(`/boutiques/utilisateur/${usId}`)
                const { total, userBoutique } = shopDatas
                if (total > 0) {
                    modals.open({
                        title: 'Entreprise',
                        children: (
                            <UserChoice data={userBoutique} handleClose={() => modals.closeAll()} />
                        ),
                    })
                }
            } catch (err) {
                const error = getError(err)
                if (error) setErrors('message', error)
            }
        })

    const remenberMe = () => {
        setisChecked(!isChecked)
        if (!formValues.tel) return
        setUserTel(formValues.tel)
    }
    const validates = (values, err) => {
        const { pass } = values
        if (pass.length < 5) err.pass = 'Mot de passe trop court'
    }

    useEffect(() => {
        if (!getUserTel) return
        setValues('tel', getUserTel)
        setisChecked(true)
    }, [getUserTel, setValues])

    // ** plus recuperer directement les feedback avec et outils : twak
    return (
        <Container size={400} my={90}>
            <div style={{ textAlign: 'center' }}>
                <Title
                    style={{ fontFamily: 'Greycliff CF, sans-serif', fontWeight: 800 }}
                    order={1}
                >
                    {APP_NAME}
                </Title>
                <Text size="lg" weight="bold">
                    Conçue pour simplifier et accélérer la gestion de vos stocks
                    <span role="img" aria-labelledby="toner">
                        ⚡
                    </span>
                    . <br />
                </Text>
            </div>
            <Anchor component={NavLink} to="/signup">
                <Text mt={6} align="center">
                    Creer mon compte, je n'est pas de compte ?
                </Text>
            </Anchor>
            <Paper withBorder shadow="md" mt={15} p={30} radius="md">
                {formErr.message && (
                    <Notification m={5} color="red" onClose={() => setErrors('message', '')}>
                        {formErr.message}
                    </Notification>
                )}
                <form action="" onSubmit={(e) => handleSubmit(e, validates)} ref={focusTrap}>
                    <Group align="center" spacing={1}>
                        <Text size={13}>Numero de telephone</Text>
                        <Text color="red">*</Text>
                    </Group>
                    <PhoneInput
                        inputStyle={{
                            width: '100%',
                            fontSize: '16px',
                        }}
                        inputProps={{
                            id: 'user_input',
                            placeholder: '+223 94865879',
                            required: true,
                        }}
                        defaultCountry="ml"
                        {...getInputProps('tel')}
                        onChange={(phone) => setValues('tel', phone)}
                    />
                    <PasswordInput
                        id="user_password"
                        label="Mot de passe"
                        placeholder="Mot de passe"
                        required
                        {...getInputProps('pass')}
                        onChange={handleChange}
                        mb={20}
                        variant="filled"
                        autoComplete=""
                    />
                    <Checkbox
                        checked={isChecked}
                        onChange={() => remenberMe()}
                        label="Se souvenir de moi"
                        style={{ marginBottom: '20px' }}
                    />
                    <Button type="submit" fullWidth radius="lg">
                        SE CONNECTER
                    </Button>
                </form>
            </Paper>
        </Container>
    )
}
