import { modals } from '@mantine/modals'
import { Anchor, Button, Group, Image, Menu, Spoiler, Text, Tooltip } from '@mantine/core'
import { useQuery } from 'react-query'
import { getShopStock } from '../../services/api'
import AddProduct from '../depots/AddProduct'
import { IconFileImport } from '@tabler/icons-react'
import ImportFile from '../importation/ImportFile'
import { useAppState } from '../../context/AppContext'
import { API_URL } from '../../constant'
// ** MRT
import MTRTable from '../../components/table/MTRTable'
import { useCallback, useEffect, useMemo } from 'react'
import { formatNumber } from '../../helper'
import useOnboardModal from '../../onboard/MultiRoute/useOnboardModal'
import { AUTO } from '../../onboard'

export default function Stock({ boId }) {
    const { getShop } = useAppState()
    const shopId = getShop.bo_id
    const {
        data: stockPrevision = [],
        isLoading,
        isFetching,
        isError,
    } = useQuery(['stock_prev', boId], ({ queryKey }) => getShopStock({ boId: queryKey[1] }))

    const { blockOnboard, setState } = useOnboardModal()

    const openImportModal = () => {
        modals.open({
            title: 'Importation de produit',
            children: <ImportFile handleClose={() => modals.closeAll()} boId={shopId} />,
        })
    }

    const handleAddProduct = useCallback(() => {
        modals.open({
            title: 'Nouveau produit',
            children: (
                <AddProduct
                    boId={boId}
                    isStock={true}
                    handleClose={() => modals.closeAll()}
                    setState={setState}
                />
            ),
        })
        setState({ run: true, stepIndex: 2 })
    }, [boId, setState])

    const isArr = Array.isArray(stockPrevision)
    const qteTotal = useMemo(
        () => isArr && stockPrevision.reduce((acc, curr) => acc + parseFloat(curr.pr_qte), 0),
        [stockPrevision, isArr],
    )
    const qteEntree = useMemo(
        () => isArr && stockPrevision.reduce((acc, curr) => acc + parseFloat(curr.entree), 0),
        [stockPrevision, isArr],
    )
    const qteSortie = useMemo(
        () => isArr && stockPrevision.reduce((acc, curr) => acc + parseFloat(curr.sortie), 0),
        [stockPrevision, isArr],
    )

    // ** MRT
    const columns = [
        {
            accessorKey: 'pr_url',
            header: 'Image',
            Cell: ({ cell }) => {
                return cell.getValue() && cell.getValue() ? (
                    <Spoiler maxHeight={0} showLabel="ouvrir l'image" hideLabel="fermer">
                        <Menu trigger="hover">
                            <Menu.Target>
                                <Image
                                    fit="contain"
                                    width={100}
                                    height={80}
                                    src={cell.getValue()}
                                    alt={`photo de ${cell.getValue()}`}
                                />
                            </Menu.Target>
                            <Menu.Dropdown>
                                <Menu.Label>Options</Menu.Label>
                                <Menu.Item color="blue">
                                    <Anchor href={cell.getValue()} target="_blank">
                                        Ouvrir
                                    </Anchor>
                                </Menu.Item>
                            </Menu.Dropdown>
                        </Menu>
                    </Spoiler>
                ) : (
                    <Text>Aucune Image</Text>
                )
            },
            size: 120,
        },
        {
            accessorKey: 'pr_nom',
            header: 'Produit(s)',
        },
        {
            accessorKey: 'pr_qte',
            header: 'Quantite(s)',
            Footer: () => <Text color="dimmed">Stocks : {formatNumber(qteTotal)}</Text>,
            Cell: ({ cell }) => formatNumber(cell.getValue()),
        },
        {
            accessorKey: 'pr_pa',
            header: "Prix d'achat",
            Cell: ({ cell }) => formatNumber(cell.getValue()),
        },
        {
            accessorKey: 'entree',
            header: 'Entree(s)',
            Cell: ({ cell }) => formatNumber(cell.getValue()),
            Footer: () => <Text color="green">Entrees : {formatNumber(qteEntree)}</Text>,
        },
        {
            accessorKey: 'sortie',
            header: 'Sortie(s)',
            enableColumnFilters: false,
            Cell: ({ cell }) => formatNumber(cell.getValue()),
            Footer: () => <Text color="red">Sorties : {formatNumber(qteSortie)}</Text>,
        },
    ]

    useEffect(() => {
        blockOnboard(AUTO.product.modal)
    }, [blockOnboard])

    return (
        <MTRTable
            uId="pr_id"
            columns={columns}
            data={stockPrevision}
            visual={{
                dataLoader: isLoading,
                dataError: isError,
                dataFetching: isFetching,
            }}
            renderTopToolbarCustomActions={() => (
                <div>
                    <Group spacing={3} mb={5}>
                        <Tooltip label="Ajouter un produit" withArrow>
                            <Button
                                id="button_add_product_1"
                                onClick={handleAddProduct}
                                variant="outline"
                                mt={5}
                            >
                                Nouveau produit
                            </Button>
                        </Tooltip>
                        <Tooltip label="Importer vos donnée excel" withArrow>
                            <Button
                                mt={5}
                                color="green"
                                onClick={openImportModal}
                                variant="outline"
                            >
                                <IconFileImport />
                                <Text>Importer</Text>
                            </Button>
                        </Tooltip>
                        <Tooltip withArrow label="Importer plusieurs produits a la fois">
                            <Button
                                mt={5}
                                component={Anchor}
                                href={`${API_URL}/documents/inventaire/${shopId}?n=-1`}
                                target="_blank"
                                variant="outline"
                                color="orange"
                            >
                                Fiche d'inventaire
                            </Button>
                        </Tooltip>
                    </Group>
                </div>
            )}
        />
    )
}
