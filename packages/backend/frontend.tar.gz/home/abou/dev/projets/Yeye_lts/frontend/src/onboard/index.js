// context global de l'application
export * from './MultiRoute/context'

// logique metier du onboarding
export * from './MultiRoute/Wrapper'

// crochets pour les fonctionnalites basic (nextStep, prevStep, stayStep)
export * from './MultiRoute/useBasic'

// crochets pour les fonctionnalites de gestion de modal (autoLoadOnboard, closeOnboard, blockOnboard)
export * from './MultiRoute/useOnboardModal'

// crochets pour les fonctionnalites de gestion de route (ta, taPath)
export * from './MultiRoute/useOnboardRoute'

// function utilitaires necessaires

const actions = {
    INIT: 'init',
    START: 'start',
    STOP: 'stop',
    RESET: 'reset',
    RESTART: 'restart',
    PREV: 'prev',
    NEXT: 'next',
    GO: 'go',
    INDEX: 'index',
    CLOSE: 'close',
    SKIP: 'skip',
    UPDATE: 'update',
}
/**
 * @typedef {(action: import('react-joyride').actions) => void } wrapStepAfterCb
 */

/**
 * Guider l'utilisateur de pas a pas avec le next bouton power
 *
 * @param { 'step:after' | string} type
 * @param { wrapStepAfterCb } cb
 * @returns
 */
export function wrapStepAfter(cb, type = 'step:after') {
    if (type === 'step:after') cb(actions)
}
