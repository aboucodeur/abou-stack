import React from "react"
import { Button, Notification, Radio, TextInput } from "@mantine/core"
import { useMutation, useQueryClient } from "react-query"
import useForm from "../../hooks/useForm"
import { editGerant } from "../../services/api"
import { getError } from "../../utils"

export default function EditGerant({ data, handleClose }) {
    const { formValues, formErr, getInputProps, handleChange, setErrors, setValues, cleanForm } = useForm({
        prenom: "",
        nom: "",
        email: "",
        tel: "",
        etat: ""
    })
    const { mutate } = useMutation("ger", editGerant)
    const query = useQueryClient()
    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ ...formValues, usId: data.us_id }, {
            onSuccess() {
                query.invalidateQueries("ger")
                cleanForm()
                handleClose()
            },
            onError(err) {
                const getErr = getError(err)
                if (getErr) setErrors("message", getErr)
            }
        })
    }
    React.useEffect(() => {
        setValues("prenom", data.us_prenom)
        setValues("nom", data.us_nom)
        setValues("email", data.us_email)
        setValues("tel", data.us_tel)
        setValues("etat", data.disabled ? "1" : "0")
    }, [data, setValues])

    return (
        <form onSubmit={handleSubmit}>
            {formErr.message && <Notification color="red" onClose={() => setErrors("message", "")}>{formErr.message}</Notification>}
            <TextInput
                label="Prenom"
                placeholder="Donner le prenom"
                autoComplete="off"
                autoCorrect="off"
                {...getInputProps("prenom")}
                onChange={handleChange}
            />
            <TextInput
                label="Nom"
                placeholder="Donner le nom"
                autoComplete="off"
                autoCorrect="off"
                {...getInputProps("nom")}
                onChange={handleChange}
            />
            <TextInput
                label="Email"
                placeholder="Donner le 'email"
                autoComplete="off"
                autoCorrect="off"
                {...getInputProps("email")}
                onChange={handleChange}
            />
            <TextInput
                label="Télephone"
                placeholder="Donner votre télephone"
                type="tel"
                {...getInputProps("tel")}
                onChange={handleChange}
            />
            <Radio.Group
                value={formValues.etat}
                onChange={(value) => setValues("etat", value)}
                name="user_state"
                withAsterisk
            >
                <Radio value="0" label="Activer" />
                <Radio value="1" label="Desactiver" />
            </Radio.Group>
            <Button mt={15} type="submit">Modifier</Button>
        </form>
    )
}
