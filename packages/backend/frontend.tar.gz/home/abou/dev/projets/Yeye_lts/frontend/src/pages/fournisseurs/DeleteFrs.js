import { Button } from '@mantine/core'
import { useMutation, useQueryClient } from 'react-query'
import { deleteFournisseur } from '../../services/api'


export default function DeleteFrs({ data, handleClose }) {
    const { mutate } = useMutation(["frs"], deleteFournisseur)
    const query = useQueryClient()

    const handleDelete = () => {
        mutate({ foId: data.fo_id }, {
            onSuccess: () => {
                query.invalidateQueries("frs")
                handleClose()
            }
        })
    }

    return <Button onClick={() => handleDelete()} color="red">Supprimer le fournisseur {data.fo_nom}</Button>
}