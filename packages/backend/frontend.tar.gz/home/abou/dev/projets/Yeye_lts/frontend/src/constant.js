// VITE_ expose this env variable and not access to process just es
const ENDPOINTS = import.meta.env.VITE_MY_API_URL
export const API_URL = ENDPOINTS
export const APP_NAME = "YEYE"
