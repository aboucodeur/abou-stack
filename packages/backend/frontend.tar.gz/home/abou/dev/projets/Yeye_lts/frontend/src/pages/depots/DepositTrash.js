import { Text, Badge, Button, Title } from '@mantine/core'
import { useAppState } from '../../context/AppContext'
import { useQuery, useMutation, useQueryClient } from 'react-query'
import { getShopDepotsTrash, removeDepot } from '../../services/api'
import { AppTable } from '../../components'

export default function DepositTrash() {
    const { getShop } = useAppState()
    const shopId = getShop.bo_id
    const query = useQueryClient()
    const { data = [] } = useQuery(["dep_trash", shopId], ({ queryKey }) => getShopDepotsTrash(queryKey[1]))
    const { mutate } = useMutation(["dep"], removeDepot)

    const handleRestore = (deId, type) => {
        mutate({ deId, type }, {
            onSuccess: () => {
                query.invalidateQueries("dep")
                query.invalidateQueries("dep_trash")
            }
        })
    }

    const tableRows = data.map(d => (
        <tr key={d.de_id}>
            <td><Text>{d.de_nom}</Text></td>
            <td>
                <Button onClick={() => handleRestore(d.de_id, "act")} color="orange">Restaurer</Button>
            </td>
        </tr>
    ))

    return (
        <div>
            <Title order={4}>Recuperer les produits <Badge size="lg" color="orange">Annuler</Badge></Title>
            {data.length === 0
                ? <Text weight="bold">Aucun n'element</Text>
                : <AppTable
                    title="Recuperation des depots annuler"
                    tableHead={["Nom", "Action"]}
                    tableRows={tableRows}
                    style={{ userSelect: "none" }}
                />
            }
        </div>
    )
}