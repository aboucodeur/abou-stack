import { Button, Notification, TextInput } from '@mantine/core'
import useForm from "../../hooks/useForm"
import { addDepots } from '../../services/api'
import { useQueryClient, useMutation } from 'react-query'
import { getError } from '../../utils'

export default function AddDeposit({ boId, handleClose }) {
    const initialValues = { nom: "" }
    const { formValues, formErr, handleChange, cleanForm, setErrors, getInputProps } = useForm(initialValues)
    const queryClient = useQueryClient()
    const { mutate } = useMutation(["dep"], addDepots)
    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ nom: formValues.nom.trim(), bo_id: boId }, {
            onSuccess() {
                queryClient.invalidateQueries("dep")
                queryClient.invalidateQueries("dep_adapt")
                cleanForm()
                handleClose()
            },
            onError(err) {
                const error = getError(err)
                if (error) setErrors("message", error)
            }
        })
    }

    return (
        <div>
            {formErr.message && <Notification m={5} onClose={() => setErrors("message", "")} color="red">{formErr.message}</Notification>}
            <form onSubmit={handleSubmit}>
                <TextInput
                    label="Nom ici"
                    description="200 caracteres maximum"
                    required
                    {...getInputProps("nom")}
                    onChange={handleChange}
                    maxLength={200}
                />
                <Button color="green" type="submit" mt={5} fullWidth variant='outline'>Ajouter</Button>
            </form>
        </div>
    )
}