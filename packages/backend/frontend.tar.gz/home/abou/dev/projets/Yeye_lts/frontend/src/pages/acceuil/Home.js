import { Box, SimpleGrid, Text, Title } from '@mantine/core'
import HomeCard from './HomeCard'
import { useAppState } from "../../context/AppContext"

export default function Home({ shopDash = {} }) {
    const { getShop } = useAppState()
    const shopInfos = getShop
    return (
        <div style={{ display: "flex", flexWrap: "wrap" }}>
            <SimpleGrid cols={5} spacing={0} breakpoints={[{ maxWidth: 580, cols: 2 }, { maxWidth: 380, cols: 1 }]}>
                {shopDash.cart.map((d, idx) => (
                    <HomeCard
                        key={idx}
                        title={d.title}
                        desc={d.desc}
                        total={d.total || 0}
                    />
                ))}
            </SimpleGrid>
            <Box m={5}>
                <Title order={3}>{shopInfos.bo_nom}</Title>
                <Text>{shopInfos.bo_email}</Text>
                <Text>{shopInfos.bo_adr}</Text>
                <Text>{shopInfos.bo_tel}</Text>
            </Box>
        </div>
    )
}