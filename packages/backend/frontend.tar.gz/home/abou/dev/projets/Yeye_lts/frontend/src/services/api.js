import { instance } from "../axios"

export const getShopDepotAdaptSelect = (boId) => boId && instance.get(`/depots/boutique/${boId}/select`).then(res => res.data)
export const getShopDepotsTrash = (boId) => boId && instance.get(`/depots/boutique/${boId}/trash`).then((res) => res.data)
export const getShopDepots = (boId) => boId && instance.get(`/depots/boutique/${boId}`).then((res) => res.data)
export const addDepots = (values) => instance.post(`/depots`, { ...values }).then((res) => res.data)
export const editDepot = (values) => values.deId && instance.put(`/depots/${values.deId}`, { ...values }).then((res) => res.data)
export const removeDepot = (values) => values.deId && instance.delete(`/depots/${values.deId}?type=${values.type || "des"}`).then((res) => res.data)

export const getShopFournisseurAdaptSelect = (boId) => boId && instance.get(`/fournisseurs/boutique/${boId}/select`).then(res => res.data)
export const getShopFournisseur = (boId) => boId && instance.get(`/fournisseurs/boutique/${boId}`).then((res) => res.data)
export const addFournisseur = (values) => instance.post(`/fournisseurs`, { ...values }).then((res) => res.data)
export const editFournisseur = (values) => values.foId && instance.put(`/fournisseurs/${values.foId}`, { ...values }).then((res) => res.data)
export const deleteFournisseur = (values) => values.foId && instance.delete(`/fournisseurs/${values.foId}?type=${values.type || "des"}`).then((res) => res.data)

export const getShopStock = (values) => values.boId && instance.get(`/produits/stock/${values.boId}`).then(res => res.data)
export const getShopProduct = (boId) => boId && instance.get(`/produits/boutique/${boId}`).then(res => res.data)
export const getShopProductAdaptSelect = (boId) => boId && instance.get(`/produits/boutique/${boId}/select`).then(res => res.data)
export const getDepotProduct = (deId) => deId && instance.get(`/produits/depot/${deId}`).then((res) => res.data)

export const addProduct = (values) => instance.post("/produits", values).then((res) => res.data)
export const editProduct = (values) => values.prId && instance.put(`/produits/${values.prId}`, values.formData).then((res) => res.data)
export const removeProduct= (prId) => prId && instance.delete(`/produits/${prId}`).then(res=> res.data)
export const getAchatRuptureProduct = (acId) => acId && instance.get(`/produits/achat/${acId}`).then(res => res.data)
export const getApprRuptureProduct = (appId) => appId && instance.get(`/produits/approvision/${appId}`).then(res => res.data)
export const getBenefice = (boId) => boId && instance.get(`/produits/benefice/${boId}`).then(res => res.data)

export const addGerant = (values) => instance.post("/users_auth/signup", { ...values }).then((res) => res.data)
export const getOneShopUser = (usId) => usId && instance.get(`/users/${usId}`).then((res) => res.data)
export const getShopUser = (boId) => boId && instance.get(`/users/boutique/${boId}`).then((res) => res.data)
export const editGerant = (values) => values.usId && instance.put(`/users/${values.usId}`, { ...values }).then(res => res.data)

export const getAchat = (acId) => acId && instance.get(`/achats/${acId}`).then(res => res.data)
export const getShopAchat = (boId, date) => boId && instance.get(`/achats/boutique/${boId}${date ? `?date=${date}` : ""}`).then(res => res.data)
export const addShopAchat = (values) => instance.post("/achats", { ...values }).then(res => res.data)
export const editShopAchat = (values) => values.acId && instance.put(`/achats/${values.acId}`, { ...values }).then(res => res.data)
export const removeShopAchat = (acId) => acId && instance.delete(`/achats/${acId}`).then(res => res.data)
export const getAchatCommand = (acId) => acId && instance.get(`/achats/commande/${acId}`).then(res => res.data)
export const addAchatCommand = (values) => values.acId && instance.post(`/achats/commande/${values.acId}`, { ...values }).then(res => res.data)
export const editAchatCommand = (values) => values.fcId && instance.put(`/achats/commande/${values.fcId}`, { ...values }).then(res => res.data)
export const removeAchatCommand = (fcId) => fcId && instance.delete(`/achats/commande/${fcId}`).then(res => res.data)
export const getAchatPaiement = (acId) => acId && instance.get(`/achats/paiement/${acId}`).then(res => res.data)
export const addAchatPaiement = (values) => values.acId && instance.post(`/achats/paiement/${values.acId}`, { ...values }).then(res => res.data)
export const editAchatPaiement = (values) => values.apId && instance.put(`/achats/paiement/${values.apId}`, { ...values }).then(res => res.data)
export const removeAchatPaiement = (apId) => apId && instance.delete(`/achats/paiement/${apId}`).then(res => res.data)
export const getAchatReception = (acId) => acId && instance.get(`/achats/reception/${acId}`).then(res => res.data)
export const addAchatReception = (values) => values.acId && instance.post(`/achats/reception/${values.acId}`, { ...values }).then(res => res.data)
export const addAchatReceptionContenu = (reId) => reId && instance.post(`/achats/reception/contenu/${reId}`).then(res => res.data)
export const getAchatReceptionContenu = (reId) => reId && instance.get(`/achats/reception/contenu/${reId}`).then(res => res.data)
export const editAchatReceptionContenu = (values) => instance.put(`/achats/reception/contenu/${values.rcId}`, { ...values }).then(res => res.data)
export const addAchatReceptionFull = (acId) => acId && instance.post(`/achats/reception/contenu/${acId}/full`).then(res => res.data)
export const getAchatRetour = (acId) => instance.get(`/achats/retour/${acId}`).then(res => res.data)
export const addAchatRetour = (values) => instance.post(`/achats/retour/${values.acId}`, { ...values }).then(res => res.data)
export const addAchatRetourContenu = (arId) => arId && instance.post(`/achats/retour/contenu/${arId}`).then(res => res.data)
export const getAchatRetourContenu = (arId) => arId && instance.get(`/achats/retour/contenu/${arId}`).then(res => res.data)
export const editAchatRetourContenu = (values) => values.arcId && instance.put(`/achats/retour/contenu/${values.arcId}`, { ...values }).then(res => res.data)
export const getAchatInfoPaiement = (acId) => acId && instance.get(`/achats/info/${acId}?t=p`).then(res => res.data)
export const getAchatInfoReception = (acId) => acId && instance.get(`/achats/info/${acId}?t=r`).then(res => res.data)

export const getShopVendreTrash = (boId) => instance.get(`/vendres/boutique/${boId}/trash`).then(res => res.data)
export const getVendre = (vendId) => vendId && instance.get(`/vendres/${vendId}`).then(res => res.data)
export const getShopVendre = (boId, date) => boId && instance.get(`/vendres/boutique/${boId}${date ? `?date=${date}` : ""}`).then(res => res.data)
export const addShopVendre = (values) => instance.post("/vendres", { ...values }).then(res => res.data)
export const editShopVendre = (values) => values.vendId && instance.put(`/vendres/${values.vendId}`, { ...values }).then(res => res.data)
export const removeShopVendre = (vendId) => vendId && instance.delete(`/vendres/${vendId}`).then(res => res.data)
export const getVendreCommand = (vendId) => vendId && instance.get(`/vendres/commande/${vendId}`).then(res => res.data)
export const addVendreCommand = (values) => values.vendId && instance.post(`/vendres/commande/${values.vendId}`, { ...values }).then(res => res.data)
export const addVendreCommandWithCode = (values) => instance.post(`/vendres/commande/${values.vendId}/code/${values.code}`).then(res => res.data)
export const editVendreCommand = (values) => values.venId && instance.put(`/vendres/commande/${values.venId}`, { ...values }).then(res => res.data)
export const removeVendreCommand = (venId) => venId && instance.delete(`/vendres/commande/${venId}`).then(res => res.data)
export const getVendrePaiement = (vendId) => vendId && instance.get(`/vendres/paiement/${vendId}`).then(res => res.data)
export const addVendrePaiement = (values) => instance.post(`/vendres/paiement/${values.vendId}`, { ...values }).then(res => res.data)
export const addVendreCpaiement = (values) => instance.post(`/vendres/cpaiement/${values.vendId}`, { ...values }).then(res => res.data)
export const editVendrePaiement = (values) => instance.put(`/vendres/paiement/${values.vpId}`, { ...values }).then(res => res.data)
export const removeVendrePaiement = (vpId) => vpId && instance.delete(`/vendres/paiement/${vpId}`).then(res => res.data)
export const getVendreLivraison = (vendId) => vendId && instance.get(`/vendres/livraison/${vendId}`).then(res => res.data)
export const addVendreLivraison = (values) => values.vendId && instance.post(`/vendres/livraison/${values.vendId}`, { ...values }).then(res => res.data)
export const addVendreLivraisonContenu = (liId) => liId && instance.post(`/vendres/livraison/contenu/${liId}`).then(res => res.data)
export const getVendreLivraisonContenu = (liId) => liId && instance.get(`/vendres/livraison/contenu/${liId}`).then(res => res.data)
export const editVendreLivraisonContenu = (values) => instance.put(`/vendres/livraison/contenu/${values.lcId}`, { ...values }).then(res => res.data)
export const addVendreLivraisonFull = (vendId) => vendId && instance.post(`/vendres/livraison/contenu/${vendId}/full`).then(res => res.data)
export const getVendreInfoLivraison = (vendId) => vendId && instance.get(`/vendres/info/${vendId}?t=l`).then(res => res.data)
export const getVendreInfoPaiement = (vendId) => vendId && instance.get(`/vendres/info/${vendId}?t=p`).then(res => res.data)
export const getVendreRetour = (vendId) => instance.get(`/vendres/retour/${vendId}`).then(res => res.data)
export const addVendreRetour = (values) => instance.post(`/vendres/retour/${values.vendId}`, { ...values }).then(res => res.data)
export const addVendreRetourContenu = (vrId) => instance.post(`/vendres/retour/contenu/${vrId}`).then(res => res.data)
export const getVendreRetourContenu = (vrId) => vrId && instance.get(`/vendres/retour/contenu/${vrId}`).then(res => res.data)
export const editVendreRetourContenu = (values) => instance.put(`/vendres/retour/contenu/${values.vrcId}`, { ...values }).then(res => res.data)

export const getBoutiqueApprovision = (boId, date) => boId && instance.get(`/approvisions/boutique/${boId}${date ? `?date=${date}` : ""}`).then(res => res.data)
export const addShopApprovision = (values) => instance.post("/approvisions", { ...values }).then(res => res.data)
export const getApprovision = (apId) => apId && instance.get(`/approvisions/${apId}`).then(res => res.data)
export const removeApprovision = (apId) => apId && instance.delete(`/approvisions/${apId}`).then(res => res.data)
export const editApprovision = (values) => values.apId && instance.put(`/approvisions/${values.apId}`, { ...values }).then(res => res.data)
export const getApprovisionCommand = (apId) => apId && instance.get(`/approvisions/commande/${apId}`).then(res => res.data)
export const addApprovisionCommand = (values) => values.apId && instance.post(`/approvisions/commande/${values.apId}`, { ...values }).then(res => res.data)
export const editApprovisionCommand = (values) => values.apcId && instance.put(`/approvisions/commande/${values.apcId}`, { ...values }).then(res => res.data)
export const removeApprovisionCommand = (apcId) => apcId && instance.delete(`/approvisions/commande/${apcId}`).then(res => res.data)
export const addApprovisionFull = (apId) => apId && instance.post(`/approvisions/full/${apId}`).then(res => res.data)

export const getShopClientAdaptSelect = (boId) => instance.get(`/clients/boutique/${boId}/select`).then(res => res.data)
export const getShopClient = (boId) => boId && instance.get(`/clients/boutique/${boId}`).then(res => res.data)
export const addShopClient = (values) => instance.post(`/clients`, { ...values }).then(res => res.data)
export const editShopClient = (values) => values.clId && instance.put(`/clients/${values.clId}`, { ...values }).then(res => res.data)
export const removeShopClient = (values) => values.clId && instance.delete(`/clients/${values.clId}?type=${values.type || "des"}`).then(res => res.data)

export const getShopDepense = (boId) => boId && instance.get(`/depenses/boutique/${boId}`).then(res => res.data)
export const addShopDepense = (values) => instance.post("/depenses", { ...values }).then(res => res.data)
export const editShopDepense = (values) => values.depId && instance.put(`/depenses/${values.depId}`, { ...values }).then(res => res.data)
export const removeShopDepense = (depId) => depId && instance.delete(`/depenses/${depId}`).then(res => res.data)

export const getBoutique = (boId) => boId && instance.get(`/boutiques/${boId}`).then(res => res.data)
export const editBoutique = (values) => values.boId && instance.put(`/boutiques/${values.boId}`, { ...values }).then(res => res.data)
export const getBoutiqueDash = (boId) => boId && instance.get(`/boutiques/dash/${boId}`).then(res => res.data)
export const getBoutiqueStat = (boId) => boId && instance.get(`/boutiques/stat/${boId}`).then(res => res.data)
export const getBoutiqueToday = (boId) => boId && instance.get(`/boutiques/day/${boId} `).then(res => res.data)

export const createUserAccount = (values) => instance.post(`/admins/user/add`, { ...values }).then(res => res.data)
export const getAllUser = () => instance.get(`/admins/user/list`).then(res => res.data)
export const getAllShopUser = (boId) => boId && instance.get(`/admins/user/boutique/${boId}`).then(res => res.data)
export const editUserAccountState = (values) => values.boId && instance.put(`/admins/user/state/${values.boId}?type=${values.type || "des"} `).then(res => res.data)
export const deleteUserAccount = (userId) => userId && instance.delete(`/admins/user/${userId} `).then(res => res.data)
export const resetUserAccountPass = (usId) => usId && instance.put(`/admins/user/resetpass/${usId}`).then(res => res.data)
export const editUserInfo = (values) => values.usId && instance.put(`/admins/user/edit/${values.usId}`, { ...values }).then(res => res.data)
export const editUserShopInfo = (values) => values.boId && instance.put(`/admins/user/edit/boutique/${values.boId}`, { ...values }).then(res => res.data)
export const importFileToDB = (values) => instance.post("/importations/excel", values).then(res => res.data)

export const getShopLicence = (boId) => boId && instance.get(`/admins/user/licence/${boId}`).then(res => res.data)
export const addShopLicence = (values) => instance.post(`/admins/user/licence`, { ...values }).then(res => res.data)
export const removeShopLicence = (licId) => licId && instance.delete(`/admins/user/licence/${licId}`).then(res => res.data)
export const addCcompte = (values) => instance.post("/ccomptes", { ...values }).then(res => res.data)
export const getClientCcompte = (clId) => clId && instance.get(`/ccomptes/client/${clId}`).then(res => res.data)
export const editCcompte = (values) => values.ccId && instance.put(`/ccomptes/${values.ccId}`, { ...values }).then(res => res.data)
export const removeCcompte = (ccId) => ccId && instance.delete(`/ccomptes/${ccId}`).then(res => res.data)

// Nouvelle fonctionnalite pour la gestion des actionnaires , banques et caisse

//TODO : Gestion des investisseurs
export const getAllInvestisseurs = async (boId) => boId && instance.get(`/investisseurs/all/${boId}`).then(res => res.data)
export const getAdaptInvestisseur = async (boId) => boId && instance.get(`/investisseurs/select/${boId}`).then(res => res.data);
export const addInvestisseur = async (values) => instance.post('/investisseurs/', { ...values }).then(res => res.data)
export const updateInvestisseur = async (values) => values.invId && instance.put(`/investisseurs/${values.invId}`, { ...values }).then(res => res.data)
export const deleteInvestisseur = async (invId) => invId && instance.delete(`/investisseurs/${invId}`).then(res => res.data)

//TODO : Gestion du banques
export const depotBanque = async (values) => await instance.post('/banques/depot', { ...values }).then(res => res.data)
export const retraitBanque = async (values) => await instance.post('/banques/retrait', { ...values }).then(res => res.data)
export const payeApaiement = async (values) => await instance.post('/banques/pachat', { ...values }).then(res => res.data)
export const annulerBanque = async (tId) => tId && await instance.put(`/banques/annulation/${tId}`).then(res => res.data)

export const compteDetail = async (coId, d1, d2, type) => {
    //comme le http_build_query de php pour construire l'url complet
    const queryParams = new URLSearchParams({ d1: d1, d2: d2, tra_type: type })
    const url = `/compte/${coId}?${queryParams.toString()}`
    return await instance.get(`/banques${url}`).then(res => res.data)
}

export const caisseDetail = async (boId, d1, d2) => {
    const queryParams = new URLSearchParams({ d1: d1, d2: d2 })
    const url = `/caisse/${boId}?${queryParams.toString()}`
    return await instance.get(`/banques${url}`).then(res => res.data)
}

export const getBoutiqueGlobal = async (boId, pick) => {
    const queryParams = new URLSearchParams({ pick: pick })
    const url = `/global/${boId}?${queryParams.toString()}`
    return await instance.get(`/boutiques${url}`).then(res => res.data)
}