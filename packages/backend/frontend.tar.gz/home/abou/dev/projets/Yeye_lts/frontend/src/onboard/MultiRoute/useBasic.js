import { useCallback } from 'react'
import { useMultipleOnboardContext } from '../index'
import { useLocalStorage } from '@mantine/hooks'

export default function useBasic() {
    const { setState } = useMultipleOnboardContext()

    const [userAgree] = useLocalStorage({ key: 'yy_start_tour' })

    // TODO : Appris les adapteurs ici funcA (adapterValue) => funcB()
    const createStepFunction = useCallback(
        (stepModifier) =>
            (goIndex = 0, isRun = true, payload_opts = {}) => {
                if (userAgree !== 'n') {
                    setState({ run: isRun, stepIndex: goIndex + stepModifier, ...payload_opts })
                }
            },
        [setState, userAgree],
    )

    const nextStep = createStepFunction(1)
    const prevStep = createStepFunction(-1)
    const stayStep = createStepFunction(0)

    return {
        nextStep,
        prevStep,
        stayStep,
    }
}
