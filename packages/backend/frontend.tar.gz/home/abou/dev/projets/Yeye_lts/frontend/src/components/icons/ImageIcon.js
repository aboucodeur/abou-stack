import { Image } from "@mantine/core"

export default function ImageIcon({ src, alt, width }) {
    return <Image src={src} alt={alt} width={width || 25} height={25} />
}