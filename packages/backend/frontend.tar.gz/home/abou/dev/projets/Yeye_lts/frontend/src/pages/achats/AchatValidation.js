import { Button } from '@mantine/core'
import { useMutation, useQueryClient } from 'react-query'
import { editShopAchat } from '../../services/api'

export default function AchatValidation({ acId, handleClose, etat = '', handleBlock, setState }) {
    const query = useQueryClient()
    const { mutate } = useMutation(['achats'], editShopAchat)

    const handleConfirm = (id) => {
        mutate(
            { etat: etat || '1', acId: id },
            {
                onSuccess() {
                    query.invalidateQueries('achats_info')
                    handleBlock()
                    handleClose()
                    setState({ run: true, stepIndex: 18 })
                },
            },
        )
    }

    return (
        <Button id="button_add_achat_validconfirm_17" mt={5} onClick={() => handleConfirm(acId)}>
            Oui, valider
        </Button>
    )
}
