import { useEffect, useState } from 'react'
import { Anchor, Button, Card, Grid, Group, List, NumberInput, Text } from '@mantine/core'
import AppTable from '../../components/table/AppTable'
import { modals } from '@mantine/modals'
import {
    addAchatReception,
    addAchatReceptionContenu,
    addAchatReceptionFull,
    editAchatReceptionContenu,
    getAchatReception,
    getAchatReceptionContenu,
} from '../../services/api'
import { useMutation, useQuery, useQueryClient } from 'react-query'
import { getError } from '../../utils'
import useForm from '../../hooks/useForm'
import { IconCheck, IconInfoCircle, IconPencil, IconPrinter } from '@tabler/icons-react'
import { API_URL } from '../../constant'
import useOnboardModal from '../../onboard/MultiRoute/useOnboardModal'

export default function AchatReception({ acId, achatInfo }) {
    const [viewTable, setViewTable] = useState({
        isView: false,
        data: {},
        isEdit: false,
        editData: {},
    })
    const [rowsId, setRowsId] = useState(null)
    const { formValues, setValues, cleanForm } = useForm({ qte: 0 })
    const query = useQueryClient()

    const { data: achatReception = [] } = useQuery(['achats_recd', acId], ({ queryKey }) =>
        getAchatReception(queryKey[1]),
    )
    const { data: achatReceptionContenu = [] } = useQuery(
        ['achats_recc', viewTable.data.re_id],
        ({ queryKey }) => getAchatReceptionContenu(queryKey[1]),
    )
    const { mutate: addReception } = useMutation(['achats_recd'], addAchatReception)
    const { mutate: addReceptionContenu } = useMutation(['achats_recc'], addAchatReceptionContenu)
    const { mutate: addReceptionFull } = useMutation(['achats_recf'], addAchatReceptionFull)
    const { mutate } = useMutation(['achats_recc'], editAchatReceptionContenu)

    const { setState, blockOnboard } = useOnboardModal()

    const handleClick = (id) => {
        addReception(
            { date: new Date().toISOString(), acId: id },
            {
                onSuccess() {
                    query.invalidateQueries('achats_recd')
                    // ** force user to click
                    setState({ run: true, stepIndex: 21 })
                },
                onError(err) {
                    const error = getError(err)
                    if (error) {
                        modals.open({
                            title: 'Notification',
                            centered: true,
                            children: error,
                            color: 'red',
                        })
                    }
                },
            },
        )
    }

    const handlePlaceContent = (id) => {
        if (viewTable.isView) {
            // ** force user to click
            setState({ run: true, stepIndex: 22 })
            return
        }
        addReceptionContenu(id, {
            onSuccess() {
                query.invalidateQueries('achats_recc')
                // ** force user to click
                setState({ run: true, stepIndex: 22 })
            },
        })
    }

    const handleFullReception = (id) => {
        addReceptionFull(id, {
            onSuccess: () => {
                query.invalidateQueries('achats_recc')
                query.invalidateQueries('achats_info')
                query.invalidateQueries('achats_cmd')
                setRowsId(null)
                cleanForm()
                // ** force user to click
                setState({ run: true, stepIndex: 23 })
            },
            onError: (err) => {
                const error = getError(err)
                if (error)
                    modals.open({
                        title: 'Notifications',

                        children: <Text>{error}</Text>,
                    })
            },
        })
    }

    const handleEdit = (id) => {
        mutate(
            { ...formValues, rcId: id },
            {
                onSuccess() {
                    query.invalidateQueries('achats_recc')
                    query.invalidateQueries('achats_info')
                    query.invalidateQueries('achats_cmd')
                    setRowsId(null)
                    cleanForm()
                },
                onError(err) {
                    const error = getError(err)
                    if (error) setRowsId(null)
                },
            },
        )
    }

    const tableRows = achatReceptionContenu.map((d) => (
        <tr key={d.rc_id}>
            <td>{d.pr_nom}</td>
            <td>
                {d.rc_id === rowsId ? (
                    <NumberInput
                        autoComplete="off"
                        autoCorrect="off"
                        max={d.reste_reel}
                        value={formValues.qte}
                        onChange={(value) => setValues('qte', value)}
                        min={0}
                    />
                ) : (
                    <Text>{d.rc_qte}</Text>
                )}
            </td>
            <td>{<Text color="red">{d.reste_reel}</Text>}</td>
            <td>
                {d.rc_id === rowsId ? (
                    <Button
                        onClick={() => handleEdit(d.rc_id)}
                        color="green"
                        children={<IconCheck size={21} />}
                    />
                ) : (
                    <Button
                        disabled={parseInt(d.reste_reel, 10) === 0}
                        onClick={() => {
                            setRowsId(d.rc_id)
                            setValues('qte', parseInt(d.rc_qte, 10))
                        }}
                        children={<IconPencil size={21} />}
                    />
                )}
            </td>
        </tr>
    ))

    useEffect(() => {
        blockOnboard(21)
    }, [blockOnboard])

    return (
        <Grid columns={30}>
            <Grid.Col md={6}>
                <Card
                    direction="column"
                    shadow="lg"
                    sx={(theme) => ({
                        backgroundColor: theme.colors.blue[2],
                        color: 'white',
                        width: '100%',
                    })}
                >
                    {achatInfo.ac_etat >= 0 && achatInfo.ac_etat < 3 ? (
                        <Button
                            id="button_add_achat_reception_20"
                            variant="white"
                            onClick={() => handleClick(acId)}
                        >
                            +
                        </Button>
                    ) : null}
                    <Text weight="bold" mt={5} order={4}>
                        Dates
                    </Text>
                    <List listStyleType="none">
                        {achatReception.map((d, _idx) => (
                            <List.Item key={d.re_id}>
                                <Anchor
                                    onClick={() => {
                                        setViewTable((prevData) => ({
                                            ...prevData,
                                            isView: true,
                                            data: { ...d },
                                        }))
                                        handlePlaceContent(d.re_id)
                                    }}
                                    // get first element and point when onboarding
                                    {...(_idx === 0 ? { id: 'anchor_add_achat_reception_21' } : {})}
                                >
                                    {new Date(d.re_date).toLocaleDateString()}
                                </Anchor>
                            </List.Item>
                        ))}
                    </List>
                </Card>
            </Grid.Col>
            <Grid.Col md={24}>
                {viewTable.isView ? (
                    <div>
                        <Group spacing={5}>
                            {achatInfo.ac_etat > 0 && !achatInfo.is_rec ? (
                                <Button
                                    id="button_add_achat_receptionfull_22"
                                    onClick={() => handleFullReception(viewTable.data.re_id)}
                                >
                                    Tout Receptionner
                                </Button>
                            ) : (
                                <Group spacing={3}>
                                    <IconInfoCircle />
                                    <Text>Reception complete de l'achat effectuer</Text>
                                </Group>
                            )}
                            {viewTable.data.re_id && achatInfo.ac_etat > 0 ? (
                                <Button
                                    variant="white"
                                    component={Anchor}
                                    href={`${API_URL}/documents/achat/bord/${viewTable.data.re_id}`}
                                    target="_blank"
                                    // fullWidth
                                    color="orange"
                                >
                                    <IconPrinter /> Bordereau
                                </Button>
                            ) : null}
                        </Group>
                        <AppTable
                            title={`Reception du ${new Date(
                                viewTable.data.re_date,
                            ).toLocaleDateString()}`}
                            tableHead={['Designation', 'Receptionner', 'Reste', 'Action']}
                            tableRows={tableRows}
                        />
                    </div>
                ) : null}
            </Grid.Col>
        </Grid>
    )
}
