import { useState } from 'react'
import { Group, NumberInput, Text, TextInput, Button } from '@mantine/core'
import { toLower } from '../../utils'
import AddForm from './AddForm'
import useForm from '../../hooks/useForm'
import { useMutation, useQueryClient } from 'react-query'
import { editAchatCommand, removeAchatCommand } from '../../services/api'
import { IconCheck, IconEdit, IconSearch, IconTrash } from '@tabler/icons-react'
import useSearch from '../../hooks/useSearch'
import { AppTable } from '../../components'
import { formatNumber } from '../../helper'

export default function AchatContenu({ achatCommand, acId, achatInfo }) {
    const { formValues, setValues, cleanForm } = useForm({ qte: undefined, prix: undefined })
    const [rowsId, setRowsId] = useState(null)
    const query = useQueryClient()
    const { mutate } = useMutation(['achats_cmd'], editAchatCommand)
    const { mutate: remCmd } = useMutation(['achats_cmd'], removeAchatCommand)
    const { searchVal, getSearchProps, handleSearch } = useSearch({ nom: '' })

    const handleEdit = (id) => {
        mutate(
            { ...formValues, fcId: id },
            {
                onSuccess() {
                    query.invalidateQueries('achats_cmd')
                    query.invalidateQueries('achats_info')
                    setRowsId(null)
                    cleanForm()
                },
            },
        )
    }
    const handleRemove = (id) => {
        remCmd(id, {
            onSuccess() {
                query.invalidateQueries('achats_cmd')
                query.invalidateQueries('achats_prod')
                query.invalidateQueries('achats_info')
                setRowsId(null)
            },
        })
    }
    const searchFilter = (data) => {
        const { fc_nom } = data
        if (!searchVal.nom) return data
        if (toLower(fc_nom).includes(toLower(searchVal.nom.trim()))) return data
    }

    const tableRows = achatCommand.filter(searchFilter).map((d, _idx) => (
        <tr key={d.fc_id}>
            <td>
                <Text>{_idx + 1}</Text>
            </td>
            <td>
                <Text>{d.fc_nom}</Text>
            </td>
            <td>
                {d.fc_id === rowsId ? (
                    <NumberInput
                        placeholder="Donner la quantité"
                        autoComplete="off"
                        autoCorrect="off"
                        defaultValue={d.fc_qte}
                        onChange={(value) => setValues('qte', value)}
                        maxLength={20}
                        min={1}
                    />
                ) : (
                    <Text>{formatNumber(d.fc_qte)}</Text>
                )}
            </td>
            <td>
                {d.fc_id === rowsId ? (
                    <NumberInput
                        placeholder="Donner le prix"
                        autoComplete="off"
                        autoCorrect="off"
                        defaultValue={d.fc_prix}
                        onChange={(value) => setValues('prix', value)}
                        maxLength={20}
                        precision={2}
                    />
                ) : (
                    <Text>{formatNumber(d.fc_prix)}</Text>
                )}
            </td>
            <td>
                <Text>{formatNumber(d.fc_prix * d.fc_qte)}</Text>
            </td>
            <td>
                <Group direction="row" spacing={5}>
                    {d.fc_id === rowsId ? (
                        <Button
                            color="green"
                            onClick={() => handleEdit(d.fc_id)}
                            type="submit"
                            children={<IconCheck />}
                        />
                    ) : (
                        <Button
                            color="gray"
                            disabled={achatInfo.ac_etat !== 0}
                            onClick={() => {
                                setRowsId(d.fc_id)
                                setValues('qte', d.fc_qte)
                                setValues('prix', d.fc_prix)
                            }}
                            children={<IconEdit />}
                        />
                    )}
                    <Button
                        color="red"
                        disabled={achatInfo.ac_etat !== 0}
                        onClick={() => handleRemove(d.fc_id)}
                        children={<IconTrash />}
                    />
                </Group>
            </td>
        </tr>
    ))

    return (
        <div>
            {achatInfo.ac_etat === 0 ? <AddForm acId={acId} /> : null}
            <TextInput
                icon={<IconSearch />}
                autoComplete="off"
                autoCorrect="off"
                placeholder="Recherche"
                mt={5}
                {...getSearchProps('nom')}
                onChange={handleSearch}
            />
            <AppTable
                id="page_add_achat_product_15"
                tableHead={['N°', 'Produit', 'Quantite', 'Prix', 'Montant', 'Action']}
                tableRows={tableRows}
            />
        </div>
    )
}
