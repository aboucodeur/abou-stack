import React from 'react'
import { Button, Group, Notification, NumberInput, TextInput, Tooltip } from '@mantine/core'
import useForm from '../../hooks/useForm'
import { addVendreCpaiement, addVendrePaiement } from '../../services/api'
import { useMutation, useQueryClient } from 'react-query'
import { getError } from '../../utils'

export default function AddPaiementForm({ vendId, rest }) {
    const { formValues, setValues, handleChange, setErrors, formErr, cleanForm, getInputProps } = useForm({
        motif: new Date().toLocaleString().split(" ").join(" à "),
        mte: 0
    })
    const query = useQueryClient()
    const { mutate } = useMutation(["vendres_pay"], addVendrePaiement)
    const { mutate: addCpaiement } = useMutation(["vendres_pay"], addVendreCpaiement)

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ ...formValues, vendId }, {
            onSuccess() {
                query.invalidateQueries("vendres_info")
                query.invalidateQueries("vendres_pay")
                cleanForm()
            },
            onError(err) {
                const error = getError(err)
                if (error) setErrors("message", error)
            }
        })
    }
    const handleCpaiement = () => {
        addCpaiement({ ...formValues, vendId }, {
            onSuccess() {
                query.invalidateQueries("vendres_info")
                query.invalidateQueries("vendres_pay")
                query.invalidateQueries("clt_comp")
                cleanForm()
            },
            onError(err) {
                const error = getError(err)
                if (error) setErrors("message", error)
            }
        })
    }

    React.useEffect(() => setValues("mte", rest), [rest, setValues])
    return (
        <div>
            {formErr.message && <Notification color="red" onClose={() => setErrors("message", "")} m={5}>{formErr.message}</Notification>}
            <form onSubmit={handleSubmit}>
                <Group spacing={3}>
                    <TextInput
                        placeholder="Ex : Tranche 1"
                        autoComplete="off"
                        autoCorrect="off"
                        {...getInputProps("motif")}
                        onChange={handleChange}
                        required
                    />
                    <NumberInput
                        placeholder="Somme à payer"
                        autoComplete="off"
                        autoCorrect="off"
                        max={rest}
                        min={1}
                        maxLength={20}
                        value={formValues.mte}
                        onChange={value => setValues("mte", value)}
                        required
                        precision={2}
                    />
                    <Group spacing={3}>
                        <Button type="submit" disabled={rest <= 0 && true}>Payer</Button>
                        <Tooltip withArrow label="Payer a partir du compte du client">
                            <Button
                                onClick={() => handleCpaiement(vendId)}
                                variant="outline"
                                color="orange"
                                type="button"
                                disabled={rest <= 0 && true}>
                                Payer avec le compte
                            </Button>
                        </Tooltip>
                    </Group>
                </Group>
            </form>
        </div>
    )
}