import { useAppState } from "../context/AppContext"
import { Navigate, useLocation } from "react-router-dom"

export default function PrivateRoutes({ children, roles = [] }) {
    const { getAuth, getUser } = useAppState()
    const location = useLocation()
    const currentRole = getUser.us_role
    const hasNotConnected = !getAuth

    const hasNoRoles = Array.isArray(roles) && currentRole && !roles.includes(currentRole)
    const locationState = { from: location }

    if (hasNotConnected && roles.includes("admin"))
        return <Navigate to="/admin" replace={true} state={locationState} />
    if (hasNotConnected) return <Navigate to="/" replace={true} state={locationState} />
    if (hasNoRoles) return <div>Unauthorised to access !</div>

    return children
}
