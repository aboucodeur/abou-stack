const toLower = (str = "") => str && str.toUpperCase()
const getError = (err = "") => err && err?.response?.data?.message
const pgDate = (date) => (!date ? null : date.toISOString().split("T")[0])

const redirectUser = (savedUrl = "", userRole = "") => {
    if (userRole === "admin" || userRole === "prop") return savedUrl || "/acceuil"
    if (userRole === "ger") return savedUrl || "/ventes"
}

const generateColor = (len = 0) => {
    let out = []
    for (let i = 0; i <= len; i++) {
        const color = `
        rgba(${Math.floor(Math.random() * 256)},${Math.floor(Math.random() * 256)},${Math.floor(
            Math.random() * 256,
        )},${Math.random(Math.random()) / 1})`
        if (out[i] && out[i].includes(color)) return null
        out.push(color)
    }
    return out
}

export { toLower, getError, pgDate, redirectUser, generateColor }
