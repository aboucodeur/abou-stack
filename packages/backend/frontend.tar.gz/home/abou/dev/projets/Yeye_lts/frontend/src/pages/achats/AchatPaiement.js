import { Button, Group, NumberInput, TextInput } from '@mantine/core'
import { useMutation, useQueryClient } from 'react-query'
import useForm from '../../hooks/useForm'
import { editAchatPaiement, removeAchatPaiement } from '../../services/api'
import { getError } from '../../utils'
import AddPaiementForm from './AddPaiementForm'
import { IconCheck, IconPencil, IconTrash } from '@tabler/icons-react'
import { AppTable } from '../../components'
import { formatNumber, formatWari } from '../../helper'
import { useState } from 'react'

export default function AchatPaiement({ acId, rest, achatPaiement, achatInfo, getPaySum }) {
    const query = useQueryClient()
    const [rowsId, setRowsId] = useState(null)
    const { formValues, handleChange, setValues, cleanForm } = useForm({ motif: '', mte: "" })
    const { mutate } = useMutation(["achats_pay"], editAchatPaiement)
    const { mutate: remPay } = useMutation(["achats_pay"], removeAchatPaiement)

    const handleEdit = (id) => {
        mutate({ ...formValues, apId: id }, {
            onSuccess() {
                query.invalidateQueries("achats_pay")
                query.invalidateQueries("achats_info")
                cleanForm()
                setRowsId(null)
            },
            onError(err) {
                const error = getError(err)
                if (error) setRowsId(null)
            }
        })
    }
    const handleRemove = (id) => {
        remPay(id, {
            onSuccess() { query.invalidateQueries("achats_pay") }
        })
    }

    const tableRows = achatPaiement.map(d => (
        <tr key={d.ap_id}>
            <td>{new Date(d.createdAt).toLocaleString()}</td>
            <td>
                {d.ap_id === rowsId ?
                    <TextInput
                        autoComplete="off"
                        autoCorrect="off"
                        name="motif"
                        value={formValues.motif}
                        onChange={handleChange}
                    /> :
                    d.inv_nom
                        ? d.ap_motif + ' compte ' + d.inv_nom :
                        d.ap_motif
                }
            </td>
            <td>{
                d.ap_id === rowsId ?
                    <NumberInput
                        autoComplete="off"
                        autoCorrect="off"
                        max={rest}
                        min={0}
                        maxLength={20}
                        defaultValue={formValues.mte}
                        onChange={value => setValues("mte", value)}
                        placeholder="Donner le prix si necessaire"
                    /> :
                    formatNumber(d.ap_mte)
            }
            </td>
            <td>
                {d.tra_id
                    ? "Payer bar banque"
                    : <Group spacing={3}>
                        {d.ap_id === rowsId ?
                            <Button
                                onClick={() => handleEdit(d.ap_id)}
                                color="green"
                                children={<IconCheck size={21} />}
                            />
                            : <Button
                                onClick={() => {
                                    setRowsId(d.ap_id)
                                    setValues("motif", d.ap_motif)
                                }}
                                children={<IconPencil size={21} />}
                            />}

                        <Button
                            color="red"
                            onClick={() => handleRemove(d.ap_id)}
                            children={<IconTrash size={21} />}
                        />
                    </Group>
                }
            </td>
        </tr>
    ))

    return (
        <div>
            {(achatInfo.ac_etat > 0) ? <AddPaiementForm rest={rest} acId={acId} /> : null}
            <AppTable
                title={`Paiements avec une somme de ${formatWari(getPaySum)}`}
                tableHead={["Date", "Motif", "Montant", "Action"]}
                tableRows={tableRows}
            />
        </div>
    )
}