import React from 'react'
import { Button, Notification, Textarea, TextInput, Title } from '@mantine/core'
import useForm from '../../hooks/useForm'
import { useMutation, useQueryClient } from "react-query"
import { editShopClient } from '../../services/api'
import { getError } from '../../utils'

export default function EditClient({ data, handleClose }) {
    const { formValues, formErr, handleChange, setErrors, setValues, cleanForm, setFormErr } = useForm({ nom: "", tel: "", adr: "" })
    const query = useQueryClient()
    const { mutate } = useMutation(["clt"], editShopClient)

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({
            ...formValues,
            nom: formValues.nom.trim(),
            clId: data.cl_id
        }, {
            onSuccess: () => {
                query.invalidateQueries("clt")
                cleanForm()
                setFormErr({})
                handleClose()
            },
            onError: (err) => {
                const error = getError(err)
                if (error) setErrors("message", error)
            }
        })
    }

    React.useEffect(() => {
        setValues("nom", data.cl_nom)
        setValues("tel", data.cl_tel)
        setValues("adr", data.cl_adr)
    }, [data, setValues])

    return (
        <div>
            {formErr.message && <Notification m={5} title={<Title order={3} color="red">Erreur</Title>}>{formErr.message}</Notification>}
            <form onSubmit={handleSubmit}>
                <TextInput
                    label="Modification du nom"
                    autoComplete="off"
                    autoCorrect="off"
                    placeholder="Nouveau nom"
                    name="nom"
                    value={formValues.nom}
                    onChange={handleChange}
                />
                <TextInput
                    label="Modification du telephone"
                    type="tel"
                    autoComplete="off"
                    autoCorrect="off"
                    value={formValues.tel}
                    name="tel"
                    placeholder="Nouveau numero"
                    onChange={handleChange}
                />
                <Textarea
                    spellCheck={false}
                    label="Modification adresse"
                    autoComplete="off"
                    autoCorrect="off"
                    name="adr"
                    value={formValues.adr}
                    onChange={handleChange}
                />
                <Button mt={5} type="submit">Modifier</Button>
            </form>
        </div>
    )
}