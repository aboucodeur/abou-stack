import React from 'react'
import { Anchor, Button, Group, Loader, Paper, Select, Text, Tooltip, UnstyledButton } from '@mantine/core'
import { DatePickerInput } from "@mantine/dates"
import useSearch from '../../hooks/useSearch'
import AppTable from '../../components/table/AppTable'
import { useNavigate, useParams, useSearchParams } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from 'react-query'
import { annulerBanque, compteDetail } from '../../services/api'
import { getError, pgDate } from '../../utils'
import { modals } from '@mantine/modals'
import ADepots from './ADepots'
import { IconArrowDown, IconArrowUp, IconReload } from '@tabler/icons-react'
import ASorties from './ASorties'
import { formatNumber } from '../../helper'

export default function Details() {
    const { coId } = useParams()
    const navigate = useNavigate()
    const [GET] = useSearchParams()
    const nom = GET.get("nom")
    const { searchVal, getSearchProps, setSearch } = useSearch({ d1: null, d2: null, tra_type: "0" })
    const { d1, d2, tra_type } = searchVal

    const { data = [], isLoading } = useQuery(
        ["act_detail", pgDate(d1) || '', pgDate(d2) || '', tra_type],
        ({ queryKey }) => compteDetail(coId, queryKey[1], queryKey[2], queryKey[3])
    )
    const query = useQueryClient()
    const { mutate } = useMutation(["act_detail"], annulerBanque)

    // ** FEATURES
    const addModal = (coId) => {
        modals.open({
            title: "Operation de depot",
            children: <ADepots coId={coId} closeModal={() => modals.closeAll()} />,
        })
    }
    const editModal = (coId) => {
        modals.open({
            title: "Operation de retrait",
            children: <ASorties coId={coId} closeModal={() => modals.closeAll()} />,
        })
    }
    const handleDelete = (traId) => {
        mutate(traId, {
            onSuccess() {
                query.invalidateQueries("act_detail")
            },
            onError: (err) => {
                const error = getError(err)
                if (error) alert(error)
            }
        })
    }

    const rows = data.map((d, _idx) => (
        <tr key={d.tra_id}>
            <td><Text>{(_idx + 1)}</Text></td>
            <td><Text>{formatNumber(d.tra_mte)}</Text></td>
            <td><Text>{d.tra_type === 'd' ? 'Depots' : d.tra_type === 'r' ? 'Retraits' : 'Remboursements'}</Text></td>
            <td><Text>{new Date(d.date_tra).toLocaleString()}</Text></td>
            <td>
                <Group>
                    {d.ac_id ? <Anchor target='_blank' href={`/commandes/fournisseurs/${d.ac_id}`}>Voir l'achat</Anchor> : null}
                    <Tooltip label="Annulation" withArrow>
                        <UnstyledButton onClick={() => handleDelete(d.tra_id)}>
                            <IconReload color="red" />
                        </UnstyledButton>
                    </Tooltip>
                </Group>
            </td>
        </tr>

    ))

    // ** DATA COHERENCE
    React.useEffect(() => {
        if (GET.toString()) return
        navigate("/action")
    }, [GET, navigate])

    if (isLoading) return (
        <div>
            <Text>Chargement en cours ...</Text>
            <Loader />
        </div>
    )
    return (
        <div>
            <Paper shadow='lg' p='md'>
                <Text weight="bold">Proprietaire du compte : {nom}</Text>
                <Group spacing={3}>
                    <Button leftIcon={<IconArrowDown />} mt={5} onClick={() => addModal(coId)}>Faire depot</Button>
                    <Button color="orange" leftIcon={<IconArrowUp />} mt={5} onClick={() => editModal(coId)}>Retrait et Remboursement</Button>
                </Group>
                <Group spacing={3} mt={5}>
                    <DatePickerInput
                        label="Date de debut"
                        placeholder='Date debut ici'
                        locale='fr'

                        {...getSearchProps("d1")}
                        onChange={(value) => setSearch('d1', value)}
                        clearable
                    />
                    <DatePickerInput
                        label="Date de fin"

                        placeholder='Date fin ici'
                        locale='fr'
                        {...getSearchProps("d2")}
                        onChange={(value) => setSearch('d2', value)}
                        clearable
                    />
                    <Select
                        label="Type de transaction"
                        defaultValue="0"
                        data={[
                            { value: '0', label: "Tous les types" },
                            { value: 'd', label: "Depots" },
                            { value: 'r', label: "Paiement achats" },
                            { value: 'e', label: "Remboursements" },
                        ]}
                        value={searchVal.tra_type}
                        onChange={(value) => setSearch("tra_type", value ? value : '0')}
                    />
                </Group>
            </Paper>
            {/* DONNEES */}
            <AppTable
                tableHead={["No", "Montant", "Type", "Date", "Action"]}
                tableRows={rows}
            />
        </div>
    )
}