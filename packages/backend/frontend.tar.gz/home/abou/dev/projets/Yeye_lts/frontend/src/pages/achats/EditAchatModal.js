import { useEffect } from 'react'
import { Button, Notification, Textarea, TextInput } from '@mantine/core'
import useForm from '../../hooks/useForm'
import { editShopAchat } from '../../services/api'
import { useMutation, useQueryClient } from "react-query"
import { getError } from '../../utils'

export default function EditAchatModal({ datas, handleClose }) {
    const { formValues, formErr, handleChange, setErrors, setValues, cleanForm } = useForm({ date: "", desc: "" })
    const query = useQueryClient()
    const { mutate } = useMutation(["achats"], editShopAchat)
    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ ...formValues, acId: datas.ac_id }, {
            onSuccess() {
                query.invalidateQueries("achats")
                cleanForm()
                handleClose()
            },
            onError(err) {
                const error = getError(err)
                setErrors("message", error)
            }
        })
    }

    useEffect(() => {
        setValues("desc", datas.ac_desc)
        setValues("date", datas.ac_date)
    }, [datas, setValues])

    return (
        <div>
            {formErr.message && <Notification m={5} color="red" onClose={() => setErrors("message", "")}>{formErr.message}</Notification>}
            <form onSubmit={handleSubmit}>
                <TextInput
                    type="date"
                    label="Date de reception"
                    autoComplete="off"
                    autoCorrect="off"
                    name="date"
                    value={formValues.date}
                    onChange={handleChange}
                />
                <Textarea
                    label="Description"
                    description="300 caracteres maximum"
                    maxLength={300}
                    autoComplete="off"
                    autoCorrect="off"
                    name="desc"
                    value={formValues.desc}
                    onChange={handleChange}
                />
                <Button mt={5} type="submit" fullWidth variant='outline' color='orange'>Modifier</Button>
            </form>
        </div>
    )
}