import { Button, Group, Notification, NumberInput, Textarea } from '@mantine/core'
import useForm from '../../hooks/useForm'
import { useMutation, useQueryClient } from 'react-query'
import { addShopDepense } from '../../services/api'
import { getError } from '../../utils'
import { useFocusTrap } from '@mantine/hooks'

export default function AddExpense({ boId, handleClose }) {
    const { formValues, handleChange, formErr, setErrors, cleanForm, setValues, getInputProps } = useForm({ mte: "", motif: "" })
    const query = useQueryClient()
    const { mutate } = useMutation(["depenses"], addShopDepense)
    const focusTrap = useFocusTrap()

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ ...formValues, bo_id: boId }, {
            onSuccess: () => {
                query.invalidateQueries("depenses")
                cleanForm()
                handleClose()
            },
            onError: (err) => {
                const error = getError(err)
                if (error) setErrors("message", error)
            }
        })
    }

    return (
        <div>
            {formErr.message && <Notification m={5} onClose={() => setErrors("message", "")} color="red">{formErr.message}</Notification>}
            <form onSubmit={handleSubmit} ref={focusTrap}>
                <NumberInput
                    label="Montant"
                    placeholder="Montant du depense"
                    autoComplete="off"
                    autoCorrect="off"
                    name="mte"
                    min={10}
                    required
                    maxLength={15}
                    value={formValues.mte}
                    onChange={(value) => setValues("mte", value)}
                    data-autofocus
                />
                <Textarea
                    spellCheck={false}
                    label="Motif"
                    placeholder="Description du depense"
                    autoComplete="off"
                    autoCorrect="off"
                    name="motif"
                    maxLength={255}
                    required
                    {...getInputProps("motif")}
                    onChange={handleChange}
                />
                <Group spacing={3}>
                    <Button onClick={() => handleClose()} mt={5} color="orange">Annuler</Button>
                    <Button mt={5} type="submit">Ajouter</Button>
                </Group>
            </form>
        </div>
    )
}