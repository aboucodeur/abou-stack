import React from 'react'
import useForm from "../../hooks/useForm"
import { Button, Group, NumberInput, Text, TextInput } from '@mantine/core'
import AppTable from '../../components/table/AppTable'
import AddForm from './AddForm'
import { editVendreCommand, removeVendreCommand } from '../../services/api'
import { useMutation, useQueryClient } from 'react-query'
import { toLower } from '../../utils'
import { IconCheck, IconPencil, IconSearch, IconTrash } from '@tabler/icons-react'
import useSearch from '../../hooks/useSearch'
import { formatNumber } from '../../helper'

export default function VenteContenu({ vendreCommand, vendId, vendreInfo, getSum }) {
    const { formValues, setValues, cleanForm } = useForm({ qte: '', prix: 0 })
    const [rowsId, setRowsId] = React.useState(null)
    const query = useQueryClient()
    const { mutate } = useMutation(["vendres_cmd"], editVendreCommand)
    const { mutate: remCmd } = useMutation(["vendres"], removeVendreCommand)
    const { searchVal, getSearchProps, handleSearch } = useSearch({ nom: "" })

    const handleEdit = (id) => {
        mutate({ ...formValues, venId: id }, {
            onSuccess() {
                query.invalidateQueries("vendres_cmd")
                query.invalidateQueries("vendres_info")
                cleanForm()
                setRowsId(null)
            },
            onError() { setRowsId(null) }
        })
    }
    const handleRemove = (id) => remCmd(id, {
        onSuccess() {
            query.invalidateQueries("vendres_cmd")
            query.invalidateQueries("user_game")
            query.invalidateQueries("vendres_info")
        }
    })
    const searchFilter = (data) => {
        const { pr_nom } = data
        if (!searchVal.nom) return data
        if (toLower(pr_nom).includes(toLower(searchVal.nom.trim()))) return data
    }

    const tableRows = vendreCommand
        .filter(d => rowsId ? d : searchFilter(d))
        .map((d, _idx) => (
            <tr key={d.ven_id}>
                <td><Text>{_idx + 1}</Text></td>
                <td><Text>{d.pr_nom}</Text></td>
                <td><Text>{d.pr_qte}</Text></td>
                <td>{d.ven_id === rowsId ?
                    <NumberInput
                        placeholder="Quantite"
                        autoComplete="off"
                        autoCorrect="off"
                        defaultValue={d.ven_qte}
                        onChange={(value) => setValues("qte", value)}
                        max={d.pr_qte}
                        maxLength={20}
                        min={1}
                    /> :
                    formatNumber(d.ven_qte)}
                </td>
                <td>{d.ven_id === rowsId ?
                    <NumberInput
                        placeholder="Prix"
                        autoComplete="off"
                        autoCorrect="off"
                        defaultValue={d.ven_prix}
                        onChange={(value) => setValues("prix", value)}
                        maxLength={20}
                        min={0}
                        precision={2} // decimal
                    />
                    : <Text>{formatNumber(d.ven_prix)}</Text>
                }
                </td>
                <td><Text>{formatNumber(d.montant)}</Text></td>
                <td>
                    <Group spacing={5}>
                        {d.ven_id === rowsId ?
                            <Button
                                color="gray"
                                onClick={() => handleEdit(d.ven_id)}
                                type="submit"
                                children={<IconCheck />}
                            />
                            : <Button
                                onClick={() => {
                                    setRowsId(d.ven_id)
                                    setValues("qte", parseInt(d.ven_qte, 10))
                                    setValues("prix", parseFloat(d.ven_prix, 10))
                                }}
                                disabled={vendreInfo.vend_etat !== 0}
                                children={<IconPencil />}
                            />}
                        <Button
                            disabled={vendreInfo.vend_etat !== 0}
                            onClick={() => handleRemove(d.ven_id)}
                            color="red"
                            children={<IconTrash />}
                        />
                    </Group>
                </td>
            </tr>
        ))

    return (
        <div>
            {vendreInfo.vend_etat === 0 ? <AddForm vendId={vendId} /> : null}
            <TextInput
                icon={<IconSearch />}
                autoComplete="off"
                autoCorrect="off"
                placeholder="Rechercher dans le pannier"
                mt={5}
                {...getSearchProps("nom")}
                onChange={handleSearch}
            />
            <AppTable
                title={`Pannier avec une somme de ${formatNumber(getSum)}`}
                tableHead={["N°", "Designation", "stock", "Quantite", "Prix", "Montant", "Action"]}
                tableRows={tableRows}
            />
        </div>
    )
}