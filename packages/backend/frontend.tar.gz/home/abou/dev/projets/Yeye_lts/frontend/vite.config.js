import fs from "fs/promises"
import path from "path"
import { defineConfig } from "vite"
// ** VITE PLUGINS
import react from "@vitejs/plugin-react"
import svgr from "vite-plugin-svgr"
import eslint from "vite-plugin-eslint"
import { VitePWA } from "vite-plugin-pwa"

export default defineConfig(() => {
    return {
        // developpement
        esbuild: {
            loader: "jsx",
            include: /src\/.*\.jsx?$/,
            exclude: [],
        },
        optimizeDeps: {
            esbuildOptions: {
                plugins: [
                    {
                        name: "load-js-files-as-jsx",
                        setup(build) {
                            build.onLoad({ filter: /src\/.*\.js$/ }, async (args) => ({
                                loader: "jsx",
                                contents: await fs.readFile(args.path, "utf-8"),
                            }))
                        },
                    },
                ],
            },
        },
        // ** BUILD OPTIONS (Rollup)
        build: {
            outDir: "build",
            manifest: true,
            chunkSizeWarningLimit: 1900, // en kbs (kilobytes)
            sourcemap: false,
            cssMinify: true,
        },
        plugins: [
            react(),
            svgr({ svgrOptions: { icon: true } }),
            eslint(),
            VitePWA({
                registerType: "autoUpdate",
                // setup du workbox google
                workbox: {
                    navigateFallbackDenylist: [
                        /^\/api\/v1/,
                        // /^\/sw.js/,
                        /^\/robots.txt/,
                        /^\/logo192.png/,
                        /^\/logo512.png/,
                        /^\/file/,
                        /^\/index.html/,
                    ],
                    runtimeCaching: [
                        {
                            urlPattern: ({ url }) => url.pathname.startsWith("/api/v1"),
                            handler: "NetworkOnly",
                            options: { cacheName: "api-cache" },
                        },
                    ],
                },
                includeAssets: ["/favicon.ico ", "/apple-touch-icon.png "],
            }),
        ],
        server: { open: true, port: 3000 },
        resolve: { alias: { "~": path.resolve(__dirname, "./src") } },
    }
})
