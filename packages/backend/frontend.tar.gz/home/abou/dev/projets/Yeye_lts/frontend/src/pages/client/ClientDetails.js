import { Button, Card, Group, Loader, Notification, NumberInput, Text, Title } from "@mantine/core"
import { useParams } from "react-router-dom"
import { useMutation, useQuery, useQueryClient } from "react-query"
import useForm from "../../hooks/useForm"
import { instance } from "../../axios"
import {  getError } from "../../utils"
import { addCcompte, editCcompte, getClientCcompte, removeCcompte } from "../../services/api"
import AppTable from "../../components/table/AppTable"
import { IconCash, IconCheck, IconEdit, IconTrash } from "@tabler/icons-react"
import { formatNumber } from "../../helper"
import { useState } from "react"

export default function ClientDetails() {
    const { id } = useParams()
    const clId = parseInt(id, 10)
    const [rowsId, setRowsId] = useState(null)
    const { formValues, formErr, setValues, cleanForm, setErrors } = useForm({ mte: 0, emte: 0 })
    // ** api
    const query = useQueryClient()
    const { data: clientInfo = {}, isLoading } = useQuery(["clt_info", clId], ({ queryKey }) => queryKey[1] && instance.get(`/clients/${queryKey[1]}`).then(res => res.data))
    const { data: clientCompte = [] } = useQuery(["clt_comp", clId], ({ queryKey }) => getClientCcompte(queryKey[1]))
    const { mutate } = useMutation(["clt_comp"], addCcompte)
    const { mutate: editCompte } = useMutation(["clt_comp"], editCcompte)
    const { mutate: remCompte } = useMutation(["clt_comp"], removeCcompte)


    const customErr = (err) => {
        const error = getError(err)
        if (error) setErrors("message", error)
        if (rowsId) setRowsId(null)
    }
    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ ...formValues, cl_id: clId }, {
            onSuccess() {
                query.invalidateQueries("clt_comp")
                cleanForm()
                if (rowsId) setRowsId(null)
            },
            onError: (err) => customErr(err)
        })
    }
    const handleEdit = (id) => {
        delete formValues.mte
        editCompte({ ...formValues, ccId: id }, {
            onSuccess() {
                query.invalidateQueries("clt_comp")
                cleanForm()
                if (rowsId) setRowsId(null)
            },
            onError: (err) => customErr(err)
        })
    }
    const handleRemove = (id) => {
        remCompte(id, {
            onSuccess() {
                query.invalidateQueries("clt_comp")
                cleanForm()
                if (rowsId) setRowsId(null)
            },
            onError: (err) => customErr(err)
        })
    }

    const isCompte = Array.isArray(clientCompte)
    const rows = isCompte && clientCompte.map(d => (
        <tr key={d.cc_id}>
            <td>
                {d.cl_id === rowsId
                    ? <NumberInput
                        placeholder="Montant"
                        autoComplete="off"
                        autoCorrect="off"
                        defaultValue={d.cc_mte}
                        onChange={(value) => setValues("emte", value)}
                        max={30000000}
                        min={0}
                        maxLength={20}
                        precision={2} // decimal
                    />
                    : <Text>{formatNumber(d.cc_mte)}</Text>
                }

            </td>
            <td>
                <Group spacing={10}>
                    {d.cl_id === rowsId ?
                        <Button
                            color="green"
                            onClick={() => handleEdit(d.cc_id)}
                            children={<IconCheck />}
                        />
                        : <Button
                            onClick={() => setRowsId(d.cl_id)}
                            children={<IconEdit />}
                        />
                    }
                    <Button
                        color="red"
                        onClick={() => handleRemove(d.cc_id)}
                        children={<IconTrash />}
                    />
                </Group>
            </td>
        </tr>
    ))

    if (isLoading) return <Loader />
    if (!clientInfo) return <Text>Client Introuvable</Text>
    return (
        <div>
            {formErr.message ? <Notification color="red" onClose={() => setErrors("message", "")}>{formErr.message}</Notification> : null}
            <form onSubmit={handleSubmit}>
                <Group spacing={3} mt={5}>
                    <NumberInput
                        max={30000000}
                        min={0}
                        placeholder="Montant"
                        autoComplete="off"
                        autoCorrect="off"
                        value={formValues.mte}
                        onChange={(value) => setValues("mte", value)}
                        maxLength={20}
                        required
                        hideControls
                        icon={<IconCash />}
                        precision={2} // decimal
                    />
                    <Button type="submit">Ajouter</Button>
                </Group>
            </form>
            <Card mt={5} shadow="lg" sx={(theme) => ({ backgroundColor: theme.colors.blue[6], color: "white" })}>
                <Title order={4}>Informations du clients</Title>
                <Text>Nom complet : {clientInfo.cl_nom}</Text>
                {clientInfo.cl_tel ? <Text>Telephone : {clientInfo.cl_tel}</Text> : null}
                {clientInfo.cl_adr ? <Text>Adresse : {clientInfo.cl_adr}</Text> : null}
            </Card>
            {isCompte && clientCompte.length === 0
                ? <Text mt={5}>Compte vide 0 F veillez ajouter un montant !!!</Text>
                : <AppTable
                    title="Informations sur le compte du clients"
                    tableHead={["Montant", "Action"]}
                    tableRows={rows}
                />}
        </div>
    )
}
