import { Alert, Button, TextInput, Title } from '@mantine/core'
import useForm from "../../hooks/useForm"
import { useMutation, useQueryClient } from 'react-query'
import { addFournisseur } from '../../services/api'
import { getError } from '../../utils'

export default function AddFrs({ boId, handleClose }) {
    const initialValues = { nom: "", tel: "", adr: "", email: "", bo_id: boId }
    const { formValues, handleChange, cleanForm, formErrors, setErrors } = useForm(initialValues)
    const { mutate, isError } = useMutation(["frs"], addFournisseur)
    const query = useQueryClient()

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate({ ...formValues, nom: formValues.nom.trim() }, {
            onSuccess: () => {
                query.invalidateQueries("frs")
                query.invalidateQueries("frs_adapt")
                cleanForm()
                handleClose()
            },
            onError: (err) => {
                const error = getError(err)
                if (error) setErrors("message", error)
            }
        })
    }

    return (
        <div>
            {isError && <Alert color="red" title={<Title order={4}>Erreur</Title>}>{formErrors.message}</Alert>}
            <div>
                <form onSubmit={handleSubmit}>
                    <TextInput
                        label="Nom"
                        placeholder="Donner le nom du fournisseur"
                        name="nom"
                        value={formValues.nom}
                        onChange={handleChange}
                        required
                    />
                    <TextInput
                        label="Telephone"
                        placeholder="Ex : 0023 __-__-__-__"
                        name="tel"
                        value={formValues.tel}
                        onChange={handleChange}
                        required
                    />
                    <TextInput
                        label="Adresse"
                        placeholder="Donner une addresse"
                        name="adr"
                        value={formValues.adr}
                        onChange={handleChange}
                        required
                    />
                    <TextInput
                        type="email"
                        label="Email"
                        placeholder="Donner l'email du fournisseur"
                        name="email"
                        value={formValues.email}
                        onChange={handleChange}
                        required
                    />
                    <Button type="submit" mt={5}>Enregistrer</Button>
                </form>
            </div>
        </div>
    )
}