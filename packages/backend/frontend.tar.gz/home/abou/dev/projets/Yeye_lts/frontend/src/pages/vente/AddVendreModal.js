import { Button, Notification, Select, TextInput } from '@mantine/core'
import { modals } from '@mantine/modals'
import { useMutation, useQueryClient } from 'react-query'
import { addShopVendre } from '../../services/api'
import useForm from '../../hooks/useForm'
import { useNavigate } from 'react-router-dom'
import AddClient from '../client/AddClient'
import { getError } from '../../utils'
import { useFocusTrap } from '@mantine/hooks'

export default function AddVendreModal({ boId, usId, handleClose, shopClient }) {
    const navigate = useNavigate()
    const { formValues, formErr, setValues, setErrors, cleanForm } = useForm({
        cl_id: null,
        ven_date: '',
    })

    const query = useQueryClient()
    const { mutate } = useMutation(['vendres'], addShopVendre)
    const focusTrap = useFocusTrap()

    const handleSubmit = (e) => {
        e.preventDefault()
        mutate(
            { ...formValues, bo_id: boId, usId },
            {
                onSuccess({ vendId }) {
                    query.invalidateQueries('vendres')
                    cleanForm()
                    handleClose()
                    navigate(`/ventes/${vendId}`)
                },
                onError(err) {
                    const error = getError(err)
                    if (error) setErrors('message', error)
                },
            },
        )
    }
    const handleAddClient = () => {
        modals.open({
            title: 'Ajout Rapide client',
            children: <AddClient boId={boId} closeModal={() => modals.closeAll()} />,
        })
    }

    return (
        <>
            {formErr.message && (
                <Notification m={5} color="red" onClose={() => setErrors('message', '')}>
                    {formErr.message}
                </Notification>
            )}
            <form onSubmit={handleSubmit} ref={focusTrap}>
                {/* maxDropdownHeight={90} : Pour la nouvelle version */}
                <Select
                    label="Choisir le client"
                    nothingFound={
                        <Button
                            style={{ flex: 0.6 }}
                            color="orange"
                            onClick={() => handleAddClient()}
                        >
                            le client n'existe pas cliquer pour ajouter !
                        </Button>
                    }
                    data={shopClient}
                    searchable
                    clearable
                    onChange={(value) => setValues('cl_id', value)}
                    required
                    data-autofocus
                    maxDropdownHeight={90}
                />
                <TextInput
                    type="date"
                    label="Choisir la date (pas obligatoire)"
                    placeholder="Pour inserer des anciennes ventes"
                    autoCorrect="false"
                    value={formValues.ven_date || undefined}
                    onChange={(e) => setValues('ven_date', e.target.value)}
                />
                <Button mt={5} color="green" type="submit" fullWidth>
                    Valider
                </Button>
            </form>
        </>
    )
}
