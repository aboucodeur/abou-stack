import { NavLink, useNavigate } from "react-router-dom"
import {
    Navbar,
    UnstyledButton,
    createStyles,
    Stack,
    Text,
    Group,
    Collapse,
    useMantineTheme,
    Button,
    ScrollArea,
    Tooltip,
} from "@mantine/core"
import { IconChevronRight, IconChevronLeft, IconLogout } from "@tabler/icons-react"
import ImageIcon from "../icons/ImageIcon"
import { useAppState } from "../../context/AppContext"
import {
    achatIcon,
    bankIcon,
    cashIcon,
    cltIcon,
    dashIcon,
    frsIcon,
    iaIcon,
    listIcon,
    meIcon,
    stockIcon,
    userIcon,
    venteIcon,
} from "../../constants"
import { useState } from "react"

const useStyles = createStyles((theme) => ({
    container: {
        display: "flex",
        alignItems: "center",
    },
    tlink: {
        width: "100%",
        margin: "6px",
        padding: "7px",
        cursor: "pointer",
        "&:hover": {
            // backgroundColor: theme.colors.gray[6],
            color: theme.colors.blue[6],
            fontWeight: "bold",
        },
    },
    subLink: {
        display: "block",
        textDecoration: "none",
        fontWeight: 500,
        padding: "7px",
        paddingLeft: 31,
        marginLeft: 25,
        fontSize: theme.fontSizes.sm,
        color: theme.colorScheme === "dark" ? theme.colors.dark[0] : theme.colors.gray[7],
        borderLeft: `1px solid ${
            theme.colorScheme === "dark" ? theme.colors.dark[4] : theme.colors.gray[3]
        }`,
        "&:hover": {
            backgroundColor:
                theme.colorScheme === "dark" ? theme.colors.dark[7] : theme.colors.gray[0],
            color: theme.colorScheme === "dark" ? theme.white : theme.black,
        },
    },
    chevron: { transition: "transform 200ms ease" },
}))

function NavbarLink({ icon = {}, label, link, links, ...rest }) {
    const { classes } = useStyles()
    const theme = useMantineTheme()
    const hasLinks = Array.isArray(links)
    const [opened, setOpened] = useState(false)
    const ChevronIcon = theme.dir === "ltr" ? IconChevronRight : IconChevronLeft

    const items = (hasLinks ? links : []).map((link) => (
        <Text
            component={NavLink}
            to={link.link}
            className={classes.subLink}
            href={link.link}
            key={link.label}
            style={({ isActive }) => ({
                backgroundColor:
                    isActive &&
                    theme.fn.variant({ variant: "light", color: theme.primaryColor }).background,
                color:
                    isActive &&
                    theme.fn.variant({ variant: "light", color: theme.primaryColor }).color,
            })}
            {...rest}
        >
            {link.label}
        </Text>
    ))

    return (
        <div style={{ userSelect: "none" }}>
            {hasLinks ? (
                <Group mt={5}>
                    <UnstyledButton onClick={() => setOpened((o) => !o)}>
                        <Group>
                            {icon.src && <ImageIcon src={icon.src} alt={icon.alt} />}
                            <Text>{label}</Text>
                        </Group>
                    </UnstyledButton>
                    <ChevronIcon
                        className={classes.chevron}
                        size={14}
                        stroke={1.5}
                        style={{
                            transform: opened
                                ? `rotate(${theme.dir === "rtl" ? -90 : 90}deg)`
                                : "none",
                        }}
                    />
                </Group>
            ) : (
                <div className={classes.container}>
                    {icon.src ? <ImageIcon src={icon.src} alt={icon.alt} /> : null}
                    <Text
                        className={classes.tlink}
                        to={link}
                        component={NavLink}
                        style={({ isActive }) => ({
                            backgroundColor: isActive ? theme.colors.blue[6] : undefined,
                            color: isActive ? "white" : undefined,
                            borderRadius: "12px",
                            fontWeight: isActive ? "bold" : undefined,
                        })}
                        {...rest}
                    >
                        {label}
                    </Text>
                </div>
            )}
            {hasLinks ? <Collapse in={opened}>{items}</Collapse> : null}
        </div>
    )
}

export const mockdata = [
    { icon: { src: dashIcon, alt: "dash_icon" }, label: "Statistiques", link: "/acceuil" },
    {
        icon: { src: stockIcon, alt: "stock_icon" },
        label: "Stocks",
        link: "/depots",
        id: "yeye_welcome_0",
    },
    {
        icon: { src: achatIcon, alt: "achat_icon" },
        label: "Achats",
        link: "/commandes/fournisseurs",
        id: "menu_achat_9",
    },
    { icon: { src: venteIcon, alt: "ventes_icon" }, label: "Ventes", link: "/ventes" },
    { icon: { src: iaIcon, alt: "dash_icon" }, label: "Stats IA", link: "/ia" },
    { icon: { src: cltIcon, alt: "clt_icon" }, label: "Clients", link: "/clients" },
    { icon: { src: frsIcon, alt: "frs_icon" }, label: "Fournisseurs", link: "/fournisseurs" },
    { icon: { src: cashIcon, alt: "depenses_icon" }, label: "Depenses", link: "/depenses" },
    { icon: { src: bankIcon, alt: "bank_icon" }, label: "Actionnaire", link: "/action" },
    {
        icon: { src: meIcon, alt: "me_icon" },
        label: "Infos",
        links: [
            { label: "Gerants", link: "/gerants" },
            { label: "Informations", link: "/moi/boutique" },
            { label: "Mot de passe", link: "/moi/password" },
        ],
    },
]

const rootLinks = [
    { icon: { src: userIcon }, label: "Ajouter", link: "/admin/dashboard/user/add" },
    { icon: { src: listIcon }, label: "Utilisateur", link: "/admin/dashboard/user/lists" },
]

const gerLinks = [
    { icon: { src: venteIcon, alt: "ventes_icon" }, label: "Ventes", link: "/ventes" },
    {
        icon: { src: meIcon, alt: "me_icon" },
        label: "Moi",
        links: [{ label: "Mot de passe", link: "/moi/password" }],
    },
]

export default function AppNavbar({ opened, setOpened }) {
    const { logOut, getUser } = useAppState()
    const navigate = useNavigate()
    const currentRole = getUser.us_role
    const origin = currentRole === "admin" ? "/admin" : "/"
    // const closeNav = () => setOpened(false)

    const links = mockdata.map((link) => (
        <NavbarLink label={link.label} key={link.label} {...link} />
    ))
    const aLinks = rootLinks.map((link) => (
        <NavbarLink label={link.label} key={link.label} {...link} />
    ))
    const gLinks = gerLinks.map((link) => (
        <NavbarLink label={link.label} key={link.label} {...link} />
    ))

    return (
        <Navbar
            hiddenBreakpoint="sm"
            hidden={!opened}
            height="auto"
            width={{ sm: 170, lg: 190 }}
            p="sm"
        >
            <Navbar.Section component={ScrollArea} grow mx="-xs" px="xs">
                <Stack justify="center" spacing={0}>
                    {currentRole === "admin" ? aLinks : currentRole === "prop" ? links : gLinks}
                </Stack>
            </Navbar.Section>
            <Navbar.Section>
                <Tooltip withArrow label="Au revoir">
                    <Button
                        mt={5}
                        color="red"
                        onClick={() => {
                            logOut()
                            navigate(origin)
                            window.location.reload()
                        }}
                    >
                        <IconLogout size={21} />
                    </Button>
                </Tooltip>
            </Navbar.Section>
        </Navbar>
    )
}
