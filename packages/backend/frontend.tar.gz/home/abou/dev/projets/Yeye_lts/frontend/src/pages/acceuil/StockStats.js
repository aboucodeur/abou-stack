import { BarChart, Bar, XAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { Loader, Title } from '@mantine/core'
import { useQuery } from 'react-query'
import { getBoutiqueStat } from '../../services/api'
import { formatWari } from '../../helper'

export default function StockStats({ boId }) {
    const { data: statDatas = [], isLoading } = useQuery(['stat', boId], ({ queryKey }) => getBoutiqueStat(queryKey[1]))
    const parseDate = (dateString) => {
        const date = new Date(dateString)
        return date
    }

    if (isLoading) return <Loader />;
    return (
        <div>
            <Title order={2}>Revenus annuels</Title>
            <ResponsiveContainer width="80%" height={350}>
                <BarChart barSize={60} data={statDatas.datasYear} margin={{ top: 15, right: 5, bottom: 5, left: 35 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="annee" tickFormatter={(tick) => parseDate(tick).getUTCFullYear()} />
                    <Tooltip formatter={(value) => `${formatWari(value)}`} />
                    <Legend formatter={() => "Recette Annuels"} />
                    <Bar dataKey="recette" fill="#228be6" />
                </BarChart>
            </ResponsiveContainer>
            <Title order={2}>Revenus trimestriels</Title>
            <ResponsiveContainer width="80%" height={350}>
                <BarChart barSize={60} data={statDatas.datasQuarter} margin={{ top: 15, right: 5, bottom: 5, left: 35 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis
                        dataKey="trimestre"
                        tickFormatter={(tick) => parseDate(tick).toLocaleDateString()}
                    />
                    {/* <YAxis /> */}
                    <Tooltip formatter={(value) => `${formatWari(value)}`} />
                    <Legend formatter={() => "Recette trimestriels"} />
                    <Bar dataKey="recette" fill="#228be6" />
                </BarChart>
            </ResponsiveContainer>

        </div>
    );
}
