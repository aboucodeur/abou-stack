import { modals } from "@mantine/modals"
import { Button, Card, Divider, Group, Image, Loader, Menu, Text, Title } from '@mantine/core'
import { useAppState } from "../../context/AppContext"
import { useQuery, useQueryClient } from "react-query"
import { getBoutique } from '../../services/api'
import { instance } from '../../axios'
import EditShop from './EditShop'
import { SHOP_EDIT } from '../../context/action/action'
import { getError } from '../../utils'
import { Upload } from '../../components'
import { useState } from "react"

export default function ShopPage() {
    const { getShop, dispatch } = useAppState()
    const [upload, setUpload] = useState({ file: null, err: {} })
    const query = useQueryClient()
    const shopId = getShop.bo_id

    const { data = {}, isLoading } = useQuery(["shop", shopId], ({ queryKey }) => getBoutique(queryKey[1]))

    const editShopModal = (data) => {
        modals.open({
            title: "Modification",
            children: <EditShop data={data} boId={data.bo_id} handleClose={() => modals.closeAll()} />
        })
    }
    const removeShopFileModal = () => {
        modals.open({
            title: "Supprimer le logo",
            children: <Button color="red" onClick={() => {
                instance.delete(`/uploads/${shopId}`)
                    .then(() => {
                        query.invalidateQueries("shop")
                        dispatch({ type: SHOP_EDIT, payload: { bo_url: '' } }) // * note : coherence du store
                        modals.closeAll()
                    })
            }}>Oui, supprimer</Button>
        })
    }
    const handleUpload = (e) => {
        e.preventDefault()
        if (Object.entries(upload.err).length === 0) {
            const formData = new FormData()
            formData.append("file", upload.file)
            instance.post(`/uploads/${shopId}`, formData)
                .then((res) => {
                    query.invalidateQueries("shop")
                    dispatch({ type: SHOP_EDIT, payload: { bo_url: res.data.bo_url } }) // ** note : coherence du store
                })
                .catch(err => {
                    const error = getError(err)
                    if (error) {
                        modals.open({
                            title: <Title order={4}>Erreur</Title>,
                            color: "red",
                            children: <Text>{error}</Text>
                        })
                    }
                })
        }
    }
    if (isLoading) return <Loader />
    return (
        <div>
            <Title order={4}>Informations de l'entreprise</Title>
            <Card shadow="lg" sx={(theme) => ({ backgroundColor: theme.colors.blue[6], color: "white" })}>
                {data.bo_url &&
                    <Menu trigger="hover">
                        <Menu.Target>
                            <Image src={data.bo_url} style={{ maxWidth: 213 }} m={5} alt="logo_boutique" />
                        </Menu.Target>
                        <Menu.Dropdown>
                            <Menu.Label>Options</Menu.Label>
                            <Menu.Item color="red" onClick={() => removeShopFileModal()}>Supprimer</Menu.Item>
                        </Menu.Dropdown>
                    </Menu>
                }
                <Title order={3}>{data.bo_nom}</Title>
                <Divider mb={5} />
                <Text>{data.bo_tel}</Text>
                <Text>{data.bo_adr}</Text>
                <Text>{data.bo_email}</Text>
                {/* <Text>Expiration de l'abonnement : {new Date(data.exp * 1000).toLocaleString().split(" ").join(" à ")}</Text> */}
            </Card>
            <Button mt={5} onClick={() => editShopModal({ ...data })}>Modifier Informations</Button>
            <Divider mt={5} label="Téléchargement du logo" />
            <form encType="multipart/form-data" onSubmit={handleUpload}>
                <Group direction="row" spacing={5} align="center">
                    <Upload onUploadFile={(err, file) => setUpload(prev => ({ ...prev, file, err }))} />
                    {upload.file ? <Button type="submit">Modifier</Button> : null}
                </Group>
            </form>
        </div>
    )
}