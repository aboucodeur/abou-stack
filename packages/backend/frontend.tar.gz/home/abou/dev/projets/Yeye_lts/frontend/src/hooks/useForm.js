import React from "react"

export default function useForm(initialValues = {}, submitFn) {
    const [formValues, setFormValues] = React.useState({ ...initialValues })
    const [formErr, setFormErr] = React.useState({})
    const [isSubmit, setIsSubmit] = React.useState(false)

    const handleChange = (e) => {
        const { name, value, type } = e.target
        if (!name) throw new Error("Aucun nom definis")
        if (type === "checkbox") setFormValues(prev => ({ ...prev, [name]: !formValues[name] }))
        else setFormValues(prev => ({ ...prev, [name]: value }))
    }
    const setValues = React.useCallback((key, value) => setFormValues(prev => ({ ...prev, [key]: value })), [])
    const setErrors = React.useCallback((key, value) => setFormErr(prev => ({ ...prev, [key]: value })), [])
    const getInputProps = React.useCallback((name = "") => {
        const hasNoyKey = !Object.keys(formValues).includes(name)
        if (hasNoyKey) throw new Error("nom introuvable")
        return { name: name, value: formValues[name] }
    }, [formValues])

    // ** external error
    const onError = (values, cb) => {
        const err = {}
        if (cb) cb(values, err)
        setFormErr(err)
    }
    // ** internal error
    const _validate = (values, cb) => {
        const err = {}
        if (cb) cb(values, err)
        return err
    }
    // * Soumettre automatiquement le formulaire
    const handleSubmit = React.useCallback((e, cb) => {
        if (e) e.preventDefault()
        setFormErr(_validate(formValues, cb))
        setIsSubmit(true)
    }, [formValues])
    const cleanForm = React.useCallback(() => setFormValues(initialValues), [initialValues])

    React.useEffect(() => {
        if (Object.entries(formErr).length === 0 && isSubmit && submitFn) {
            submitFn(formValues)
            setIsSubmit(false)
        }
        return
    }, [formErr, formValues, isSubmit, submitFn, cleanForm])

    return {
        formValues,
        formErr,
        setFormValues,
        setFormErr,
        setValues,
        setErrors,
        handleChange,
        handleSubmit,
        getInputProps,
        onError,
        cleanForm,
    }
}