import { useQuery } from 'react-query'
import { instance } from '../../axios'
import { useAppState } from '../../context/AppContext'
import { Loader, Text, useMantineTheme } from '@mantine/core'
import { AppTable } from '../../components'
import { frenchDays } from '../../mock'

export default function VenteIa() {
    const { getShop } = useAppState()
    const shopId = getShop.bo_id
    const theme = useMantineTheme()
    const day = new Date().getDay()

    const { data, isLoading } = useQuery(["ia_vente", day],
        ({ queryKey }) => instance.get('/ia/prediction/' + shopId + '?day=' + queryKey[1]).then(res => res.data)
    )

    const rows = Array.isArray(data) && data.map((d, _idx) => (
        <tr style={{
            backgroundColor: d.vend_id && theme.colors.green[6],
            color: d.vend_id && theme.white,
            userSelect: "none"
        }} key={d.cl_id}>
            <td><Text>{(_idx + 1)}</Text></td>
            <td><Text>{d.cl_nom}</Text></td>
            <td><Text>{d.vend_id ? "Confimer" : "Pas confimer"}</Text></td>
        </tr>
    ))


    if (isLoading) return <Loader />

    if (Array.isArray(data) && data.length === 0) return (
        <Text weight="bold" mt={5}>Moins de clients {frenchDays[day]} dans votre entreprise !</Text>
    )

    return (
        <AppTable
            tableHead={["No", "Client predit", "Observation"]}
            tableRows={rows}
        />
    )
}