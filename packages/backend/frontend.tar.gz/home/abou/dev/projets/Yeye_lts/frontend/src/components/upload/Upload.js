import { useState } from "react";
import { Button, Group } from "@mantine/core";
import { IconUpload } from "@tabler/icons-react";

const UploadContainerStyles = {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    color: "white",
    alignItems: "center",
    borderRadius: "18px",
};

const LabelStyles = {
    backgroundColor: "slateblue",
    padding: "12px",
    borderRadius: "12px",
};

const UploadInputStyles = {
    display: "none",
};

const MIMES_TYPES = {
    "image/jpeg": "jpg",
    "image/jpg": "jpg",
    "image/png": "png",
};

export default function Upload({ onUploadFile }) {
    const initialValues = { file: null, uploaded: false };
    const [isUpload, setIsUpload] = useState(initialValues);

    const removeFile = () => {
        setIsUpload(initialValues);
        onUploadFile({}, null);
    };

    const handleUpload = (e) => {
        const isFile = e.target.files[0];
        if (!isFile) return;

        const getExtension = MIMES_TYPES[isFile.type];
        if (!getExtension) {
            onUploadFile({ message: "Extension not supported" });
        } else {
            setIsUpload({ ...isUpload, file: isFile, uploaded: true });
            onUploadFile({}, isFile);
        }
    };

    return (
        <div style={UploadContainerStyles}>
            <Group>
                <label htmlFor="upload-file" style={LabelStyles}>
                    <IconUpload size={21} />
                </label>
                {isUpload.uploaded && (
                    <Button color="red" onClick={() => removeFile()}>
                        Retirer le fichier
                    </Button>
                )}
            </Group>

            <input
                id="upload-file"
                type="file"
                required={true}
                onChange={handleUpload}
                style={UploadInputStyles}
            />
        </div>
    );
}
