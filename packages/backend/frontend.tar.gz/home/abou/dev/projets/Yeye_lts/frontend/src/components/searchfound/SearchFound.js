import React from 'react'
import { Text } from '@mantine/core'

function SearchFound({ message = "Auncun resultat trouver !", children }) {
    return (
        <div>
            <Text weight="bold" mt={15} mb={15} >{message}</Text>
            {children}
        </div>
    )
}

export default SearchFound